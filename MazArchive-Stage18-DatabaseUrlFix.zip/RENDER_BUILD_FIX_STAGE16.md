# Stage 16 – Render build stability

Changes based on Stage 15:
- Both Dockerfiles disable the Gradle daemon explicitly.
- Gradle build runs `clean installDist` with stack traces for clearer Render logs.
- Gradle JVM memory is limited to reduce build failures on small Render instances.

Important:
- Do not place secrets in GitHub or this file.
- Keep `ADMIN_PASSWORD`, `DATABASE_URL`, `DB_USER`, `DB_PASSWORD`, and `JWT_SECRET` in Render Environment variables.
