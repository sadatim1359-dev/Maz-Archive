# Fix4 implementation status

This package is based on the uploaded Fix4 tree; it was not rebuilt from scratch.

Implemented in this pass:
- Added Android Retrofit question retrieval endpoint and repository method.
- Added serializable Android question DTO.
- Added backend exam duration persistence and migration.
- Added duration validation at database level.
- Changed login to reject invalid credentials instead of issuing a USER token for arbitrary credentials.
- Preserved existing Android UI and backend routes.

Required before production deployment:
- Wire `ExamRepository.questions()` into the Compose exam player and remove sample-question fallback.
- Add authenticated user accounts and server-side result submission tables/endpoints.
- Replace the custom JWT implementation with a standard JWT issuer including expiry and refresh-token persistence.
- Run Gradle/Android and backend integration tests in CI with configured services.
