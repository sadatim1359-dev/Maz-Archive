# Production checklist

Implemented in source:
- Android Compose/Material 3, RTL-first dark UI
- Archive-scoped search and Year → Period → Month filter UI
- In-app Android PdfRenderer with two-finger zoom
- Separate annotation data model and normalized coordinates
- Room local queue + repository + sync boundary
- Ktor API with PostgreSQL/Exposed
- JWT role separation and user-scoped annotation queries
- Private filesystem PDF serving behind authentication
- PDF upload content type, magic-byte and 50 MiB validation
- Admin CRUD and PDF replacement UI
- Database indexes and foreign keys

Before public deployment:
1. Replace demo login with a real identity provider or a properly hashed user table + refresh tokens.
2. Store PDFs in S3/MinIO private buckets and serve short-lived signed URLs.
3. Put API behind HTTPS/reverse proxy with rate limiting and request-size limits.
4. Add multipart streaming uploads, antivirus scanning, and PDF parser validation.
5. Add database migrations (Flyway/Liquibase) rather than SchemaUtils.create in production.
6. Add Android WorkManager constraints for CONNECTED network and exponential backoff.
7. Persist every stroke as an immutable event or operation record if collaborative history is required.
8. Add full UI/instrumentation tests, API integration tests, backup/restore drills and crash reporting.
9. Bundle Vazirmatn font under app assets/resources if licensing and distribution terms permit.
10. Supply only exam PDFs whose distribution rights are established.
