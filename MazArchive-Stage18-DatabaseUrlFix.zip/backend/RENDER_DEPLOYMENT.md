# Render deployment

In Render, create a **Web Service** connected to the GitHub repository.

- Runtime: **Docker**
- Root Directory: `backend`
- Dockerfile Path: `Dockerfile`
- Start Command: leave empty (the Dockerfile supplies it)
- Add environment variables:
  - `ADMIN_PASSWORD`: a strong administrator password
  - `JWT_SECRET`: a long random secret
  - Database variables required by the backend (`DATABASE_URL`, `DB_USER`, `DB_PASSWORD`) after creating PostgreSQL

The service listens on Render's `PORT` value.
