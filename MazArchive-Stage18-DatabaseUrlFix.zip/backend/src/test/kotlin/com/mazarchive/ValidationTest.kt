package com.mazarchive
import kotlin.test.Test
import kotlin.test.assertTrue
class ValidationTest {
 @Test fun normalizedCoordinatesAreBounded(){val x=0.42f;val y=0.87f;assertTrue(x in 0f..1f);assertTrue(y in 0f..1f)}
}
