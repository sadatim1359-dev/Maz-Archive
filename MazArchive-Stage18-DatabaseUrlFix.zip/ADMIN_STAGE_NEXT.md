# Admin CRUD Stage

Implemented in Android API layer and admin UI:
- Update exam via PUT /admin/exams/{id}
- Delete exam via DELETE /admin/exams/{id}
- Edit exam form prefill
- Delete exam action

Not yet verified against a live backend or compiled APK.
