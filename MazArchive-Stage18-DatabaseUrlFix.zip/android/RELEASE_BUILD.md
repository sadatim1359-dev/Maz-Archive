# Release build

The source is prepared for a release build, but the APK must be compiled on a machine with Android SDK/Gradle tooling.

1. Open `android/` in Android Studio.
2. Configure the Android SDK.
3. Set the backend URL in `AppConfig.BASE_URL`.
4. Start PostgreSQL and the Ktor backend.
5. Run the app on an emulator/device.
6. Execute unit/UI tests.
7. Configure a release signing key.
8. Build:
   - APK for direct installation
   - AAB for Google Play

Do not ship with the demo `JWT_SECRET`, `ADMIN_PASSWORD`, database credentials, or localhost URLs.
