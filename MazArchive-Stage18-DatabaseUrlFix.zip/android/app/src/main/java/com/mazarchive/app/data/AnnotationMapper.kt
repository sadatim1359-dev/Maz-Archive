package com.mazarchive.app.data
import com.mazarchive.app.AnnotationEntity
import com.mazarchive.app.AnnotationPayload
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

object AnnotationMapper {
    private val json=Json{encodeDefaults=true}
    fun position(points:List<Pair<Float,Float>>)=json.encodeToString(points)
    fun payload(a:AnnotationEntity)=AnnotationPayload(
        a.id,a.userId,a.examId,a.pageNumber,a.type,a.content,a.position,a.color,a.thickness)
}
