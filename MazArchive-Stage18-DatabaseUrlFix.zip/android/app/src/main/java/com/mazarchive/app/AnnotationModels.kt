package com.mazarchive.app

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import kotlinx.serialization.Serializable


@Serializable
data class QuestionDto(
    val id: Long = 0,
    val examId: Long,
    val number: Int,
    val text: String,
    val options: List<String>,
    val correctIndex: Int,
    val imageUrl: String? = null
)

@Serializable
data class AnnotationPayload(
    val id:String, val user_id:String, val exam_id:Long, val page_number:Int,
    val type:String, val content:String?=null, val position:String,
    val color:String, val thickness:Float, val created_at:String="", val updated_at:String=""
)

@Entity(tableName="annotation_queue", indices=[Index(value=["userId","examId","pageNumber"])])
data class AnnotationEntity(
    @PrimaryKey val id:String, val userId:String, val examId:Long, val pageNumber:Int,
    val type:String, val content:String?, val position:String, val color:String,
    val thickness:Float, val synced:Boolean=false
)
@Dao interface AnnotationDao {
    @Query("SELECT * FROM annotation_queue WHERE examId=:examId AND userId=:userId ORDER BY pageNumber,id")
    suspend fun byExam(examId:Long,userId:String):List<AnnotationEntity>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsert(a:AnnotationEntity)
    @Query("SELECT * FROM annotation_queue WHERE synced=0") suspend fun pending():List<AnnotationEntity>
    @Query("UPDATE annotation_queue SET synced=1 WHERE id=:id") suspend fun markSynced(id:String)
    @Query("DELETE FROM annotation_queue WHERE id=:id") suspend fun delete(id:String)
}
@Database(entities=[AnnotationEntity::class],version=1,exportSchema=false)
abstract class MazDb:RoomDatabase(){
    abstract fun annotations():AnnotationDao
    companion object {
        @Volatile private var INSTANCE:MazDb?=null
        fun get(context:Context)=INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext,MazDb::class.java,"mazarchive.db").build().also{INSTANCE=it}
        }
    }
}

interface AnnotationApi {
    @GET("exams/{id}/annotations") suspend fun list(@Path("id") examId:Long):List<AnnotationPayload>
    @POST("exams/{id}/annotations") suspend fun create(@Path("id") examId:Long,@Body a:AnnotationPayload):AnnotationPayload
    @PUT("annotations/{id}") suspend fun update(@Path("id") id:String,@Body a:AnnotationPayload):AnnotationPayload
    @DELETE("annotations/{id}") suspend fun delete(@Path("id") id:String)
}
class AnnotationRepository(private val dao:AnnotationDao, private val api:AnnotationApi) {
    suspend fun local(examId:Long,userId:String)=dao.byExam(examId,userId)
    suspend fun saveLocal(a:AnnotationEntity)=dao.upsert(a)
    suspend fun sync() {
        dao.pending().forEach { a ->
            runCatching {
                api.create(a.examId, AnnotationPayload(a.id,a.userId,a.examId,a.pageNumber,a.type,a.content,a.position,a.color,a.thickness))
                dao.markSynced(a.id)
            }
        }
    }
}
class AnnotationSyncWorker(appContext:Context,params:WorkerParameters):CoroutineWorker(appContext,params){
    override suspend fun doWork():Result = withContext(Dispatchers.IO) {
        // Repository is wired by the application DI graph in the production stage.
        Result.success()
    }
}
