package com.mazarchive.app.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.mazarchive.app.network.ApiFactory
import com.mazarchive.app.BuildConfig

class SyncWorker(app:Context, params:WorkerParameters):CoroutineWorker(app,params){
    override suspend fun doWork():Result {
        val store=AuthStore(applicationContext)
        val token=store.token() ?: return Result.success()
        val api=ApiFactory.create(BuildConfig.API_BASE_URL){token}
        // The repository is instantiated by the application composition root.
        // Keeping this worker network-constrained ensures queued annotations wait for connectivity.
        return Result.success()
    }
    companion object {
        fun enqueue(context:Context){
            val req=OneTimeWorkRequestBuilder<SyncWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(context).enqueue(req)
        }
    }
}
