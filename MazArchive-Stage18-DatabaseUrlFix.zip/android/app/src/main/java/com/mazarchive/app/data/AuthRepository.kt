package com.mazarchive.app.data

import com.mazarchive.app.network.AuthApi
import com.mazarchive.app.network.LoginRequest

data class Session(val accessToken:String,val refreshToken:String?,val role:String)
class AuthRepository(private val api:AuthApi, private val store:AuthStore){
    suspend fun login(username:String,password:String):Result<Session> = runCatching {
        val r=api.login(LoginRequest(username,password))
        Session(r.token,null,r.role).also{store.save(it.accessToken,it.role)}
    }
    fun session():Session?=store.token()?.let{Session(it, null, store.role()?:"USER")}
    fun logout(){store.clear()}
}
