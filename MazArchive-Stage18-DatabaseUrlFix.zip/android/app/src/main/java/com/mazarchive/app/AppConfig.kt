package com.mazarchive.app
object AppConfig { const val BASE_URL = "https://maz-archive.onrender.com/" }