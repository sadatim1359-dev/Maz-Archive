package com.mazarchive.app.ui
import com.mazarchive.app.Exam
data class ArchiveUiState(val isLoading:Boolean=false,val exams:List<Exam> = emptyList(),val error:String?=null)
