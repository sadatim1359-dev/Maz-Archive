package com.mazarchive.app.data

import com.mazarchive.app.Exam
import com.mazarchive.app.network.MazApi

data class ArchiveQuery(
    val grade:String,
    val field:String,
    val year:Int?=null,
    val period:String?=null,
    val month:String?=null,
    val search:String?=null
)
class ArchiveRepository(private val api:MazApi){
    suspend fun search(q:ArchiveQuery):List<Exam> =
        api.exams(q.grade,q.field,q.year,q.period,q.month,q.search)
}
