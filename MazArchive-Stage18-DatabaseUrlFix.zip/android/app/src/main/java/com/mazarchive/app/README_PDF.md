PDF implementation notes:
- Android PdfRenderer is used because it is platform-supported and keeps PDF content immutable.
- The current screen demonstrates real rendering and pinch zoom.
- For production, move rendering to a bounded background pool, add page virtualization, a real page-position scrollbar, and a transparent annotation Canvas above each page.
- Store normalized page coordinates (0..1) so annotations remain stable across zoom/device sizes.
- The pen/highlighter/eraser tool state should live in PdfViewModel; pointer input should distinguish one-finger draw vs one-finger scroll, while transform gestures retain two-finger pan/zoom.
