# Deployment

## Backend
Use PostgreSQL with automated backups and migrations. Put Ktor behind HTTPS/reverse proxy.

Required production environment:
- DATABASE_URL
- DB_USER
- DB_PASSWORD
- JWT_SECRET
- ADMIN_PASSWORD (or replace with a proper identity provider)
- STORAGE_DIR

## PDF storage
For production, use a private S3-compatible object store (S3/MinIO). Keep PDFs inaccessible anonymously and issue short-lived signed URLs.

## Security
- HTTPS only
- strong password hashing / identity provider
- short-lived access tokens + refresh token rotation
- rate limiting
- upload size/type validation
- PDF malware/content scanning
- database least-privilege credentials
- audit logging for admin operations

## Observability
Add structured logs, health checks, crash reporting, metrics and alerting before public release.
