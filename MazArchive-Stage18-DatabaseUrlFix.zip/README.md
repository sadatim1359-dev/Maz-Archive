# MazArchive | آرشیو ماز — Full-stack project

A production-oriented Persian RTL Android archive app with a Kotlin/Ktor API, PostgreSQL and private PDF storage.

## Modules
- `android/`: Android app, Compose UI, archive/search/filter, PDF reader, annotation state, Room repository and API client.
- `backend/`: Ktor REST API, JWT roles, PostgreSQL/Exposed persistence, private PDF storage, admin endpoints and admin HTML console.
- `backend/schema.sql`: relational schema and indexes.

## Architecture
Compose UI → ViewModel → Repository → Room/API → Ktor → PostgreSQL
                                              ↘ private object/file storage

PDF bytes never enter PostgreSQL. Annotation records reference exam/page and normalized positions.

## Run
Configure `backend/.env.example`, start PostgreSQL, then run the backend Gradle application.
Open `android/` in Android Studio and point `AppConfig.BASE_URL` to the backend.

## Important
The included home/archive data is safe demo data. The PDF reader expects licensed PDFs from the backend. Do not add copyrighted exam files without distribution rights.

## Final hardening
See `PRODUCTION_CHECKLIST.md` for identity provider, S3/MinIO signed URLs, migrations, rate limiting, antivirus/PDF validation, WorkManager constraints, tests and backup/restore requirements.
