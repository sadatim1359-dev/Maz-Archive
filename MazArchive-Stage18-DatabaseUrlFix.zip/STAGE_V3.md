# Stage 3 — Authentication & offline-sync hardening

Added:
- AuthStore abstraction for access token/role persistence.
- Retrofit auth endpoint contract.
- Bearer-token interceptor.
- API factory token injection.
- Annotation serialization helper for normalized page coordinates.
- WorkManager network constraint for future sync execution.
- BuildConfig-based API base URL.
- Login gate UI.
- Release-oriented acceptance checklist.

Important: the Login UI currently gates the UI locally; production must call AuthApi.login(), persist the returned token with AuthStore, and handle expiry/refresh before release.
