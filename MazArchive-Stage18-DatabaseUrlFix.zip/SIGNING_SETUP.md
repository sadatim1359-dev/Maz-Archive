# امضای ثابت Maz-Archive

این پروژه برای ساخت APK نسخه Release با کلید ثابت آماده شده است.

## مهم
- کلید خصوصی را داخل GitHub Repository قرار ندهید.
- فایل `mazarchive-release.jks` را خارج از Repository و در جای امن نگهداری کنید.
- برای نصب روی نسخه قبلی که با امضای دیگری ساخته شده، احتمالاً یک بار حذف و نصب مجدد لازم است.

## Secrets موردنیاز GitHub

در مسیر Settings → Secrets and variables → Actions این چهار Secret را بسازید:

- `SIGNING_STORE_BASE64`: خروجی Base64 فایل keystore
- `SIGNING_STORE_PASSWORD`: رمز keystore
- `SIGNING_KEY_ALIAS`: مقدار `mazarchive`
- `SIGNING_KEY_PASSWORD`: رمز کلید

برای تبدیل فایل به Base64 در Linux/macOS:

```bash
base64 -w 0 mazarchive-release.jks > keystore.base64.txt
```

در macOS اگر `-w` پشتیبانی نشد:

```bash
base64 mazarchive-release.jks | tr -d '\n' > keystore.base64.txt
```

مقدار فایل `keystore.base64.txt` را به عنوان Secret `SIGNING_STORE_BASE64` ثبت کنید.
