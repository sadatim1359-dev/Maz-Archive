# Fix4 Interactive Implementation

This package is based directly on the uploaded `MazArchive-Fix4.zip`.

The Android exam flow now opens an in-app interactive exam instead of the PDF route. The backend also contains question CRUD endpoints for admin use.

The Android player currently uses bundled sample questions so the UI/flow can be tested without a live backend. Backend question endpoints are prepared for the next API wiring step.
