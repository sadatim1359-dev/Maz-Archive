# Maz-Archive Stage 4

- Preserves Stage 2 persistent theme changes.
- Preserves Stage 3 real archive API loading and filters.
- Replaced hardcoded exam detail content with live `GET /exams/{id}` data.
- Added loading, retry, and error states to the exam detail screen.
- No changes to Render environment variables or `ADMIN_PASSWORD`.
- Android build still needs verification in GitHub Actions because this workspace has no Gradle wrapper/installed Gradle.
