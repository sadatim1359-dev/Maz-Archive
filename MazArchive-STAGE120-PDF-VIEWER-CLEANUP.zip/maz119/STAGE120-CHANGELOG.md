# Stage 120 — PDF Viewer Cleanup

- Removed the duplicated bottom page-count badge from the PDF viewer.
- Kept the page count in the top control bar.
- No OCR or question extraction was introduced.
- Android Gradle compilation was not run in this environment; run GitHub Actions before installing.
