package com.mazarchive

import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.*
import io.ktor.server.auth.*
import io.ktor.server.auth.jwt.*
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.http.content.staticResources
import io.ktor.serialization.kotlinx.json.json
import io.ktor.utils.io.jvm.javaio.toInputStream
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.javatime.*
import java.io.File
import org.apache.pdfbox.Loader
import org.apache.pdfbox.text.PDFTextStripper
import org.apache.pdfbox.text.TextPosition
import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.util.Base64
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object Exams : Table("exams") {
    val id = long("id").autoIncrement()
    val title = text("title")
    val grade = text("grade")
    val field = text("field")
    val examNumber = integer("exam_number").nullable()
    val examDate = date("exam_date")
    val year = integer("year")
    val period = text("period")
    val month = text("month")
    val description = text("description").default("")
    val pdfUrl = text("pdf_url")
    val durationSeconds = integer("duration_seconds").default(1800)
    val createdAt = timestamp("created_at")
    val updatedAt = timestamp("updated_at")
    override val primaryKey = PrimaryKey(id)
}

object Questions : Table("questions") {
    val id = long("id").autoIncrement()
    val examId = long("exam_id").references(Exams.id, onDelete = ReferenceOption.CASCADE)
    val number = integer("number")
    val text = text("question_text")
    val options = text("options_json")
    val correctIndex = integer("correct_index").nullable()
    val createdAt = timestamp("created_at")
    val updatedAt = timestamp("updated_at")
    override val primaryKey = PrimaryKey(id)
}


object ExamAttempts : Table("exam_attempts") {
    val id = long("id").autoIncrement()
    val userKey = text("user_key")
    val examId = long("exam_id").references(Exams.id, onDelete = ReferenceOption.CASCADE)
    val correct = integer("correct")
    val wrong = integer("wrong")
    val unanswered = integer("unanswered")
    val total = integer("total")
    val percent = float("percent")
    val usedSeconds = integer("used_seconds")
    val submittedByTime = bool("submitted_by_time")
    val createdAt = timestamp("created_at")
    override val primaryKey = PrimaryKey(id)
}

object Annotations : Table("annotations") {
    val id = uuid("id")
    val userId = uuid("user_id")
    val examId = long("exam_id")
    val pageNumber = integer("page_number")
    val type = text("type")
    val content = text("content").nullable()
    val position = text("position")
    val color = text("color")
    val thickness = float("thickness")
    val createdAt = timestamp("created_at")
    val updatedAt = timestamp("updated_at")
    override val primaryKey = PrimaryKey(id)
}

@Serializable data class ExamDto(
    val id: Long = 0, val title: String, val grade: String, val field: String,
    val examNumber: Int? = null, val examDate: String, val year: Int,
    val period: String, val month: String, val description: String = "",
    val pdfUrl: String = "", val durationSeconds: Int = 1800
)

@Serializable data class QuestionDto(
    val id: Long = 0, val examId: Long, val number: Int, val text: String,
    val options: List<String>, val correctIndex: Int? = null, val imageUrl: String? = null,
    val createdAt: String = "", val updatedAt: String = ""
)

@Serializable data class AnnotationDto(
    val id: String, val user_id: String, val exam_id: Long, val page_number: Int,
    val type: String, val content: String? = null, val position: String,
    val color: String, val thickness: Float, val created_at: String = "",
    val updated_at: String = ""
)

@Serializable data class Login(val username: String, val password: String)
@Serializable data class AttemptRequest(val examId: Long, val correct: Int, val wrong: Int, val unanswered: Int, val total: Int, val percent: Float, val usedSeconds: Int, val submittedByTime: Boolean = false)
@Serializable data class AttemptDto(val id: Long, val examId: Long, val correct: Int, val wrong: Int, val unanswered: Int, val total: Int, val percent: Float, val usedSeconds: Int, val submittedByTime: Boolean, val createdAt: String)

@Serializable
data class PdfExtractionSummary(
    val pages: Int,
    val extractedCharacters: Int,
    val detectedQuestionNumbers: List<Int>,
    val needsReview: Boolean = true,
    val message: String = "استخراج اولیه انجام شد؛ بررسی مدیر لازم است."
)


/** Rebuilds PDF text using glyph positions to reduce RTL/layout corruption. */
private class LayoutAwareStripper : PDFTextStripper() {
    init { sortByPosition = true; addMoreFormatting = false }

    override fun writeString(text: String, textPositions: List<TextPosition>) {
        if (textPositions.isEmpty()) {
            super.writeString(text)
            return
        }
        val rtl = textPositions.map { it.unicode }.count { ch ->
            ch.any { it in '\u0590'..'\u08FF' }
        } > textPositions.size / 2
        val ordered = if (rtl) textPositions.sortedByDescending { it.xDirAdj }
        else textPositions.sortedBy { it.xDirAdj }
        val rebuilt = ordered.joinToString("") { it.unicode }
        super.writeString(if (rebuilt.isBlank()) text else rebuilt)
    }
}

fun extractPdfSummary(file: File): PdfExtractionSummary {
    Loader.loadPDF(file).use { document ->
        val stripper = LayoutAwareStripper()
        val allText = buildString {
            for (page in 1..document.numberOfPages) {
                stripper.startPage = page
                stripper.endPage = page
                append(stripper.getText(document))
                append("\n")
            }
        }
        val detected = Regex("(?m)^\\s*[-−]?\\s*(\\d{1,3})\\s+")
            .findAll(allText)
            .mapNotNull { it.groupValues.getOrNull(1)?.toIntOrNull() }
            .filter { it in 1..300 }
            .distinct()
            .sorted()
            .toList()
        return PdfExtractionSummary(
            pages = document.numberOfPages,
            extractedCharacters = allText.length,
            detectedQuestionNumbers = detected
        )
    }
}

@Serializable
data class ExtractedQuestionCandidate(
    val number: Int,
    val text: String,
    val options: List<String>,
    val correctIndex: Int = -1,
    val needsReview: Boolean = true
)

@Serializable
data class PdfQuestionExtraction(
    val pages: Int,
    val questions: List<ExtractedQuestionCandidate>,
    val warnings: List<String> = emptyList()
)

fun extractPdfQuestions(file: File): PdfQuestionExtraction {
    Loader.loadPDF(file).use { document ->
        val stripper = LayoutAwareStripper()
        val pageTexts = (1..document.numberOfPages).map { page ->
            stripper.startPage = page
            stripper.endPage = page
            stripper.getText(document)
        }
        fun markerText(value: String): String = value
            .replace(Regex("[\\u200C\\u200D\\u200E\\u200F\\u202A-\\u202E\\u2066-\\u2069\\uFEFF]"), "")
            .replace(Regex("\\s+"), "")
        val firstAnswerPage = pageTexts.indexOfFirst { text ->
            val normalized = markerText(text)
            normalized.contains("دفترچهپاسخ") || normalized.contains("پاسخنامه")
        }.let { index -> if (index >= 0) index + 1 else null }
        val questionEndPage = (firstAnswerPage?.minus(1) ?: document.numberOfPages)
        val lines = mutableListOf<String>()
        pageTexts.take(questionEndPage).forEach { pageText ->
            pageText.lineSequence().map { it.trim() }
                .filter { it.isNotBlank() }.forEach { lines += it }
        }
        fun normalizeDigits(value: String): String {
            val mapped = value.map { ch ->
                when (ch) {
                    in '\u06F0'..'\u06F9' -> ('0'.code + (ch.code - '\u06F0'.code)).toChar()
                    in '\u0660'..'\u0669' -> ('0'.code + (ch.code - '\u0660'.code)).toChar()
                    '\u200C', '\u200D', '\u200E', '\u200F', '\u202A', '\u202B', '\u202C', '\u202D', '\u202E' -> ' '
                    else -> ch
                }
            }.joinToString("")
            return mapped.replace(Regex("\\s+"), " ").trim()
        }
        val starts = Regex("^(?:سؤال\\s*)?([0-9]{1,3})\\s*[\\)\\.\\-:]\\s*(.*)$")
        val option = Regex("^(?:[\\(\\[]?([1-4]|[الفبج\\u062f])[\\)\\].:-]?|([1-4])[\\.\\-:])\\s*(.+)$")
        val chunks = mutableListOf<Pair<Int, MutableList<String>>>()
        var current: Pair<Int, MutableList<String>>? = null
        for (rawLine in lines) {
            val line = normalizeDigits(rawLine)
            val m = starts.find(line)
            if (m != null) {
                current?.let { chunks += it }
                current = m.groupValues[1].toInt() to mutableListOf(m.groupValues[2])
            } else current?.second?.add(line)
        }
        current?.let { chunks += it }
        val result = chunks.mapNotNull { (number, content) ->
            val optionIndexes = content.mapIndexedNotNull { index, line -> if (option.matches(line)) index else null }
            if (optionIndexes.size < 2) return@mapNotNull null
            val firstOption = optionIndexes.first()
            val text = content.take(firstOption).joinToString(" ").trim()
            val options = optionIndexes.mapIndexed { i, start ->
                val end = optionIndexes.getOrNull(i + 1) ?: content.size
                content.subList(start, end).joinToString(" ").let { block ->
                    option.find(block)?.groupValues?.lastOrNull()?.trim() ?: block.trim()
                }
            }.take(4)
            if (text.isBlank() || options.size < 2) null
            else ExtractedQuestionCandidate(number, text, options, -1, true)
        }.distinctBy { it.number }.sortedBy { it.number }
        val warnings = buildList {
            if (result.isEmpty()) add("هیچ سؤال قابل تشخیصی پیدا نشد؛ قالب PDF باید در پنل بررسی شود.")
            if (result.any { it.options.size != 4 }) add("برخی سؤال‌ها چهار گزینه کامل ندارند و نیازمند بررسی هستند.")
            add("پاسخ صحیح عمداً به‌صورت نیازمند بررسی ثبت شده است؛ از حدس‌زدن پاسخ جلوگیری می‌شود.")
        }
        return PdfQuestionExtraction(document.numberOfPages, result, warnings)
    }
}

@Serializable data class Token(val token: String, val role: String)

private val jsonCodec = Json { ignoreUnknownKeys = true }

fun questionDto(row: ResultRow) = QuestionDto(
    id = row[Questions.id], examId = row[Questions.examId], number = row[Questions.number],
    text = row[Questions.text], options = jsonCodec.decodeFromString(row[Questions.options]),
    correctIndex = row[Questions.correctIndex], createdAt = row[Questions.createdAt].toString(),
    updatedAt = row[Questions.updatedAt].toString()
)

fun examDto(row: ResultRow) = ExamDto(
    id = row[Exams.id], title = row[Exams.title], grade = row[Exams.grade], field = row[Exams.field],
    examNumber = row[Exams.examNumber], examDate = row[Exams.examDate].toString(), year = row[Exams.year],
    period = row[Exams.period], month = row[Exams.month], description = row[Exams.description],
    pdfUrl = row[Exams.pdfUrl], durationSeconds = row[Exams.durationSeconds]
)

fun annotationDto(row: ResultRow) = AnnotationDto(
    id = row[Annotations.id].toString(), user_id = row[Annotations.userId].toString(),
    exam_id = row[Annotations.examId], page_number = row[Annotations.pageNumber], type = row[Annotations.type],
    content = row[Annotations.content], position = row[Annotations.position], color = row[Annotations.color],
    thickness = row[Annotations.thickness], created_at = row[Annotations.createdAt].toString(),
    updated_at = row[Annotations.updatedAt].toString()
)

object DevRefreshTokens : MutableMap<String, Pair<String, String>> by java.util.concurrent.ConcurrentHashMap()

object JwtAuth {
    private val secret = System.getenv("JWT_SECRET") ?: "CHANGE_ME"
    fun token(subject: String, role: String): String {
        val header = Base64.getUrlEncoder().withoutPadding().encodeToString("""{"alg":"HS256","typ":"JWT"}""".toByteArray())
        val now = java.time.Instant.now().epochSecond
        val expiresAt = now + 24 * 60 * 60
        val payloadJson = """{"sub":"$subject","role":"$role","iat":$now,"exp":$expiresAt}"""
        val payload = Base64.getUrlEncoder().withoutPadding().encodeToString(payloadJson.toByteArray())
        val data = "$header.$payload"
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(), "HmacSHA256"))
        val signature = Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(data.toByteArray()))
        return "$data.$signature"
    }
    val verifier = JWT.require(Algorithm.HMAC256(secret)).build()
}

fun main() {
    embeddedServer(Netty, port = System.getenv("PORT")?.toInt() ?: 8080, host = "0.0.0.0") {
        module()
    }.start(wait = true)
}

fun Application.module() {
    // Supports both a normal JDBC URL and Supabase's postgresql:// connection string.
    // Prefer explicit DB_USER/DB_PASSWORD when provided; otherwise read credentials
    // from DATABASE_URL without logging them.
    val configuredUrl = System.getenv("DATABASE_URL")
        ?: "jdbc:postgresql://localhost:5432/mazarchive"

    // PostgreSQL JDBC does not accept Supabase credentials embedded in the host part.
    // Extract credentials from the URI and build a clean JDBC URL containing only host/port/path.
    val uriValue = if (configuredUrl.startsWith("jdbc:")) {
        configuredUrl.removePrefix("jdbc:")
    } else {
        configuredUrl
    }

    val parsedUri = runCatching { URI(uriValue) }.getOrNull()
    val urlUserInfo = parsedUri?.userInfo
    val urlUser = urlUserInfo?.substringBefore(":")?.let {
        URLDecoder.decode(it, StandardCharsets.UTF_8)
    }
    val urlPassword = urlUserInfo?.substringAfter(":", "")?.let {
        URLDecoder.decode(it, StandardCharsets.UTF_8)
    }

    val jdbcUrl = if (parsedUri?.host != null) {
        val port = if (parsedUri.port != -1) ":${parsedUri.port}" else ""
        val path = parsedUri.rawPath.orEmpty().ifBlank { "/postgres" }
        val query = parsedUri.rawQuery?.let { "?$it" } ?: ""
        "jdbc:postgresql://${parsedUri.host}$port$path$query"
    } else if (configuredUrl.startsWith("jdbc:")) {
        configuredUrl
    } else {
        "jdbc:$configuredUrl"
    }

    val dbUser = System.getenv("DB_USER") ?: urlUser ?: "postgres"
    val dbPassword = System.getenv("DB_PASSWORD") ?: urlPassword ?: "postgres"

    Database.connect(
        url = jdbcUrl,
        driver = "org.postgresql.Driver",
        user = dbUser,
        password = dbPassword
    )
    transaction {
        SchemaUtils.create(Exams, Questions, Annotations, ExamAttempts)
        exec("ALTER TABLE exams ADD COLUMN IF NOT EXISTS description TEXT NOT NULL DEFAULT ''")
        exec("ALTER TABLE exams ADD COLUMN IF NOT EXISTS duration_seconds INTEGER NOT NULL DEFAULT 1800")
    }
    install(ContentNegotiation) { json() }
    install(Authentication) {
        jwt("auth") {
            verifier(JwtAuth.verifier)
            validate { principal -> if (principal.payload.subject != null) JWTPrincipal(principal.payload) else null }
        }
    }
    routing {
        staticResources("/admin", "web")
        get("/health") { call.respond(mapOf("status" to "ok")) }

        authenticate("auth") {
            get("/attempts") {
                val userKey = call.principal<JWTPrincipal>()!!.payload.subject
                val rows = transaction { ExamAttempts.selectAll().where { ExamAttempts.userKey eq userKey }.orderBy(ExamAttempts.createdAt, SortOrder.DESC).map {
                    AttemptDto(it[ExamAttempts.id], it[ExamAttempts.examId], it[ExamAttempts.correct], it[ExamAttempts.wrong], it[ExamAttempts.unanswered], it[ExamAttempts.total], it[ExamAttempts.percent], it[ExamAttempts.usedSeconds], it[ExamAttempts.submittedByTime], it[ExamAttempts.createdAt].toString())
                } }
                call.respond(rows)
            }
            post("/attempts") {
                val userKey = call.principal<JWTPrincipal>()!!.payload.subject
                val body = call.receive<AttemptRequest>()
                if (body.total <= 0 || body.correct < 0 || body.wrong < 0 || body.unanswered < 0 || body.correct + body.wrong + body.unanswered != body.total || body.percent !in 0f..100f) {
                    call.respond(HttpStatusCode.BadRequest, "اطلاعات کارنامه نامعتبر است"); return@post
                }
                val id = transaction { ExamAttempts.insert {
                    it[ExamAttempts.userKey] = userKey
                    it[ExamAttempts.examId] = body.examId
                    it[ExamAttempts.correct] = body.correct
                    it[ExamAttempts.wrong] = body.wrong
                    it[ExamAttempts.unanswered] = body.unanswered
                    it[ExamAttempts.total] = body.total
                    it[ExamAttempts.percent] = body.percent
                    it[ExamAttempts.usedSeconds] = body.usedSeconds
                    it[ExamAttempts.submittedByTime] = body.submittedByTime
                    it[ExamAttempts.createdAt] = Instant.now()
                } get ExamAttempts.id }
                call.respond(HttpStatusCode.Created, mapOf("id" to id))
            }
        }

        post("/auth/login") {
            val body = call.receive<Login>()
            val isAdmin = body.username == "admin" && body.password == (System.getenv("ADMIN_PASSWORD") ?: "change-me")
            if (!isAdmin) {
                call.respond(status = HttpStatusCode.Unauthorized, message = "نام کاربری یا رمز عبور نامعتبر است")
                return@post
            }
            val role = "ADMIN"
            val refresh = UUID.randomUUID().toString()
            DevRefreshTokens[refresh] = body.username to role
            call.respond(mapOf("token" to JwtAuth.token(body.username, role), "role" to role, "refreshToken" to refresh))
        }

        post("/auth/refresh") {
            val body = call.receive<Map<String, String>>()
            val refresh = body["refreshToken"]
            if (refresh == null) {
                call.respond(HttpStatusCode.BadRequest)
                return@post
            }
            val entry = DevRefreshTokens[refresh]
            if (entry == null) {
                call.respond(HttpStatusCode.Unauthorized)
                return@post
            }
            call.respond(Token(JwtAuth.token(entry.first, entry.second), entry.second))
        }

        authenticate("auth") {
            get("/exams") {
                val grade = call.request.queryParameters["grade"]
                val field = call.request.queryParameters["field"]
                val year = call.request.queryParameters["year"]?.toIntOrNull()
                val period = call.request.queryParameters["period"]
                val month = call.request.queryParameters["month"]
                val query = call.request.queryParameters["q"]?.trim()
                val conditions = listOfNotNull(
                    grade?.let { Exams.grade eq it }, field?.let { Exams.field eq it },
                    year?.let { Exams.year eq it }, period?.let { Exams.period eq it },
                    month?.let { Exams.month eq it }, query?.takeIf { it.isNotEmpty() }?.let { Exams.title eq it }
                )
                val rows = transaction {
                    if (conditions.isEmpty()) {
                        Exams.selectAll().orderBy(Exams.examDate, SortOrder.DESC).map(::examDto)
                    } else {
                        val predicate = conditions.drop(1).fold(conditions.first()) { acc, condition ->
                            Op.build { acc and condition }
                        }
                        Exams.selectAll().where { predicate }.orderBy(Exams.examDate, SortOrder.DESC).map(::examDto)
                    }
                }
                call.respond(rows)
            }

            get("/exams/{id}") {
                val id = call.parameters["id"]!!.toLong()
                val row = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull() }
                if (row == null) call.respond(HttpStatusCode.NotFound) else call.respond(examDto(row))
            }

            get("/exams/{id}/questions") {
                val id = call.parameters["id"]!!.toLong()
                val rows = transaction { Questions.selectAll().where { Questions.examId eq id }.orderBy(Questions.number).map(::questionDto) }
                call.respond(rows)
            }

            get("/exams/{id}/pdf") {
                val id = call.parameters["id"]!!.toLong()
                val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                if (path == null) { call.respond(HttpStatusCode.NotFound); return@get }
                val root = File(System.getenv("STORAGE_DIR") ?: "./storage")
                val file = File(path)
                if (!file.canonicalPath.startsWith(root.canonicalPath)) { call.respond(HttpStatusCode.Forbidden); return@get }
                if (!file.exists()) { call.respond(HttpStatusCode.NotFound); return@get }
                call.respondFile(file)
            }

            get("/exams/{id}/annotations") {
                val id = call.parameters["id"]!!.toLong()
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                val rows = transaction { Annotations.selectAll().where { (Annotations.examId eq id) and (Annotations.userId eq uid) }.map(::annotationDto) }
                call.respond(rows)
            }

            post("/exams/{id}/annotations") {
                val id = call.parameters["id"]!!.toLong()
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                val annotation = call.receive<AnnotationDto>()
                val annotationId = UUID.fromString(annotation.id)
                transaction {
                    Annotations.insert {
                        it[Annotations.id] = annotationId; it[userId] = uid; it[examId] = id
                        it[pageNumber] = annotation.page_number; it[type] = annotation.type; it[content] = annotation.content
                        it[position] = annotation.position; it[color] = annotation.color; it[thickness] = annotation.thickness
                        it[createdAt] = Instant.now(); it[updatedAt] = Instant.now()
                    }
                }
                call.respond(status = HttpStatusCode.Created, message = annotation.copy(user_id = uid.toString()))
            }

            put("/annotations/{id}") {
                val annotationId = UUID.fromString(call.parameters["id"]!!)
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                val annotation = call.receive<AnnotationDto>()
                transaction {
                    Annotations.update({ (Annotations.id eq annotationId) and (Annotations.userId eq uid) }) {
                        it[position] = annotation.position; it[color] = annotation.color; it[thickness] = annotation.thickness
                        it[content] = annotation.content; it[updatedAt] = Instant.now()
                    }
                }
                call.respond(annotation)
            }

            delete("/annotations/{id}") {
                val annotationId = UUID.fromString(call.parameters["id"]!!)
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                transaction { Annotations.deleteWhere { (Annotations.id eq annotationId) and (Annotations.userId eq uid) } }
                call.respond(HttpStatusCode.NoContent)
            }

            route("/admin") {
                suspend fun ApplicationCall.requireAdmin(): Boolean {
                    val isAdmin = principal<JWTPrincipal>()?.payload?.getClaim("role")?.asString() == "ADMIN"
                    if (!isAdmin) respond(status = HttpStatusCode.Forbidden, message = "دسترسی مدیر لازم است")
                    return isAdmin
                }

                get("/exams") {
                    if (!call.requireAdmin()) return@get
                    val rows = transaction { Exams.selectAll().orderBy(Exams.examDate, SortOrder.DESC).map(::examDto) }
                    call.respond(rows)
                }
                get("/stats") {
                    if (!call.requireAdmin()) return@get
                    val rows = transaction { Exams.selectAll().toList() }
                    call.respond(mapOf("total" to rows.size, "withPdf" to rows.count { it[Exams.pdfUrl].isNotBlank() }, "withoutPdf" to rows.count { it[Exams.pdfUrl].isBlank() }))
                }
                post("/exams") {
                    if (!call.requireAdmin()) return@post
                    val exam = call.receive<ExamDto>()
                    val newId = transaction {
                        Exams.insert {
                            it[title] = exam.title; it[grade] = exam.grade; it[field] = exam.field; it[examNumber] = exam.examNumber
                            it[examDate] = java.time.LocalDate.parse(exam.examDate); it[year] = exam.year; it[period] = exam.period
                            it[month] = exam.month; it[description] = exam.description; it[pdfUrl] = exam.pdfUrl
                            it[durationSeconds] = exam.durationSeconds; it[createdAt] = Instant.now(); it[updatedAt] = Instant.now()
                        } get Exams.id
                    }
                    call.respond(status = HttpStatusCode.Created, message = exam.copy(id = newId))
                }
                put("/exams/{id}") {
                    if (!call.requireAdmin()) return@put
                    val id = call.parameters["id"]!!.toLong(); val exam = call.receive<ExamDto>()
                    transaction {
                        Exams.update({ Exams.id eq id }) {
                            it[title] = exam.title; it[grade] = exam.grade; it[field] = exam.field; it[examNumber] = exam.examNumber
                            it[examDate] = java.time.LocalDate.parse(exam.examDate); it[year] = exam.year; it[period] = exam.period
                            it[month] = exam.month; it[description] = exam.description; it[durationSeconds] = exam.durationSeconds
                            it[updatedAt] = Instant.now()
                        }
                    }
                    call.respond(exam)
                }
                delete("/exams/{id}") {
                    if (!call.requireAdmin()) return@delete
                    transaction { Exams.deleteWhere { Exams.id eq call.parameters["id"]!!.toLong() } }
                    call.respond(HttpStatusCode.NoContent)
                }
                get("/exams/{id}/questions") {
                    if (!call.requireAdmin()) return@get
                    val examId = call.parameters["id"]!!.toLong()
                    val rows = transaction { Questions.selectAll().where { Questions.examId eq examId }.orderBy(Questions.number).map(::questionDto) }
                    call.respond(rows)
                }
                post("/exams/{id}/questions") {
                    if (!call.requireAdmin()) return@post
                    val examId = call.parameters["id"]!!.toLong(); val question = call.receive<QuestionDto>()
                    if (question.options.size < 2 || (question.correctIndex != null && question.correctIndex !in question.options.indices)) {
                        call.respond(status = HttpStatusCode.BadRequest, message = "گزینه‌ها یا پاسخ صحیح نامعتبر است"); return@post
                    }
                    val duplicate = transaction {
                        Questions.selectAll().where { (Questions.examId eq examId) and (Questions.number eq question.number) }.count()
                    }
                    if (duplicate > 0) {
                        call.respond(HttpStatusCode.Conflict, "این شماره سؤال قبلاً برای این آزمون ثبت شده است؛ از ویرایش استفاده کنید"); return@post
                    }
                    val newId = transaction {
                        Questions.insert {
                            it[Questions.examId] = examId; it[number] = question.number; it[text] = question.text
                            it[options] = jsonCodec.encodeToString(ListSerializer(String.serializer()), question.options); it[correctIndex] = question.correctIndex
                            it[createdAt] = Instant.now(); it[updatedAt] = Instant.now()
                        } get Questions.id
                    }
                    call.respond(status = HttpStatusCode.Created, message = question.copy(id = newId, examId = examId))
                }
                put("/exams/{examId}/questions/{id}") {
                    if (!call.requireAdmin()) return@put
                    val examId = call.parameters["examId"]!!.toLong(); val id = call.parameters["id"]!!.toLong(); val question = call.receive<QuestionDto>()
                    if (question.options.size < 2 || (question.correctIndex != null && question.correctIndex !in question.options.indices)) {
                        call.respond(status = HttpStatusCode.BadRequest, message = "گزینه‌ها یا پاسخ صحیح نامعتبر است"); return@put
                    }
                    val duplicate = transaction {
                        Questions.selectAll().where { (Questions.examId eq examId) and (Questions.number eq question.number) and (Questions.id neq id) }.count()
                    }
                    if (duplicate > 0) {
                        call.respond(HttpStatusCode.Conflict, "این شماره سؤال قبلاً برای سؤال دیگری ثبت شده است"); return@put
                    }
                    val updated = transaction {
                        Questions.update({ (Questions.id eq id) and (Questions.examId eq examId) }) {
                            it[number] = question.number; it[text] = question.text; it[options] = jsonCodec.encodeToString(ListSerializer(String.serializer()), question.options)
                            it[correctIndex] = question.correctIndex; it[updatedAt] = Instant.now()
                        }
                    }
                    if (updated == 0) {
                        call.respond(HttpStatusCode.NotFound, "سؤال پیدا نشد"); return@put
                    }
                    call.respond(question.copy(id = id, examId = examId))
                }
                delete("/exams/{examId}/questions/{id}") {
                    if (!call.requireAdmin()) return@delete
                    val examId = call.parameters["examId"]!!.toLong(); val id = call.parameters["id"]!!.toLong()
                    transaction { Questions.deleteWhere { (Questions.id eq id) and (Questions.examId eq examId) } }
                    call.respond(HttpStatusCode.NoContent)
                }
                get("/exams/{id}/pdf/extraction-summary") {
                    if (!call.requireAdmin()) return@get
                    val id = call.parameters["id"]!!.toLong()
                    val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                    if (path.isNullOrBlank()) { call.respond(HttpStatusCode.NotFound, "برای این آزمون PDF ثبت نشده است"); return@get }
                    val file = File(path)
                    if (!file.exists()) { call.respond(HttpStatusCode.NotFound, "فایل PDF روی سرور پیدا نشد"); return@get }
                    val extraction = runCatching { extractPdfSummary(file) }.getOrElse { error ->
                        call.respond(HttpStatusCode.UnprocessableEntity, "استخراج PDF ناموفق بود: ${error.message ?: "خطای نامشخص"}")
                        return@get
                    }
                    call.respond(extraction)
                }
                get("/exams/{id}/pdf/extracted-questions") {
                    if (!call.requireAdmin()) return@get
                    val id = call.parameters["id"]!!.toLong()
                    val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                    if (path.isNullOrBlank()) { call.respond(HttpStatusCode.NotFound, "برای این آزمون PDF ثبت نشده است"); return@get }
                    val file = File(path)
                    if (!file.exists()) { call.respond(HttpStatusCode.NotFound, "فایل PDF روی سرور پیدا نشد"); return@get }
                    val extraction = runCatching { extractPdfQuestions(file) }.getOrElse { error ->
                        call.respond(HttpStatusCode.UnprocessableEntity, "استخراج سؤال‌ها ناموفق بود: ${error.message ?: "خطای نامشخص"}")
                        return@get
                    }
                    call.respond(extraction)
                }
                post("/exams/{id}/pdf") {
                    if (!call.requireAdmin()) return@post
                    val id = call.parameters["id"]!!.toLong()
                    val receivedType = call.request.contentType()?.toString() ?: "none"
                    val root = File(System.getenv("STORAGE_DIR") ?: "./storage")
                    val target = File(root, "exams/$id.pdf")
                    target.parentFile.mkdirs()
                    call.receiveChannel().toInputStream().use { input -> target.outputStream().use { output -> input.copyTo(output) } }
                    val size = target.length()
                    val magic = target.inputStream().use { it.readNBytes(5) }
                    if (!magic.contentEquals(byteArrayOf(0x25, 0x50, 0x44, 0x46, 0x2D))) {
                        target.delete()
                        call.respond(HttpStatusCode.BadRequest, "Invalid PDF: size=$size contentType=$receivedType header=${magic.joinToString()}")
                        return@post
                    }
                    val extraction = runCatching { extractPdfSummary(target) }.getOrElse { error ->
                        call.respond(HttpStatusCode.UnprocessableEntity, "استخراج PDF ناموفق بود: ${error.message ?: "خطای نامشخص"}")
                        return@post
                    }
                    transaction { Exams.update({ Exams.id eq id }) { it[pdfUrl] = target.absolutePath; it[updatedAt] = Instant.now() } }
                    call.respond(mapOf("ok" to true, "extraction" to extraction))
                }
            }
        }
    }
}
