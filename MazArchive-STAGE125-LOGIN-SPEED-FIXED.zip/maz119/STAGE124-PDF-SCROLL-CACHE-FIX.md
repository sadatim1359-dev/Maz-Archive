# Stage 124 — PDF Scroll/Reload Performance Fix

## Changes
- Added an in-memory `LruCache` for rendered PDF page bitmaps.
- Added stable LazyColumn keys for PDF pages.
- Reuses cached page bitmaps when the user scrolls away and returns.
- Reduced render width from 1200px to 1000px to lower bitmap memory and render cost.

## Verification
- Static source inspection completed.
- Android/Gradle build was not run in this environment.
- Test the APK through GitHub Actions before installing.
