# Stage 125 — Login Speed Optimization

## Changes
- Reuse one `AuthApi` instance during the app session instead of creating a new Retrofit service for each login/register/health request.
- Cache `AuthApi` services by base URL inside `AuthApiFactory`.
- Reuse the same OkHttp client and connection pool for the warm-up and authentication requests.
- Preserve existing login, registration, duplicate-account (409), and admin flows.

## Verification
- Static source review completed.
- Android Gradle build was not executed in this environment; verify through GitHub Actions before installing.
