# Stage 87 — Dark Text Contrast Fix

- Fixed dark theme Material color scheme so default text uses a light, readable color.
- Set explicit `onBackground`, `onSurface`, `onSurfaceVariant`, and `onPrimary` colors.
- This prevents headings and card metadata from rendering black on dark backgrounds.
- Existing timer, manual finish, answer key, PDF, question count, and duration features are preserved.
