# Stage 104 — Speed Optimization (initial pass)

Changes:
- Reduced the fixed splash delay from 2600ms to 900ms.
- Added a non-blocking `/health` warm-up request during splash to help wake Render before login/first API use.
- Added a shared OkHttp client for authentication requests with bounded timeouts and retry-on-connection-failure.

Limitations:
- Render cold-start latency cannot be guaranteed away from the Android client.
- This pass does not change BCrypt security or backend database logic.
- Android/GitHub Actions build must be run externally to confirm compilation.
