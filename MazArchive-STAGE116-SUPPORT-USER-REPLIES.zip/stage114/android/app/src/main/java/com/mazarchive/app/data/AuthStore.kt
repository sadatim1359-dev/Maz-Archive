package com.mazarchive.app.data

import android.content.Context
import androidx.core.content.edit

class AuthStore(context: Context) {
    private val prefs = context.getSharedPreferences("maz_auth", Context.MODE_PRIVATE)

    fun token(): String? = prefs.getString("access_token", null)
    fun role(): String? = prefs.getString("role", null)
    fun refreshToken(): String? = prefs.getString("refresh_token", null)

    fun save(token: String, role: String, refreshToken: String? = null) {
        prefs.edit {
            putString("access_token", token)
            putString("role", role)
            putBoolean("registered", true)
            if (refreshToken != null) putString("refresh_token", refreshToken)
        }
    }

    /** Clears only the active session. Registration state is preserved so
     * logging out returns an existing user to the login screen instead of
     * attempting a second registration (HTTP 409).
     */
    fun clear() {
        prefs.edit {
            remove("access_token")
            remove("refresh_token")
            remove("role")
        }
    }

    fun isLoggedIn() = !token().isNullOrBlank()

    fun isRegistered() = prefs.getBoolean("registered", false)

    fun registerLocal(username: String, password: String) {
        prefs.edit {
            putBoolean("registered", true)
            putString("username", username)
            putString("local_password", password)
            putString("access_token", "local-session")
            putString("role", "USER")
        }
    }

    fun checkLocalCredentials(username: String, password: String): Boolean =
        isRegistered() &&
            prefs.getString("username", null) == username &&
            prefs.getString("local_password", null) == password
}
