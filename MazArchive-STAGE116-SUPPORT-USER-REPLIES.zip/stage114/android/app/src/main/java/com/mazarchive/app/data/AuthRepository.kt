package com.mazarchive.app.data

import com.mazarchive.app.network.AuthApi
import com.mazarchive.app.network.LoginRequest
import com.mazarchive.app.network.RegisterRequest

data class Session(val accessToken:String,val refreshToken:String?,val role:String)
class AuthRepository(private val api:AuthApi, private val store:AuthStore){
    suspend fun login(username:String,password:String):Result<Session> = runCatching {
        val r=api.login(LoginRequest(username,password))
        Session(r.token,r.refreshToken,r.role).also{store.save(it.accessToken,it.role,it.refreshToken)}
    }
    suspend fun register(username:String,password:String):Result<Session> = runCatching {
        val r=api.register(RegisterRequest(username,password))
        Session(r.token,r.refreshToken,r.role).also{store.save(it.accessToken,it.role,it.refreshToken)}
    }
    fun session():Session?=store.token()?.let{Session(it, null, store.role()?:"USER")}
    fun logout(){store.clear()}
}
