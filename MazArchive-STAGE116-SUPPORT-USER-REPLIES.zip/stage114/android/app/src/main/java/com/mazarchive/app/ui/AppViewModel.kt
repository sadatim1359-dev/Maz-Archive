package com.mazarchive.app.ui
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mazarchive.app.Exam
import com.mazarchive.app.data.ExamRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job

data class ArchiveState(val loading:Boolean=false,val exams:List<Exam> = emptyList(),val error:String?=null)
class ArchiveViewModel(private val repo:ExamRepository):ViewModel(){
    private val _state=MutableStateFlow(ArchiveState()); val state:StateFlow<ArchiveState> = _state
    private var loadJob: Job? = null
    private var lastRequest: String? = null

    fun load(grade:String,field:String,q:String?=null) {
        val requestKey = "$grade|$field|${q.orEmpty()}"
        if (requestKey == lastRequest && _state.value.exams.isNotEmpty()) return
        lastRequest = requestKey
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _state.value=ArchiveState(loading=true)
            runCatching{repo.exams(grade,field,q=q)}
                .onSuccess{_state.value=ArchiveState(exams=it)}
                .onFailure{if (it !is kotlinx.coroutines.CancellationException) _state.value=ArchiveState(error=it.message)}
        }
    }
}
