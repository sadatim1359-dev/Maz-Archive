package com.mazarchive.app.data

import com.mazarchive.app.Exam
import com.mazarchive.app.AnnotationEntity
import com.mazarchive.app.AnnotationPayload
import com.mazarchive.app.network.MazApi
import com.mazarchive.app.MazDb
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.Instant

class ExamRepository(private val api:MazApi, private val db:MazDb) {
    private data class ExamsCacheEntry(val value: List<Exam>, val savedAtMs: Long)
    private val cacheMutex = Mutex()
    private val examsCache = LinkedHashMap<String, ExamsCacheEntry>()
    private val examCache = LinkedHashMap<Long, Pair<Exam, Long>>()
    private val cacheTtlMs = 60_000L

    private fun now() = System.currentTimeMillis()
    private fun examsKey(grade:String?, field:String?, year:Int?, period:String?, month:String?, q:String?) =
        listOf(grade, field, year, period, month, q).joinToString("|") { it?.toString() ?: "" }

    suspend fun exams(grade:String?=null,field:String?=null,year:Int?=null,period:String?=null,month:String?=null,q:String?=null): List<Exam> {
        val key = examsKey(grade, field, year, period, month, q)
        cacheMutex.withLock {
            examsCache[key]?.takeIf { now() - it.savedAtMs < cacheTtlMs }?.let { return it.value }
        }
        val fresh = api.exams(grade,field,year,period,month,q)
        cacheMutex.withLock {
            examsCache[key] = ExamsCacheEntry(fresh, now())
            while (examsCache.size > 12) examsCache.remove(examsCache.keys.first())
        }
        return fresh
    }

    suspend fun exam(id:Long): Exam {
        cacheMutex.withLock {
            examCache[id]?.takeIf { now() - it.second < cacheTtlMs }?.let { return it.first }
        }
        val fresh = api.exam(id)
        cacheMutex.withLock { examCache[id] = fresh to now() }
        return fresh
    }

    suspend fun invalidateCache() = cacheMutex.withLock {
        examsCache.clear()
        examCache.clear()
    }
    fun localAnnotations(examId:Long,userId:String):Flow<List<AnnotationEntity>> =
        kotlinx.coroutines.flow.flow { emit(db.annotations().byExam(examId,userId)) }
    suspend fun saveAnnotation(a:AnnotationEntity)=db.annotations().upsert(a)
    suspend fun syncPending() {
        db.annotations().pending().forEach { a ->
            runCatching {
                api.createAnnotation(a.examId,AnnotationPayload(
                    a.id,a.userId,a.examId,a.pageNumber,a.type,a.content,a.position,a.color,a.thickness,
                    Instant.now().toString(),Instant.now().toString()))
            }.onSuccess { db.annotations().markSynced(a.id) }
        }
    }
}
