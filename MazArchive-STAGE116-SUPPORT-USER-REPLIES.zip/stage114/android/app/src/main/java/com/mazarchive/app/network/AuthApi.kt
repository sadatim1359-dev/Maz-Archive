package com.mazarchive.app.network
import kotlinx.serialization.Serializable
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.GET
import okhttp3.MediaType.Companion.toMediaType
import kotlinx.serialization.json.Json
import retrofit2.converter.kotlinx.serialization.asConverterFactory

@Serializable data class LoginRequest(val username:String,val password:String)
@Serializable data class RegisterRequest(val username:String,val password:String)
@Serializable data class TokenResponse(val token:String,val role:String,val refreshToken:String?=null)
@Serializable data class RefreshRequest(val refreshToken:String)
interface AuthApi {
 @GET("health") suspend fun health(): Map<String, String>
 @POST("auth/login") suspend fun login(@Body request:LoginRequest):TokenResponse
 @POST("auth/register") suspend fun register(@Body request:RegisterRequest):TokenResponse
 @POST("auth/refresh") suspend fun refresh(@Body request:RefreshRequest):TokenResponse
}

object AuthApiFactory {
    private val client by lazy {
        okhttp3.OkHttpClient.Builder()
            .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
            .writeTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    fun create(baseUrl: String): AuthApi = retrofit2.Retrofit.Builder()
        .baseUrl(baseUrl)
        .client(client)
        .addConverterFactory(kotlinx.serialization.json.Json { ignoreUnknownKeys = true }.asConverterFactory("application/json".toMediaType()))
        .build().create(AuthApi::class.java)
}
