# Stage 96 — BCrypt build safeguard

- Kept the compact user-profile changes from Stage 95.
- Declared `at.favre.lib:bcrypt:0.10.2` explicitly in `backend/build.gradle.kts`.
- This dependency is required by `Application.kt` imports and BCrypt calls.
- The root Dockerfile builds directly from `backend/`; it does not extract an old ZIP during the Render build.

Important: the build was not executed in this environment because the Gradle executable is unavailable here. Run Render after committing this version and confirm the compile step.
