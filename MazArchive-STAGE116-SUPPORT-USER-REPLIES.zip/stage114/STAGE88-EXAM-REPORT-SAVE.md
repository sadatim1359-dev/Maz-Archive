# Stage 88 — Save Completed Exams in Report

- Every manual or automatic exam completion is saved in local exam history.
- The result is calculated using the backend answer key when available.
- The app attempts to synchronize the attempt with the backend `/attempts` endpoint.
- The report screen refreshes local history when opened.
- Existing timer, manual finish, answer key, PDF and contrast changes are preserved.

Note: Android Gradle build and live Render verification must still be run in GitHub/Render.
