# Stage 85 – Manual Exam Finish

- Added an `اتمام آزمون` button on the PDF screen.
- Added the same action on the answer-sheet screen.
- Added a confirmation dialog before final submission.
- Manual submission stops the timer and calculates used seconds from remaining time.
- Automatic submission at timeout remains supported.


## Stage 86 – Exam detail cleanup
- Removed duplicate «شروع دوباره آزمون» button.
- Added question count and duration metadata cards to exam details.
