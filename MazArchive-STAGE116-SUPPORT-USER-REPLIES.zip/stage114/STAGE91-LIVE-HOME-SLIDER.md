# Stage 91 — Live Home Slider

Implemented a server-driven home banner system for Maz-Archive.

## Backend
- Added `home_banners` table with notice/exam type, title, subtitle, optional image URL, optional exam ID, active flag and sort order.
- Added public `GET /home-banners` endpoint for active banners.
- Added admin CRUD endpoints under `/admin/home-banners`.
- Added safe startup table creation and SQL schema definition.

## Android
- Home screen loads active banners from the backend.
- Supports notice and exam-promotion banners.
- Optional remote image URL rendering.
- Exam banners can open the linked exam when an exam ID is provided.
- Admin panel includes banner management with title, subtitle, image URL, type, exam ID, order and active state.

## Verification
- ZIP integrity verified.
- Full Android/Gradle and live Render deployment tests require the GitHub/Render environment.
