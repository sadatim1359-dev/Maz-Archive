# Stage 93 — Independent User Accounts

- Added a persistent `users` table in PostgreSQL/Supabase.
- Added `/auth/register` with username validation and BCrypt password hashing.
- Extended `/auth/login` to authenticate regular users from the database while preserving the admin environment-password login.
- Added `last_login_at` tracking.
- Updated `/user-stats` to read registered users and real login activity.
- Updated Android registration and regular login to use the backend API instead of local-only credentials.
- The existing admin login remains based on `ADMIN_PASSWORD`.

Important: deploy the backend before testing registration in the Android app. Existing locally registered accounts are not automatically migrated to the server database.
