# Stage 92 — Live Home Dashboard

- Added public `/home-dashboard` endpoint.
- Added real total exam count and per-grade counts from the database.
- Added newest exams from the database.
- Added recommended exams from active EXAM banners.
- Added active notices from managed banners.
- Updated Android home screen to consume live dashboard data with fallback to banners.
- Preserved existing slider/admin banner functionality.
