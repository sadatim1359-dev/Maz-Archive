# Stage 108 — Support Admin

Implemented:
- `support_messages` table with ticket relation and index.
- User endpoint: `GET /support/tickets/{id}/messages` (owner-only).
- Admin endpoint: `GET /admin/support/tickets` with message thread.
- Admin endpoint: `POST /admin/support/tickets/{id}/messages` for replies.
- Admin endpoint: `PUT /admin/support/tickets/{id}/status` for OPEN, IN_PROGRESS, ANSWERED, CLOSED.
- Admin panel support page with list, thread, reply, and status controls.

The backend build could not be run in this environment because Gradle is not installed. Verify with the repository GitHub Actions workflow before deployment.
