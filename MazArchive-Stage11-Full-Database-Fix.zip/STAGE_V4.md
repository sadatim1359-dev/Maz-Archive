# Stage 4 — Authentication & API integration

Added:
- AuthRepository and session abstraction.
- Refresh-token API contract.
- Refresh-token persistence in AuthStore.
- Backend `/auth/refresh` development endpoint.
- ArchiveRepository with server-side query parameters.
- Explicit ArchiveUiState.
- Removed the need for a UI layer to know API details.

Production note:
The included refresh token store is intentionally development-only. For production, persist hashed, revocable refresh tokens in PostgreSQL with expiry, rotation and device/session metadata.
