CREATE TABLE IF NOT EXISTS exams (
 id BIGSERIAL PRIMARY KEY,title TEXT NOT NULL,grade TEXT NOT NULL CHECK(grade IN ('دهم','یازدهم','دوازدهم')),
 field TEXT NOT NULL CHECK(field IN ('ریاضی','تجربی','انسانی')),exam_number INTEGER NULL,exam_date DATE NOT NULL,
 year INTEGER NOT NULL,period TEXT NOT NULL CHECK(period IN ('تابستانه','شروع از مهر')),month TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',pdf_url TEXT NOT NULL DEFAULT '',duration_seconds INTEGER NOT NULL DEFAULT 1800 CHECK(duration_seconds > 0),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),updated_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS annotations (
 id UUID PRIMARY KEY,user_id UUID NOT NULL,exam_id BIGINT NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
 page_number INTEGER NOT NULL CHECK(page_number>=0),type TEXT NOT NULL,content TEXT,
 position JSONB NOT NULL,color TEXT NOT NULL,thickness REAL NOT NULL CHECK(thickness>0),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),updated_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS idx_exams_archive ON exams(grade,field,year,period,month,exam_date DESC);
CREATE INDEX IF NOT EXISTS idx_exams_search ON exams USING gin(to_tsvector('simple',title));
CREATE INDEX IF NOT EXISTS idx_annotations_user_exam ON annotations(user_id,exam_id,page_number);


CREATE TABLE IF NOT EXISTS questions (
 id BIGSERIAL PRIMARY KEY,
 exam_id BIGINT NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
 number INTEGER NOT NULL CHECK(number > 0),
 question_text TEXT NOT NULL,
 options_json JSONB NOT NULL,
 correct_index INTEGER NOT NULL CHECK(correct_index >= 0),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(exam_id, number)
);
CREATE INDEX IF NOT EXISTS idx_questions_exam ON questions(exam_id, number);
