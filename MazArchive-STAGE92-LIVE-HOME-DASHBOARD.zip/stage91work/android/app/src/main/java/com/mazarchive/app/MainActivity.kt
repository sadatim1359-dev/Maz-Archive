package com.mazarchive.app

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.graphics.BitmapFactory
import java.net.HttpURLConnection
import java.net.URL
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.layout.ContentScale
import androidx.compose.runtime.*
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Assignment
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.serialization.Serializable
import androidx.compose.ui.text.input.PasswordVisualTransformation
import java.net.URLDecoder
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.mazarchive.app.network.ApiFactory
import com.mazarchive.app.network.AnswerKeyItem
import com.mazarchive.app.network.AnswerKeyPayload
import com.mazarchive.app.network.HomeBannerDto
import com.mazarchive.app.network.AuthApiFactory
import com.mazarchive.app.network.AttemptRequest
import com.mazarchive.app.network.ApiErrorDto
import com.mazarchive.app.network.LoginRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody
import retrofit2.HttpException
import okio.BufferedSink

private fun readableApiError(error: Throwable): String {
    return when (error) {
        is HttpException -> {
            val raw = runCatching { error.response()?.errorBody()?.string().orEmpty() }.getOrDefault("")
            val parsed = runCatching { Json { ignoreUnknownKeys = true }.decodeFromString<ApiErrorDto>(raw) }.getOrNull()
            if (parsed != null) {
                buildString {
                    append("${parsed.message} [${parsed.code}]")
                    if (parsed.stage.isNotBlank()) append("\nمرحله: ${parsed.stage}")
                    if (parsed.details.isNotBlank()) append("\nجزئیات: ${parsed.details}")
                    append("\nکد HTTP: ${error.code()}")
                }
            } else {
                "خطای سرور (HTTP ${error.code()}): ${raw.ifBlank { error.message() }}"
            }
        }
        else -> {
            val message = error.message.orEmpty()
            when {
                message.contains("Unable to resolve host", ignoreCase = true) -> "دامنه سرور پیدا نشد؛ اتصال اینترنت یا DNS را بررسی کنید."
                message.contains("timeout", ignoreCase = true) -> "زمان پاسخ سرور تمام شد؛ وضعیت Render و اتصال اینترنت را بررسی کنید."
                message.isNotBlank() -> "خطای ارتباط با سرور: $message"
                else -> "خطای ارتباط با سرور: ${error::class.simpleName ?: "خطای نامشخص"}"
            }
        }
    }
}

private fun Uri.toPdfRequestBody(context: android.content.Context): RequestBody {
    val bytes = context.contentResolver.openInputStream(this)?.use { it.readBytes() }
        ?: throw IllegalArgumentException("فایل PDF قابل خواندن نیست.")
    val pdfHeader = "%PDF-".toByteArray(Charsets.US_ASCII)
    if (bytes.size < pdfHeader.size || !bytes.copyOfRange(0, pdfHeader.size).contentEquals(pdfHeader)) {
        throw IllegalArgumentException("فایل انتخاب‌شده PDF معتبر نیست یا محتوای آن قابل خواندن نیست.")
    }
    return object : RequestBody() {
        override fun contentType() = "application/pdf".toMediaType()
        override fun contentLength(): Long = bytes.size.toLong()
        override fun writeTo(sink: BufferedSink) {
            sink.write(bytes)
        }
    }
}

@Serializable
data class Exam(
    val id: Long,
    val title: String,
    val grade: String,
    val field: String,
    val examNumber: Int? = null,
    val examDate: String,
    val year: Int,
    val period: String,
    val month: String,
    val pdfUrl: String,
    val questionCount: Int = 40,
    val durationSeconds: Int = 1800
)

enum class PenTool { PEN, HIGHLIGHTER, ERASER }

data class Stroke(
    val id: String = java.util.UUID.randomUUID().toString(),
    val page: Int,
    val points: List<androidx.compose.ui.geometry.Offset>,
    val color: Color,
    val width: Float,
    val alpha: Float,
    val tool: PenTool
)

data class ExamQuestion(
    val id: Int,
    val text: String,
    val options: List<String>,
    val correct: Int
)

data class ExamResult(
    val answers: Map<Int, Int>,
    val usedSeconds: Int,
    val submittedByTime: Boolean,
    val total: Int
)

private fun sampleQuestions(count: Int = 20): List<ExamQuestion> =
    (1..count).map { n ->
        ExamQuestion(
            id = n,
            text = "سؤال $n: کدام گزینه پاسخ صحیح این سؤال نمونه است؟",
            options = listOf("گزینه اول", "گزینه دوم", "گزینه سوم", "گزینه چهارم"),
            correct = (n + 1) % 4
        )
    }

private fun persianNumber(value: Int): String =
    value.toString().map { ch -> "۰۱۲۳۴۵۶۷۸۹"[ch - '0'] }.joinToString("")

private fun formatTime(totalSeconds: Int): String {
    val m = (totalSeconds / 60).coerceAtLeast(0)
    val sec = (totalSeconds % 60).coerceAtLeast(0)
    return "${persianNumber(m)}:${sec.toString().padStart(2, '0').map { "۰۱۲۳۴۵۶۷۸۹"[it - '0'] }.joinToString("")}"
}

private object LatestExamResultHolder {
    var result: ExamResult? = null
}

private data class HistoryEntry(
    val examId: Long,
    val correct: Int,
    val wrong: Int,
    val unanswered: Int,
    val total: Int,
    val percent: Int,
    val usedSeconds: Int,
    val timestamp: Long
)

private object ExamHistoryStore {
    private const val PREFS = "maz_exam_history"
    private const val KEY_ENTRIES = "entries"
    private fun encode(e: HistoryEntry) = listOf(e.examId, e.correct, e.wrong, e.unanswered, e.total, e.percent, e.usedSeconds, e.timestamp).joinToString(",")
    private fun decode(value: String): HistoryEntry? = runCatching {
        val p = value.split(",")
        HistoryEntry(p[0].toLong(), p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toInt(), p[6].toInt(), p[7].toLong())
    }.getOrNull()
    fun save(context: android.content.Context, examId: Long, result: ExamResult, correct: Int, total: Int) {
        val prefs = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
        val unanswered = total - result.answers.size
        val wrong = (result.answers.size - correct).coerceAtLeast(0)
        val entry = HistoryEntry(examId, correct, wrong, unanswered, total, if (total == 0) 0 else correct * 100 / total, result.usedSeconds, System.currentTimeMillis())
        val old = prefs.getString(KEY_ENTRIES, "").orEmpty().split(";").filter { it.isNotBlank() }
        prefs.edit().putString(KEY_ENTRIES, (listOf(encode(entry)) + old).take(100).joinToString(";")).apply()
    }
    fun all(context: android.content.Context): List<HistoryEntry> = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getString(KEY_ENTRIES, "").orEmpty().split(";").mapNotNull { decode(it) }
    fun count(context: android.content.Context) = all(context).size
}


private val Indigo = Color(0xFF7167E8)
private val Bg = Color(0xFF0B0B0F)
private val Card = Color(0xFF15151C)
private val LightBg = Color.White
private val LightCard = Color(0xFFFFFFFF)
private val LocalMazDark = compositionLocalOf { true }

@Composable
private fun mazBg() = if (LocalMazDark.current) Bg else LightBg

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { App() }
    }
}

@Composable
fun MazTheme(isDark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (isDark) darkColorScheme(
        primary = Indigo,
        onPrimary = Color.White,
        background = Bg,
        onBackground = Color(0xFFF4F2FF),
        surface = Card,
        onSurface = Color(0xFFF4F2FF),
        surfaceVariant = Color(0xFF24243A),
        onSurfaceVariant = Color(0xFFCAC6E0)
    ) else lightColorScheme(
        primary = Indigo, background = LightBg, surface = LightCard,
        onBackground = Color(0xFF202236), onSurface = Color(0xFF202236)
    )
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(
            LocalLayoutDirection provides LayoutDirection.Rtl,
            LocalMazDark provides isDark
        ) { content() }
    }
}

@Composable
fun App() {
    val context = LocalContext.current
    val themePrefs = remember {
        context.getSharedPreferences("maz_preferences", android.content.Context.MODE_PRIVATE)
    }
    var isDark by rememberSaveable {
        mutableStateOf(themePrefs.getBoolean("dark_theme", true))
    }
    val toggleTheme = {
        isDark = !isDark
        themePrefs.edit().putBoolean("dark_theme", isDark).apply()
    }
    MazTheme(isDark) { AppContent(isDark = isDark, onToggleTheme = toggleTheme) }
}

@Composable
private fun AppContent(isDark: Boolean, onToggleTheme: () -> Unit) {
    val nav = rememberNavController()
    val context = LocalContext.current
    val authStore = remember { com.mazarchive.app.data.AuthStore(context) }
    var showSplash by rememberSaveable { mutableStateOf(true) }
    var loggedIn by rememberSaveable { mutableStateOf(authStore.isLoggedIn()) }
    var registered by rememberSaveable { mutableStateOf(authStore.isRegistered()) }
    var showAdminLogin by rememberSaveable { mutableStateOf(false) }
    var role by rememberSaveable { mutableStateOf(authStore.role() ?: "USER") }
    var loginError by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(2600)
        showSplash = false
    }

    if (showSplash) {
        SplashScreen()
        return
    }

    if (!registered && !loggedIn && showAdminLogin) {
        LoginScreen(
            onLogin = { username, password ->
                scope.launch {
                    loginError = ""
                    if (username.trim() == "admin") {
                        runCatching {
                            AuthApiFactory.create(BuildConfig.API_BASE_URL)
                                .login(LoginRequest(username.trim(), password))
                        }.onSuccess { response ->
                            authStore.save(response.token, response.role, response.refreshToken)
                            role = response.role
                            loggedIn = true
                            showAdminLogin = false
                        }.onFailure {
                            loginError = "ورود مدیر ناموفق بود؛ آدرس سرور و رمز مدیر را بررسی کنید."
                        }
                    } else {
                        loginError = "برای ورود مدیر، نام کاربری admin را وارد کنید."
                    }
                }
            }
        )
        if (loginError.isNotBlank()) Text(loginError, color = Color(0xFFFF6B6B))
        return
    }

    if (!registered && !loggedIn) {
        RegisterScreen(
            onRegister = { username, password ->
                authStore.registerLocal(username, password)
                registered = true
                loggedIn = true
                role = "USER"
            },
            onAdminLogin = { showAdminLogin = true }
        )
        return
    }

    if (!loggedIn) {
        LoginScreen { username, password ->
            scope.launch {
                loginError = ""
                if (username.trim() == "admin") {
                    runCatching { AuthApiFactory.create(BuildConfig.API_BASE_URL).login(LoginRequest(username.trim(), password)) }
                        .onSuccess { response ->
                            authStore.save(response.token, response.role, response.refreshToken)
                            role = response.role
                            loggedIn = true
                        }.onFailure { loginError = "ورود ناموفق بود؛ آدرس سرور و رمز مدیر را بررسی کنید." }
                } else if (authStore.checkLocalCredentials(username.trim(), password)) {
                    authStore.save("local-session", "USER")
                    role = "USER"
                    loggedIn = true
                } else {
                    loginError = "نام کاربری یا رمز عبور نادرست است."
                }
            }
        }
        if (loginError.isNotBlank()) Text(loginError, color = Color(0xFFFF6B6B))
        return
    }

    if (role == "ADMIN") {
        AdminHome(onLogout = { authStore.clear(); loggedIn = false; role = "USER" })
        return
    }

    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            AppScaffold(nav, "home") {
                Home(onGrade = { grade -> nav.navigate("fields/${URLEncoder.encode(grade, "UTF-8")}") }, onBannerExam = { id -> nav.navigate("exam/$id") })
            }
        }
        composable("fields/{g}") { entry ->
            val grade = URLDecoder.decode(entry.arguments?.getString("g")!!, "UTF-8")
            AppScaffold(nav, "archive") {
                Fields(grade) { field ->
                    nav.navigate("archive/${URLEncoder.encode(grade, "UTF-8")}/${URLEncoder.encode(field, "UTF-8")}")
                }
            }
        }
        composable("archive/{g}/{f}") { entry ->
            val grade = URLDecoder.decode(entry.arguments?.getString("g")!!, "UTF-8")
            val field = URLDecoder.decode(entry.arguments?.getString("f")!!, "UTF-8")
            AppScaffold(nav, "archive") {
                Archive(grade, field) { id -> nav.navigate("exam/$id") }
            }
        }
        composable("exam/{id}") { entry ->
            ExamDetail(entry.arguments?.getString("id")!!.toLong()) { id ->
                nav.navigate("player/$id")
            }
        }
        composable("player/{id}") { entry ->
            val examId = entry.arguments?.getString("id")!!.toLong()
            ExamPlayer(examId) { result ->
                LatestExamResultHolder.result = result
                // Save every completed attempt locally and try to synchronize it with the server.
                scope.launch {
                    val api = ApiFactory.create(BuildConfig.API_BASE_URL) { authStore.token() }
                    val answerKey = runCatching {
                        api.answerKey(examId).answers.associate { it.questionNumber to (it.correctOption - 1) }
                    }.getOrDefault(emptyMap())
                    val total = result.total.coerceAtLeast(0)
                    val correct = result.answers.count { (answerKey[it.key] != null) && answerKey[it.key] == it.value }
                    val unanswered = (total - result.answers.size).coerceAtLeast(0)
                    val wrong = (result.answers.size - correct).coerceAtLeast(0)
                    val percent = if (total == 0) 0f else correct * 100f / total
                    ExamHistoryStore.save(context, examId, result, correct, total)
                    runCatching {
                        api.createAttempt(
                            AttemptRequest(
                                examId = examId,
                                correct = correct,
                                wrong = wrong,
                                unanswered = unanswered,
                                total = total,
                                percent = percent,
                                usedSeconds = result.usedSeconds,
                                submittedByTime = result.submittedByTime
                            )
                        )
                    }
                }
                nav.navigate("result/$examId/0")
            }
        }
        composable("result/{id}/{unused}") { entry ->
            ExamResultScreen(
                examId = entry.arguments?.getString("id")!!.toLong(),
                onHome = { nav.navigate("home") { popUpTo("home") { inclusive = true } } }
            )
        }
        composable("history") {
            AppScaffold(nav, "history") {
                HistoryScreen { index -> nav.navigate("historyDetail/$index") }
            }
        }
        composable("historyDetail/{index}") { entry ->
            HistoryDetailScreen(entry.arguments?.getString("index")!!.toInt(), onBack = { nav.popBackStack() })
        }
        composable("profile") { AppScaffold(nav, "profile") { ProfileScreen(isDark = isDark, onToggleTheme = onToggleTheme, onLogout = { authStore.clear(); loggedIn = false; role = "USER"; nav.navigate("home") { popUpTo("home") { inclusive = true } } }) } }
        composable("pdf/{url}") { entry ->
            PdfScreen(URLDecoder.decode(entry.arguments?.getString("url")!!, "UTF-8")) { nav.popBackStack() }
        }
    }
}

@Composable
fun AppScaffold(nav: androidx.navigation.NavHostController, selected: String, content: @Composable () -> Unit) {
    val dark = LocalMazDark.current
    val navBg = if (dark) Color(0xFF0D0F18) else Color.White
    val navText = if (dark) Color(0xFF8E91A3) else Color(0xFF4B5068)
    Scaffold(
        containerColor = mazBg(),
        bottomBar = {
            NavigationBar(containerColor = navBg, tonalElevation = 0.dp) {
                NavItem(Icons.Rounded.Home, "خانه", selected == "home", navText) { nav.navigate("home") { launchSingleTop = true; popUpTo("home") { saveState = true } } }
                NavItem(Icons.Rounded.Assignment, "کارنامه", selected == "history", navText) { nav.navigate("history") { launchSingleTop = true } }
                NavItem(Icons.Rounded.Person, "پروفایل", selected == "profile", navText) { nav.navigate("profile") { launchSingleTop = true } }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) { content() }
    }
}

@Composable
fun RowScope.NavItem(icon: ImageVector, label: String, selected: Boolean, navText: Color, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = if (selected) Indigo.copy(alpha = if (LocalMazDark.current) 0.34f else 0.14f) else Color.Transparent
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp).size(28.dp),
                    tint = if (selected) (if (LocalMazDark.current) Color.White else Indigo) else navText
                )
            }
        },
        label = { Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = if (LocalMazDark.current) Color.White else Indigo,
            selectedTextColor = if (LocalMazDark.current) Color.White else Indigo,
            indicatorColor = Indigo.copy(alpha = if (LocalMazDark.current) 0.28f else 0.12f),
            unselectedIconColor = navText,
            unselectedTextColor = navText
        )
    )
}

@Composable
fun SplashScreen() {
    Box(
        Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.mipmap.ic_launcher),
            contentDescription = "Maz-Archive",
            modifier = Modifier
                .size(150.dp)
                .clip(RoundedCornerShape(38.dp))
        )
    }
}

@Composable
private fun AdminActionCard(
    title: String,
    subtitle: String,
    icon: String,
    accent: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(205.dp),
        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.18f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.9f)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier.size(66.dp).clip(RoundedCornerShape(20.dp)).background(accent),
                contentAlignment = Alignment.Center
            ) { Text(icon, style = MaterialTheme.typography.headlineMedium, color = Color.White) }
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(subtitle, color = Color(0xFFD0CCF8), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
            Box(
                modifier = Modifier.size(38.dp).clip(CircleShape).background(accent.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) { Text("←", color = Color.White, style = MaterialTheme.typography.titleLarge) }
        }
    }
}

@Composable
private fun AdminSectionHeader(title: String, subtitle: String = "") {
    Column(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
        Text(title, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (subtitle.isNotBlank()) Text(subtitle, color = Color(0xFFBDB8F5), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun RowScope.AdminBottomNavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    TextButton(
        onClick = onClick,
        modifier = Modifier.widthIn(min = 88.dp).weight(1f),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.textButtonColors(contentColor = Color.White),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Box(
                modifier = Modifier
                    .size(if (selected) 44.dp else 40.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (selected) accent.copy(alpha = .22f) else Color.Transparent)
                    .border(1.dp, if (selected) accent.copy(alpha = .85f) else Color.Transparent, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = label, tint = if (selected) Color.White else Color(0xFFC2BDF4), modifier = Modifier.size(23.dp))
            }
            Text(label, color = if (selected) Color.White else Color(0xFFC2BDF4), fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
fun AdminHome(onLogout: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val api = remember { ApiFactory.create(BuildConfig.API_BASE_URL) { com.mazarchive.app.data.AuthStore(context).token() } }
    var section by rememberSaveable { mutableStateOf("home") }
    var examTitle by rememberSaveable { mutableStateOf("") }
    var examYear by rememberSaveable { mutableStateOf("") }
    var examField by rememberSaveable { mutableStateOf("") }
    var examGrade by rememberSaveable { mutableStateOf("") }
    var examDate by rememberSaveable { mutableStateOf("2026-01-01") }
    var examMinutes by rememberSaveable { mutableStateOf("30") }
    var examQuestionCount by rememberSaveable { mutableStateOf("40") }
    var answerKeyText by rememberSaveable { mutableStateOf("") }
    var selectedExamId by rememberSaveable { mutableStateOf<Long?>(null) }
    var editingExamId by rememberSaveable { mutableStateOf<Long?>(null) }
    var adminExams by remember { mutableStateOf(listOf<com.mazarchive.app.network.AdminExamPayload>()) }
    var status by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var bannerTitle by rememberSaveable { mutableStateOf("") }
    var bannerSubtitle by rememberSaveable { mutableStateOf("") }
    var bannerImageUrl by rememberSaveable { mutableStateOf("") }
    var bannerKind by rememberSaveable { mutableStateOf("NOTICE") }
    var bannerExamId by rememberSaveable { mutableStateOf("") }
    var bannerSortOrder by rememberSaveable { mutableStateOf("0") }
    var bannerActive by rememberSaveable { mutableStateOf(true) }
    var adminBanners by remember { mutableStateOf<List<HomeBannerDto>>(emptyList()) }
    var selectedPdfUri by remember { mutableStateOf<Uri?>(null) }
    var selectedPdfName by remember { mutableStateOf("") }
    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        selectedPdfUri = uri
        selectedPdfName = uri?.lastPathSegment?.substringAfterLast('/') ?: ""
    }

    fun loadExams() = scope.launch {
        loading = true
        runCatching { api.adminExams() }
            .onSuccess { adminExams = it; status = "آزمون‌ها از سرور دریافت شدند." }
            .onFailure { status = "دریافت آزمون‌ها ناموفق بود." }
        loading = false
    }
    fun loadBanners() = scope.launch { runCatching { api.adminHomeBanners() }.onSuccess { adminBanners = it } }
    LaunchedEffect(Unit) { loadExams(); loadBanners() }

    val bg = Color(0xFF060718)
    val panel = Color(0xFF111535)
    val purple = Color(0xFF7C4DFF)
    val blue = Color(0xFF168BFF)
    val textSecondary = Color(0xFFC2BDF4)

    Column(
        modifier = Modifier.fillMaxSize().background(bg).verticalScroll(rememberScrollState()).padding(start = 16.dp, top = 76.dp, end = 16.dp, bottom = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(purple), contentAlignment = Alignment.Center) {
                    Text("≋", color = Color.White, style = MaterialTheme.typography.headlineMedium)
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("Maz-Archive", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                    Text("پنل مدیریت", color = textSecondary)
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("admin", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("مدیر سیستم", color = textSecondary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Spacer(Modifier.height(20.dp))

        when (section) {
            "home" -> {
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(26.dp), border = androidx.compose.foundation.BorderStroke(1.dp, purple.copy(alpha = .75f))) {
                    Column(Modifier.fillMaxWidth().padding(22.dp)) {
                        Text("سلام، مدیر عزیز", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("به پنل مدیریت Maz-Archive خوش آمدید.", color = textSecondary, style = MaterialTheme.typography.bodyLarge)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) {
                        AdminActionCard("آمار کاربران", "مشاهده اطلاعات کاربران", "♟", blue) { section = "users" }
                    }
                    Box(Modifier.weight(1f)) {
                        AdminActionCard("افزودن آزمون", "ثبت و ایجاد آزمون جدید", "+", purple) { section = "add" }
                    }
                    Box(Modifier.weight(1f)) {
                        AdminActionCard("مدیریت آزمون‌ها", "مشاهده، ویرایش و حذف", "▤", blue) { section = "exams" }
                    }
                    Box(Modifier.weight(1f)) {
                        AdminActionCard("اسلایدر صفحه اصلی", "بنرها و اطلاعیه‌ها", "▰", purple) { section = "banners" }
                    }
                }
            }
            "exams" -> {
                AdminSectionHeader("مدیریت آزمون‌ها", "آزمون‌های ثبت‌شده در سرور")
                if (adminExams.isEmpty()) {
                    Text("آزمونی یافت نشد.", color = textSecondary)
                } else {
                    adminExams.forEach { item ->
                        Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                            Column(Modifier.padding(14.dp)) {
                                Text(item.title, color = Color.White, fontWeight = FontWeight.Bold)
                                Text("شناسه: ${item.id} | سال: ${item.year}", color = textSecondary)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = { editingExamId = item.id; examTitle = item.title; examYear = item.year.toString(); examGrade = item.grade; examField = item.field; examDate = item.examDate; examMinutes = (item.durationSeconds / 60).toString(); examQuestionCount = item.questionCount.toString(); answerKeyText = ""; section = "add" }) { Text("ویرایش", color = textSecondary) }
                                    TextButton(onClick = { scope.launch { loading = true; runCatching { api.deleteAdminExam(item.id) }.onSuccess { status = "آزمون حذف شد."; loadExams() }.onFailure { status = "حذف آزمون ناموفق بود." }; loading = false } }) { Text("حذف", color = Color(0xFFFF8DAB)) }
                                }
                            }
                        }
                    }
                }
            }
            "add" -> {
                AdminSectionHeader(if (editingExamId == null) "افزودن آزمون" else "ویرایش آزمون", "آزمون جدید را با فایل PDF اضافه کنید")
                Spacer(Modifier.height(8.dp))
                Box(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier.size(214.dp).clip(CircleShape)
                                .background(Color(0xFF101A55))
                                .border(3.dp, purple, CircleShape)
                                .clickable { pdfPicker.launch(arrayOf("application/pdf")) },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("PDF", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineLarge)
                                Text(if (selectedPdfUri == null) "انتخاب فایل PDF" else "فایل انتخاب شد", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("برای انتخاب لمس کنید", color = textSecondary, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (selectedPdfName.isNotBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Text(selectedPdfName, color = textSecondary, maxLines = 1, textAlign = TextAlign.Center)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                val fieldModifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                OutlinedTextField(examTitle, { examTitle = it }, fieldModifier, label = { Text("عنوان آزمون") }, singleLine = true)
                OutlinedTextField(examYear, { examYear = it }, fieldModifier, label = { Text("سال") }, singleLine = true)
                OutlinedTextField(examDate, { examDate = it }, fieldModifier, label = { Text("تاریخ برگزاری") }, singleLine = true)
                OutlinedTextField(examGrade, { examGrade = it }, fieldModifier, label = { Text("پایه") }, singleLine = true)
                OutlinedTextField(examField, { examField = it }, fieldModifier, label = { Text("رشته") }, singleLine = true)
                OutlinedTextField(examMinutes, { examMinutes = it }, fieldModifier, label = { Text("مدت آزمون (دقیقه)") }, singleLine = true)
                OutlinedTextField(examQuestionCount, { examQuestionCount = it }, fieldModifier, label = { Text("تعداد سؤال (۱ تا ۵۰۰)") }, singleLine = true)
                OutlinedTextField(answerKeyText, { answerKeyText = it }, fieldModifier, label = { Text("کلید پاسخ (مثال: 1:2,2:4,3:1)") }, minLines = 2)
                Button(enabled = !loading, onClick = {
                    val year = examYear.toIntOrNull(); val minutes = examMinutes.toIntOrNull(); val questionCount = examQuestionCount.toIntOrNull()
                    if (examTitle.isBlank() || year == null || minutes == null || questionCount == null || questionCount !in 1..500) status = "عنوان، سال و مدت را درست وارد کنید."
                    else scope.launch {
                        loading = true
                        runCatching {
                            val saved = if (editingExamId == null) {
                                api.createAdminExam(com.mazarchive.app.network.CreateExamPayload(
                                    title=examTitle.trim(), grade=examGrade.trim(), field=examField.trim(),
                                    examDate=examDate, year=year, period="", month="", durationSeconds=minutes*60, questionCount=questionCount
                                ))
                            } else {
                                api.updateAdminExam(editingExamId!!, com.mazarchive.app.network.AdminExamPayload(
                                    id=editingExamId!!, title=examTitle.trim(), grade=examGrade.trim(), field=examField.trim(),
                                    examDate=examDate, year=year, period="", month="", durationSeconds=minutes*60, questionCount=questionCount
                                ))
                            }
                            val uploadResult = selectedPdfUri?.let { uri -> api.uploadExamPdf(saved.id, uri.toPdfRequestBody(context)) }
                            val key = answerKeyText.split(",", "\n", ";").mapNotNull { token ->
                                val parts = token.trim().split(":", "=", "-").map { it.trim() }
                                val q = parts.getOrNull(0)?.toIntOrNull(); val a = parts.getOrNull(1)?.toIntOrNull()
                                if (q != null && a != null) AnswerKeyItem(q, a) else null
                            }.filter { it.questionNumber in 1..questionCount && it.correctOption in 1..4 }.distinctBy { it.questionNumber }
                            api.saveAnswerKey(saved.id, AnswerKeyPayload(key))
                            Pair(saved, uploadResult)
                        }.onSuccess { (_, uploadResult) ->
                            status = if (editingExamId == null) {
                                uploadResult?.message ?: "آزمون و PDF آرشیوی ذخیره شد؛ استخراج سؤال انجام نمی‌شود."
                            } else "آزمون ویرایش شد."
                            examTitle = ""; selectedPdfUri = null; selectedPdfName = ""; answerKeyText = ""; editingExamId = null; loadExams() }.onFailure { error ->
                            val detail = when (error) {
                                is HttpException -> {
                                    val body = runCatching { error.response()?.errorBody()?.string() }.getOrNull().orEmpty()
                                    if (body.isNotBlank()) "HTTP ${error.code()}: $body" else "HTTP ${error.code()}: ${error.message()}"
                                }
                                else -> error.message ?: error::class.simpleName ?: "خطای نامشخص"
                            }
                            status = "خطای ذخیره: $detail"
                        }
                        loading = false
                    }
                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = purple)) { Text("افزودن آزمون", color = Color.White) }
            }
            "banners" -> {
                AdminSectionHeader("مدیریت اسلایدر صفحه اصلی", "بنر اطلاع‌رسانی یا معرفی آزمون را مدیریت کنید")
                OutlinedTextField(bannerTitle, { bannerTitle = it }, Modifier.fillMaxWidth().padding(bottom = 8.dp), label = { Text("عنوان بنر") }, singleLine = true)
                OutlinedTextField(bannerSubtitle, { bannerSubtitle = it }, Modifier.fillMaxWidth().padding(bottom = 8.dp), label = { Text("توضیح کوتاه") }, minLines = 2)
                OutlinedTextField(bannerImageUrl, { bannerImageUrl = it }, Modifier.fillMaxWidth().padding(bottom = 8.dp), label = { Text("لینک تصویر (اختیاری)") }, singleLine = true)
                OutlinedTextField(bannerExamId, { bannerExamId = it }, Modifier.fillMaxWidth().padding(bottom = 8.dp), label = { Text("شناسه آزمون (برای بنر آزمون، اختیاری)") }, singleLine = true)
                OutlinedTextField(bannerSortOrder, { bannerSortOrder = it }, Modifier.fillMaxWidth().padding(bottom = 8.dp), label = { Text("ترتیب نمایش") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = bannerKind == "NOTICE", onClick = { bannerKind = "NOTICE" }, label = { Text("اطلاعیه") })
                    FilterChip(selected = bannerKind == "EXAM", onClick = { bannerKind = "EXAM" }, label = { Text("معرفی آزمون") })
                    FilterChip(selected = bannerActive, onClick = { bannerActive = !bannerActive }, label = { Text(if (bannerActive) "فعال" else "غیرفعال") })
                }
                Button(enabled = bannerTitle.isNotBlank() && !loading, onClick = { scope.launch { loading = true; runCatching { api.createHomeBanner(HomeBannerDto(title=bannerTitle.trim(), subtitle=bannerSubtitle.trim(), imageUrl=bannerImageUrl.trim(), kind=bannerKind, examId=bannerExamId.toLongOrNull(), active=bannerActive, sortOrder=bannerSortOrder.toIntOrNull() ?: 0)) }.onSuccess { status = "بنر با موفقیت ذخیره شد."; bannerTitle=""; bannerSubtitle=""; bannerImageUrl=""; bannerExamId=""; loadBanners() }.onFailure { status = "ذخیره بنر ناموفق بود: ${it.message ?: "خطای نامشخص"}" }; loading = false } }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = purple)) { Text("افزودن بنر", color = Color.White) }
                Spacer(Modifier.height(12.dp))
                adminBanners.forEach { banner ->
                    Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(banner.title, color = Color.White, fontWeight = FontWeight.Bold)
                            Text("${banner.kind} | ترتیب ${banner.sortOrder} | ${if (banner.active) "فعال" else "غیرفعال"}", color = textSecondary)
                            TextButton(onClick = { scope.launch { runCatching { api.deleteHomeBanner(banner.id) }.onSuccess { status = "بنر حذف شد."; loadBanners() }.onFailure { status = "حذف بنر ناموفق بود." } } }) { Text("حذف", color = Color(0xFFFF8DAB)) }
                        }
                    }
                }
            }
            "users" -> {
                AdminSectionHeader("آمار کاربران", "اطلاعات مربوط به کاربران سامانه")
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp)) {
                        Text("اطلاعات کاربران هنوز از API دریافت نمی‌شود.", color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("برای نمایش تعداد کاربران، کاربران فعال و آمار ورود، باید endpoint آماری کاربران در بک‌اند اضافه شود. در این مرحله داده ساختگی نمایش داده نمی‌شود.", color = textSecondary)
                    }
                }
            }
        }

        if (status.isNotBlank()) Text(status, color = textSecondary, modifier = Modifier.padding(vertical = 12.dp))
        Spacer(Modifier.height(22.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = panel.copy(alpha = .98f)),
            shape = RoundedCornerShape(28.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF252B58))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                AdminBottomNavItem(
                    icon = Icons.Rounded.Home,
                    label = "خانه",
                    selected = section == "home",
                    accent = purple,
                    onClick = { section = "home" }
                )
                AdminBottomNavItem(
                    icon = Icons.Rounded.Settings,
                    label = "تنظیمات",
                    selected = section == "settings",
                    accent = purple,
                    onClick = { section = "settings" }
                )
                AdminBottomNavItem(
                    icon = Icons.Rounded.Logout,
                    label = "خروج",
                    selected = false,
                    accent = Color(0xFFFF668B),
                    onClick = onLogout
                )
            }
        }
    }
}

@Composable
fun RegisterScreen(onRegister: (String, String) -> Unit, onAdminLogin: () -> Unit = {}) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize().background(mazBg())) {
        Column(
            Modifier.fillMaxWidth().align(Alignment.Center).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(id = R.mipmap.ic_launcher),
                contentDescription = "Maz-Archive",
                modifier = Modifier.size(104.dp).clip(RoundedCornerShape(28.dp))
            )
            Text("Maz-Archive", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Indigo)
            Text("ثبت‌نام در آرشیو", style = MaterialTheme.typography.titleLarge)
            Text("برای اولین ورود، حساب خودت را بساز", color = Color(0xFFAAAEC0))

            OutlinedTextField(
                value = user,
                onValueChange = { user = it; error = "" },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("نام کاربری") },
                singleLine = true,
                shape = RoundedCornerShape(18.dp)
            )
            OutlinedTextField(
                value = pass,
                onValueChange = { pass = it; error = "" },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("رمز عبور") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(18.dp)
            )
            OutlinedTextField(
                value = confirm,
                onValueChange = { confirm = it; error = "" },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("تکرار رمز عبور") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(18.dp)
            )
            if (error.isNotBlank()) Text(error, color = Color(0xFFFF6B6B))
            Button(
                onClick = {
                    when {
                        user.trim().length < 3 -> error = "نام کاربری حداقل ۳ حرف باشد"
                        pass.length < 4 -> error = "رمز عبور حداقل ۴ کاراکتر باشد"
                        pass != confirm -> error = "رمزهای عبور یکسان نیستند"
                        else -> onRegister(user.trim(), pass)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = user.isNotBlank() && pass.isNotBlank() && confirm.isNotBlank(),
                shape = RoundedCornerShape(16.dp)
            ) { Text("ساخت حساب و ورود") }

            OutlinedButton(
                onClick = onAdminLogin,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("ورود مدیر")
            }
        }
    }
}

@Composable
fun LoginScreen(onLogin: (String, String) -> Unit) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(mazBg())) {
        Column(
            Modifier.fillMaxWidth().align(Alignment.Center).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(id = R.mipmap.ic_launcher),
                contentDescription = "Maz-Archive",
                modifier = Modifier
                    .size(104.dp)
                    .clip(RoundedCornerShape(28.dp))
            )
            Text(
                "Maz-Archive",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = Indigo
            )
            Text("آرشیو آزمون‌ها و منابع آموزشی", color = Color(0xFFAAAEC0))
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = user,
                onValueChange = { user = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("نام کاربری") },
                shape = RoundedCornerShape(18.dp)
            )
            OutlinedTextField(
                value = pass,
                onValueChange = { pass = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("رمز عبور") },
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(18.dp)
            )
            Button(
                onClick = {
                    val u = user.trim()
                    if (u.isNotBlank() && pass.isNotBlank()) {
                        error = false
                        onLogin(u, pass)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = user.isNotBlank() && pass.isNotBlank(),
                shape = RoundedCornerShape(16.dp)
            ) { Text("ورود به آرشیو") }
            if (error) Text("نام کاربری یا رمز عبور نادرست است", color = Color(0xFFFF6B6B))
        }
    }
}

@Composable
fun Home(onGrade: (String) -> Unit, onBannerExam: (Long) -> Unit = {}) {
    val dark = LocalMazDark.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val api = remember { ApiFactory.create(BuildConfig.API_BASE_URL) { com.mazarchive.app.data.AuthStore(context).token() } }
    var banners by remember { mutableStateOf<List<HomeBannerDto>>(emptyList()) }
    var dashboard by remember { mutableStateOf<HomeDashboardDto?>(null) }
    LaunchedEffect(Unit) {
        runCatching { api.homeDashboard() }.onSuccess { data ->
            dashboard = data
            banners = data.notices + data.recommendedExams.map { exam -> HomeBannerDto(kind = "EXAM", title = exam.title, subtitle = "${exam.grade} • ${exam.field}", examId = exam.id) }
        }.onFailure { runCatching { api.homeBanners() }.onSuccess { banners = it.banners } }
    } }
    val primaryText = if (dark) Color(0xFFF4F2FF) else Color(0xFF151827)
    val secondaryText = if (dark) Color(0xFF9EA2B4) else Color(0xFF68708A)
    val examCard = if (dark) Color(0xFF171B3A) else Color(0xFFF1F0FF)
    val gradeCard = if (dark) Color(0xFF131827) else Color.White
    val gradeCounts = dashboard?.gradeCounts?.associate { it.grade to it.count }.orEmpty()
    val grades = listOf(
        Triple("دهم", "${gradeCounts["دهم"] ?: 0} آزمون", Color(0xFF10C99A)),
        Triple("یازدهم", "${gradeCounts["یازدهم"] ?: 0} آزمون", Color(0xFF2686FF)),
        Triple("دوازدهم", "${gradeCounts["دوازدهم"] ?: 0} آزمون", Color(0xFF8247FF))
    )
    Column(Modifier.fillMaxSize().background(mazBg()).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(id = R.mipmap.ic_launcher), "Maz-Archive", Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)))
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("Maz-Archive", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = primaryText)
                Text("آرشیو هوشمند آزمون‌ها", color = secondaryText, style = MaterialTheme.typography.bodySmall)
            }
            Surface(shape = CircleShape, color = if (dark) Color(0xFF171C31) else Color(0xFFEDEBFF)) { Text("M", Modifier.padding(horizontal = 13.dp, vertical = 9.dp), color = Indigo, fontWeight = FontWeight.Bold) }
        }
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("سلام، کاربر عزیز 👋", color = secondaryText)
            Text("آماده‌ای برای آزمون بعدی؟", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = primaryText)
        }
        if (banners.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("پیشنهادها و اطلاعیه‌ها", color = primaryText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                banners.forEach { banner ->
                    HomeBannerCard(banner, dark, primaryText, secondaryText) { banner.examId?.let { onBannerExam(it) } }
                }
            }
        }
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = if (dark) Color(0xFF151B31) else Color(0xFFEDEBFF))
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("مسیر پیشرفت تو", color = primaryText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("از آرشیو آزمون‌ها انتخاب کن، تمرین کن و نتیجه‌ات را در کارنامه بررسی کن.", color = secondaryText, style = MaterialTheme.typography.bodySmall)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("آرشیو" to "آزمون‌ها", "تمرین" to "حل سؤال", "کارنامه" to "پیگیری").forEach { (title, subtitle) ->
                        Surface(Modifier.weight(1f), shape = RoundedCornerShape(14.dp), color = if (dark) Color(0xFF202744) else Color.White) {
                            Column(Modifier.padding(vertical = 10.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(title, color = Indigo, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                Text(subtitle, color = secondaryText, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = examCard), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(Modifier.size(52.dp), RoundedCornerShape(16.dp), color = Indigo.copy(alpha = .22f)) { Box(contentAlignment = Alignment.Center) { Text("✦", color = Indigo, style = MaterialTheme.typography.headlineSmall) } }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("جدیدترین آزمون", color = if (dark) Color(0xFFC3BEFF) else Indigo, style = MaterialTheme.typography.labelLarge)
                        Text(dashboard?.newestExams?.firstOrNull()?.title ?: "هنوز آزمونی ثبت نشده", fontWeight = FontWeight.Bold, color = primaryText)
                        Text(dashboard?.newestExams?.firstOrNull()?.let { "${it.grade} • ${it.field}" } ?: "اطلاعات آزمون‌های جدید", color = secondaryText, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${dashboard?.newestExams?.firstOrNull()?.questionCount ?: 0} سوال", color = secondaryText, style = MaterialTheme.typography.labelSmall)
                    Text(dashboard?.newestExams?.firstOrNull()?.examDate ?: "-", color = Indigo, style = MaterialTheme.typography.labelSmall)
                }
                Button(onClick = { onGrade("یازدهم") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("مشاهده آزمون  →") }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text("پایه‌های تحصیلی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = primaryText)
                Text("پایه موردنظر را انتخاب کن • ${dashboard?.totalExams ?: 0} آزمون در آرشیو", color = secondaryText, style = MaterialTheme.typography.bodySmall)
            }
            Text("۳ پایه", color = secondaryText, style = MaterialTheme.typography.labelSmall)
        }
        grades.forEach { (grade, count, accent) ->
            Card(Modifier.fillMaxWidth().clickable { onGrade(grade) }, RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = gradeCard)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(Modifier.size(58.dp), RoundedCornerShape(18.dp), color = accent.copy(alpha = if (dark) .15f else .12f)) { Box(contentAlignment = Alignment.Center) { Text("🎓", style = MaterialTheme.typography.titleLarge) } }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("پایه $grade", fontWeight = FontWeight.Bold, color = primaryText)
                        Text(count, color = accent, style = MaterialTheme.typography.labelLarge)
                        Text("آزمون‌های این پایه", color = secondaryText, style = MaterialTheme.typography.bodySmall)
                    }
                    Text("›", color = accent, style = MaterialTheme.typography.headlineMedium)
                }
            }
        }
        Text("Maz-Archive  •  نسخه 1.0.0", Modifier.fillMaxWidth(), color = secondaryText, textAlign = androidx.compose.ui.text.style.TextAlign.Center, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun HomeBannerCard(banner: HomeBannerDto, dark: Boolean, primaryText: Color, secondaryText: Color, onClick: () -> Unit) {
    val context = LocalContext.current
    var bitmap by remember(banner.imageUrl) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(banner.imageUrl) {
        if (banner.imageUrl.isNotBlank()) withContext(Dispatchers.IO) {
            runCatching {
                val connection = URL(banner.imageUrl).openConnection() as HttpURLConnection
                connection.connectTimeout = 8000; connection.readTimeout = 10000
                connection.inputStream.use { BitmapFactory.decodeStream(it) }
            }.onSuccess { bitmap = it }
        }
    }
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = if (dark) Color(0xFF171D3B) else Color(0xFFEDEBFF))) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = banner.title, modifier = Modifier.fillMaxWidth().heightIn(max = 180.dp).clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.Crop)
            Text(if (banner.kind == "EXAM") "آزمون پیشنهادی" else "اطلاعیه", color = Indigo, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
            Text(banner.title, color = primaryText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            if (banner.subtitle.isNotBlank()) Text(banner.subtitle, color = secondaryText, style = MaterialTheme.typography.bodySmall)
            if (banner.kind == "EXAM") Text("مشاهده آزمون  →", color = Indigo, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Fields(grade: String, onField: (String) -> Unit) {
    Column(Modifier.fillMaxSize().background(mazBg()).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("انتخاب رشته", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("پایه $grade", color = Color(0xFF9EA2B4))
        Spacer(Modifier.height(4.dp))
        listOf("ریاضی" to Color(0xFF2686FF), "تجربی" to Color(0xFF10C99A), "انسانی" to Color(0xFF8247FF)).forEach { (field, accent) ->
            Card(Modifier.fillMaxWidth().clickable { onField(field) }, RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A))) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(Modifier.size(52.dp), RoundedCornerShape(16.dp), color = accent.copy(alpha = .16f)) { Box(contentAlignment = Alignment.Center) { Text("◆", color = accent) } }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) { Text("رشته $field", fontWeight = FontWeight.Bold); Text("مشاهده آزمون‌های $grade", color = Color(0xFF8F94A8), style = MaterialTheme.typography.bodySmall) }
                    Text("›", color = accent, style = MaterialTheme.typography.headlineMedium)
                }
            }
        }
    }
}

@Composable
fun Archive(grade: String, field: String, open: (Long) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val api = remember { ApiFactory.create(BuildConfig.API_BASE_URL) { com.mazarchive.app.data.AuthStore(context).token() } }
    var q by rememberSaveable(grade, field) { mutableStateOf("") }
    var year by rememberSaveable(grade, field) { mutableStateOf<Int?>(null) }
    var period by rememberSaveable(grade, field) { mutableStateOf<String?>(null) }
    var month by rememberSaveable(grade, field) { mutableStateOf<String?>(null) }
    var showFilter by rememberSaveable(grade, field) { mutableStateOf(false) }
    var exams by remember(grade, field) { mutableStateOf<List<Exam>>(emptyList()) }
    var loading by remember(grade, field) { mutableStateOf(true) }
    var error by remember(grade, field) { mutableStateOf<String?>(null) }

    fun loadExams() = scope.launch {
        loading = true
        error = null
        runCatching { api.exams(grade, field, year, period, month, q.takeIf { it.isNotBlank() }) }
            .onSuccess { exams = it }
            .onFailure { error = "دریافت آزمون‌ها از سرور انجام نشد. اتصال اینترنت و آدرس سرور را بررسی کنید." }
        loading = false
    }

    LaunchedEffect(grade, field, year, period, month, q) {
        kotlinx.coroutines.delay(300)
        loadExams()
    }

    Column(Modifier.fillMaxSize().background(mazBg()).padding(horizontal = 16.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("آزمون‌های $grade", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(field, color = Indigo)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text("نام آزمون، درس یا تاریخ...") }, leadingIcon = { Text("⌕") }, shape = RoundedCornerShape(16.dp))
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            FilterChip(selected = !showFilter, onClick = { showFilter = false }, label = { Text("همه") })
            FilterChip(selected = showFilter, onClick = { showFilter = true }, label = { Text("فیلتر") })
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { loadExams() }) { Text("بازخوانی") }
        }
        if (showFilter) FilterPanel(year, { year = it }, period, { period = it }, month, { month = it })
        when {
            loading -> Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Indigo) }
            error != null -> Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(error!!, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.error)
                TextButton(onClick = { loadExams() }) { Text("تلاش دوباره") }
            }
            exams.isEmpty() -> Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { Text("آزمونی برای این فیلتر پیدا نشد.") }
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(exams, key = { it.id }) { exam ->
                    Card(Modifier.fillMaxWidth().clickable { open(exam.id) }, RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = if (LocalMazDark.current) Color(0xFF141A2A) else MaterialTheme.colorScheme.surface)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(Modifier.size(48.dp), RoundedCornerShape(14.dp), color = Indigo.copy(alpha = .15f)) { Box(contentAlignment = Alignment.Center) { Text("▤", color = Indigo) } }
                            Spacer(Modifier.width(11.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(exam.title, fontWeight = FontWeight.SemiBold)
                                Text("${exam.examDate}  •  ${exam.month}  •  ${exam.year}", color = Color(0xFF858B9F), style = MaterialTheme.typography.bodySmall)
                            }
                            Text("›", color = Indigo, style = MaterialTheme.typography.headlineSmall)
                        }
                    }
                }
            }
        }
    }
}
@Composable
fun SearchScreen(open: (String, String) -> Unit) {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(mazBg()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("جستجو", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("آزمون موردنظرت را سریع پیدا کن", color = Color(0xFF969BAD))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("نام آزمون، درس یا پایه...") }, leadingIcon = { Text("⌕") }, shape = RoundedCornerShape(17.dp))
        Text("فیلترهای سریع", fontWeight = FontWeight.Bold)
        listOf("دهم • ریاضی", "یازدهم • فیزیک", "دوازدهم • شیمی").forEach { label ->
            val parts = label.split(" • ")
            Card(Modifier.fillMaxWidth().clickable { open(parts[0], parts[1]) }, RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A))) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text("⌕", color = Indigo); Spacer(Modifier.width(12.dp)); Text(label, Modifier.weight(1f)); Text("›", color = Indigo) }
            }
        }
    }
}

private fun formatHistoryDate(timestamp: Long): String = runCatching {
    SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.getDefault()).format(Date(timestamp))
}.getOrDefault("تاریخ نامشخص")

@Composable
fun HistoryScreen(onOpen: (Int) -> Unit) {
    val context = LocalContext.current
    var entries by remember { mutableStateOf(ExamHistoryStore.all(context)) }
    val scope = rememberCoroutineScope()
    var online by remember { mutableStateOf<List<com.mazarchive.app.network.AttemptDto>>(emptyList()) }
    var onlineLoading by remember { mutableStateOf(true) }
    var onlineError by remember { mutableStateOf(false) }
    var examTitles by remember { mutableStateOf<Map<Long, String>>(emptyMap()) }
    val average = if (entries.isEmpty()) 0 else entries.map { it.percent }.average().toInt()

    LaunchedEffect(Unit) {
        entries = ExamHistoryStore.all(context)
        onlineLoading = true
        runCatching {
            val api = ApiFactory.create(BuildConfig.API_BASE_URL) { com.mazarchive.app.data.AuthStore(context).token() }
            val attempts = api.attempts()
            val exams = runCatching { api.exams() }.getOrDefault(emptyList())
            Pair(attempts, exams)
        }.onSuccess {
            online = it.first
            examTitles = it.second.associate { exam -> exam.id to exam.title }
            onlineError = false
        }.onFailure {
            onlineError = true
        }
        onlineLoading = false
    }

    Column(Modifier.fillMaxSize().background(mazBg()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("کارنامه", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("نتایج آزمون‌های شما؛ محلی و همگام‌شده با سرور", color = Color(0xFF8E94A8), style = MaterialTheme.typography.bodySmall)
        if (entries.isNotEmpty()) {
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = if (LocalMazDark.current) Color(0xFF171B3A) else Color.White)) {
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(Modifier.weight(1f)) { Text("آزمون‌ها", color = Color(0xFF8E94A8), style = MaterialTheme.typography.bodySmall); Text(persianNumber(entries.size), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) }
                    Column(Modifier.weight(1f)) { Text("میانگین درصد", color = Color(0xFF8E94A8), style = MaterialTheme.typography.bodySmall); Text("${persianNumber(average)}٪", color = Indigo, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) }
                    Column(Modifier.weight(1f)) { Text("آنلاین", color = Color(0xFF8E94A8), style = MaterialTheme.typography.bodySmall); Text(persianNumber(online.size), color = Color(0xFF35B982), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) }
                }
            }
        }
        if (onlineLoading) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = Indigo); Text("در حال دریافت کارنامه آنلاین...", color = Color(0xFF8E94A8), style = MaterialTheme.typography.bodySmall) }
        } else if (onlineError) {
            Text("کارنامه آنلاین در دسترس نیست؛ نتایج محلی همچنان نمایش داده می‌شوند.", color = Color(0xFFE5A63B), style = MaterialTheme.typography.bodySmall)
        } else if (online.isNotEmpty()) {
            Text("نتایج همگام‌شده با سرور", fontWeight = FontWeight.Bold)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 250.dp)) {
                items(online, key = { it.id }) { item ->
                    Card(Modifier.fillMaxWidth(), RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = if (LocalMazDark.current) Color(0xFF141A2A) else Color.White)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(examTitles[item.examId] ?: "آزمون شماره ${item.examId}", fontWeight = FontWeight.SemiBold)
                                Text("${persianNumber(item.correct)} درست • ${persianNumber(item.wrong)} غلط • ${persianNumber(item.unanswered)} نزده", color = Color(0xFF8E94A8), style = MaterialTheme.typography.bodySmall)
                                Text(item.createdAt.replace('T', ' ').take(16), color = Color(0xFF8E94A8), style = MaterialTheme.typography.labelSmall)
                            }
                            Text("${persianNumber(item.percent.toInt())}٪", color = Indigo, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        if (online.isNotEmpty()) {
            val onlineAverage = online.map { it.percent }.average().toInt()
            Text("روند عملکرد", fontWeight = FontWeight.Bold)
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = if (LocalMazDark.current) Color(0xFF141A2A) else Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("میانگین نتایج آنلاین", color = Color(0xFF8E94A8), style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.weight(1f))
                        Text("${persianNumber(onlineAverage)}٪", color = Indigo, fontWeight = FontWeight.Bold)
                    }
                    online.take(6).forEach { item ->
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(examTitles[item.examId] ?: "آزمون ${item.examId}", maxLines = 1, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                Text("${persianNumber(item.percent.toInt())}٪", style = MaterialTheme.typography.bodySmall, color = Indigo)
                            }
                            LinearProgressIndicator(progress = { (item.percent / 100f).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(6.dp), color = Indigo, trackColor = Indigo.copy(alpha = .12f))
                        }
                    }
                }
            }
        }
        Text("سابقه روی دستگاه", fontWeight = FontWeight.Bold)
        if (entries.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) { Text("هنوز آزمونی ثبت نشده است.", color = Color(0xFF8E94A8)) }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(entries.size) { index ->
                    val e = entries[index]
                    Card(Modifier.fillMaxWidth().clickable { onOpen(index) }, RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = if (LocalMazDark.current) Color(0xFF171B3A) else Color.White)) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(Modifier.size(48.dp), RoundedCornerShape(15.dp), color = Indigo.copy(alpha = .18f)) { Box(contentAlignment = Alignment.Center) { Text("%", color = Indigo, fontWeight = FontWeight.Bold) } }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("آزمون شماره ${e.examId}", fontWeight = FontWeight.Bold)
                                Text("${persianNumber(e.correct)} درست • ${persianNumber(e.wrong)} غلط • ${persianNumber(e.percent)}٪", color = Color(0xFF8E94A8), style = MaterialTheme.typography.bodySmall)
                                Text(formatHistoryDate(e.timestamp), color = Color(0xFF8E94A8), style = MaterialTheme.typography.labelSmall)
                            }
                            Text("›", color = Indigo, style = MaterialTheme.typography.headlineMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryDetailScreen(index: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    val entry = ExamHistoryStore.all(context).getOrNull(index)
    Column(Modifier.fillMaxSize().background(mazBg()).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("جزئیات کارنامه", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        if (entry == null) { Text("نتیجه پیدا نشد.") } else {
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = if (LocalMazDark.current) Color(0xFF171B3A) else Color.White)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("آزمون شماره ${entry.examId}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("${persianNumber(entry.percent)}٪", style = MaterialTheme.typography.displaySmall, color = Indigo, fontWeight = FontWeight.Bold)
                    Text("${persianNumber(entry.total)} سؤال", color = Color(0xFF8E94A8))
                    Text(formatHistoryDate(entry.timestamp), color = Color(0xFF8E94A8), style = MaterialTheme.typography.bodySmall)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ResultStat("درست", persianNumber(entry.correct), Color(0xFF35B982), Modifier.weight(1f))
                ResultStat("غلط", persianNumber(entry.wrong), Color(0xFFE95B72), Modifier.weight(1f))
                ResultStat("بی‌پاسخ", persianNumber(entry.unanswered), Color(0xFFE5A63B), Modifier.weight(1f))
            }
            ResultStat("زمان استفاده‌شده", formatTime(entry.usedSeconds), Indigo, Modifier.fillMaxWidth())
        }
        OutlinedButton(onClick = onBack, Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("بازگشت") }
    }
}

@Composable
fun ProfileScreen(isDark: Boolean, onToggleTheme: () -> Unit, onLogout: () -> Unit) {
    val dark = LocalMazDark.current
    val panel = if (dark) Color(0xFF141A2A) else Color.White
    val softPanel = if (dark) Color(0xFF111622) else Color(0xFFEDEFFC)
    val primaryText = if (dark) Color(0xFFF4F2FF) else Color(0xFF202236)
    val secondaryText = if (dark) Color(0xFF8E94A8) else Color(0xFF68708A)
    Column(Modifier.fillMaxSize().background(mazBg()).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("پروفایل", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = primaryText)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onToggleTheme) {
                Text(if (isDark) "☀" else "☾", color = if (isDark) Color(0xFFFFD76A) else Indigo, style = MaterialTheme.typography.headlineSmall)
            }
        }
        Card(Modifier.fillMaxWidth(), RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = panel)) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(Modifier.size(70.dp), CircleShape, color = Color(0xFF1D5FEA)) { Box(contentAlignment = Alignment.Center) { Text("م", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("کاربر Maz-Archive", fontWeight = FontWeight.Bold, color = primaryText, style = MaterialTheme.typography.titleMedium)
                    Text("حساب کاربری شما", color = secondaryText, style = MaterialTheme.typography.bodySmall)
                }
                Text("›", color = Indigo, style = MaterialTheme.typography.headlineMedium)
            }
        }
        Card(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = if (dark) Color(0xFF171B3A) else Color(0xFFE8E7FF))) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("تاریخچه آزمون", fontWeight = FontWeight.Bold, color = primaryText, style = MaterialTheme.typography.titleMedium)
                Text("${persianNumber(ExamHistoryStore.count(LocalContext.current))} آزمون ثبت‌شده", color = Indigo, style = MaterialTheme.typography.bodyMedium)
                Text("مرور آزمون‌های قبلی شما", color = secondaryText, style = MaterialTheme.typography.bodySmall)
            }
        }
        listOf("حالت نمایش" to (if (isDark) "تاریک" else "روشن"), "اطلاعات برنامه" to "نسخه ۱.۰.۰", "درباره ما" to "آشنایی با Maz-Archive", "تماس با ما" to "پشتیبانی و ارتباط").forEach { (title, subtitle) ->
            Card(Modifier.fillMaxWidth().clickable { if (title == "حالت نمایش") onToggleTheme() }, RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = softPanel)) {
                Row(Modifier.padding(horizontal = 17.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(title, color = primaryText, fontWeight = FontWeight.SemiBold)
                        Text(subtitle, color = secondaryText, style = MaterialTheme.typography.bodySmall)
                    }
                    Text("›", color = Indigo, style = MaterialTheme.typography.headlineSmall)
                }
            }
        }
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp)) { Text("خروج از حساب", color = Color(0xFFFF6B7A), fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun FilterPanel(
    year: Int?, setYear: (Int?) -> Unit,
    period: String?, setPeriod: (String?) -> Unit,
    month: String?, setMonth: (String?) -> Unit
) {
    Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), color = Color(0xFF111522)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("فیلتر آزمون‌ها", fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(1404, 1403, 1402).forEach { value -> FilterChip(year == value, { setYear(if (year == value) null else value) }, label = { Text(value.toString()) }) } }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("تابستانه", "شروع از مهر").forEach { value -> FilterChip(period == value, { setPeriod(if (period == value) null else value) }, label = { Text(value) }) } }
            val months = if (period == "تابستانه") listOf("تیر", "مرداد", "شهریور") else listOf("مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) { months.forEach { value -> FilterChip(month == value, { setMonth(if (month == value) null else value) }, label = { Text(value) }) } }
        }
    }
}

@Composable
fun ExamDetail(id: Long, startExam: (Long) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val api = remember { ApiFactory.create(BuildConfig.API_BASE_URL) { com.mazarchive.app.data.AuthStore(context).token() } }
    var exam by remember(id) { mutableStateOf<Exam?>(null) }
    var loading by remember(id) { mutableStateOf(true) }
    var error by remember(id) { mutableStateOf<String?>(null) }

    fun loadExam() = scope.launch {
        loading = true
        error = null
        runCatching { api.exam(id) }
            .onSuccess { exam = it }
            .onFailure { error = "اطلاعات آزمون از سرور دریافت نشد. اتصال اینترنت را بررسی کنید." }
        loading = false
    }

    LaunchedEffect(id) { loadExam() }

    Column(
        Modifier.fillMaxSize().background(mazBg()).verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("جزئیات آزمون", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        when {
            loading -> Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Indigo)
            }
            error != null -> Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(error!!, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.error)
                TextButton(onClick = { loadExam() }) { Text("تلاش دوباره") }
            }
            exam != null -> {
                val item = exam!!
                Card(
                    Modifier.fillMaxWidth(), RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = if (LocalMazDark.current) Color(0xFF171B3A) else MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(item.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = if (LocalMazDark.current) Color.White else Color(0xFF171717))
                        Text("پایه ${item.grade} • رشته ${item.field}", color = if (LocalMazDark.current) Color(0xFFE8E8F2) else Color(0xFF333333))
                        Text("${item.examDate} • ${item.month} • ${item.year}", color = if (LocalMazDark.current) Color(0xFFE8E8F2) else Color(0xFF333333), style = MaterialTheme.typography.bodySmall)
                        item.examNumber?.let { Text("شماره آزمون: $it", style = MaterialTheme.typography.bodySmall, color = if (LocalMazDark.current) Color(0xFFE8E8F2) else Color(0xFF333333)) }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                color = Indigo.copy(alpha = 0.12f)
                            ) {
                                Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("تعداد سؤال", style = MaterialTheme.typography.labelMedium, color = if (LocalMazDark.current) Color(0xFFE8E8F2) else Color(0xFF333333))
                                    Text("${item.questionCount} سؤال", fontWeight = FontWeight.Bold, color = if (LocalMazDark.current) Color.White else Color(0xFF171717))
                                }
                            }
                            Surface(
                                Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                color = Indigo.copy(alpha = 0.12f)
                            ) {
                                Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("مدت آزمون", style = MaterialTheme.typography.labelMedium, color = if (LocalMazDark.current) Color(0xFFE8E8F2) else Color(0xFF333333))
                                    Text("${(item.durationSeconds / 60).coerceAtLeast(1)} دقیقه", fontWeight = FontWeight.Bold, color = if (LocalMazDark.current) Color.White else Color(0xFF171717))
                                }
                            }
                        }
                        Text("سؤال‌ها از سرور دریافت می‌شوند و آزمون داخل برنامه اجرا خواهد شد.", style = MaterialTheme.typography.bodySmall, color = if (LocalMazDark.current) Color(0xFFE8E8F2) else Color(0xFF333333))
                    }
                }
                Button(onClick = { startExam(item.id) }, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                    Text("شروع آزمون  ▶", style = MaterialTheme.typography.titleMedium)
                }
                Text("نحوه برگزاری", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = if (LocalMazDark.current) Color.White else Color(0xFF171717))
                Text("سؤال‌ها داخل برنامه نمایش داده می‌شوند. زمان آزمون واقعی است و با پایان زمان، آزمون به‌صورت خودکار ثبت می‌شود.", color = if (LocalMazDark.current) Color(0xFFE8E8F2) else Color(0xFF333333))
            }
        }
    }
}

@Composable
fun ExamPlayer(examId: Long, onFinished: (ExamResult) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val api = remember { ApiFactory.create(BuildConfig.API_BASE_URL) { com.mazarchive.app.data.AuthStore(context).token() } }
    var exam by remember(examId) { mutableStateOf<Exam?>(null) }
    var pdfFile by remember(examId) { mutableStateOf<java.io.File?>(null) }
    var loadError by remember(examId) { mutableStateOf(false) }
    var pdfErrorMessage by remember(examId) { mutableStateOf<String?>(null) }
    var selectedAnswers by rememberSaveable(examId) { mutableStateOf<Map<Int, Int>>(emptyMap()) }
    var showAnswerSheet by rememberSaveable(examId) { mutableStateOf(false) }
    var remainingSeconds by rememberSaveable(examId) { mutableStateOf<Int?>(null) }
    var timerFinished by rememberSaveable(examId) { mutableStateOf(false) }
    var showFinishDialog by rememberSaveable(examId) { mutableStateOf(false) }

    LaunchedEffect(examId) {
        runCatching { api.exam(examId) }
            .onSuccess { loaded ->
                exam = loaded.copy(questionCount = loaded.questionCount.coerceIn(1, 500))
                pdfErrorMessage = null
                pdfFile = null
                remainingSeconds = loaded.durationSeconds.coerceAtLeast(1)
                timerFinished = false
                if (loaded.pdfUrl.isBlank()) {
                    pdfErrorMessage = "آدرس فایل PDF برای این آزمون در سرور ثبت نشده است."
                } else {
                    pdfFile = runCatching {
                        withContext(Dispatchers.IO) {
                            val f = java.io.File.createTempFile("maz-exam-$examId-", ".pdf", context.cacheDir)
                        val connection = (java.net.URL("${BuildConfig.API_BASE_URL.trimEnd('/')}/exams/$examId/pdf").openConnection() as java.net.HttpURLConnection).apply {
                            requestMethod = "GET"
                            connectTimeout = 30_000
                            readTimeout = 180_000
                        }
                        try {
                            val responseCode = connection.responseCode
                            if (responseCode !in 200..299) {
                                throw java.io.IOException("PDF_HTTP_$responseCode")
                            }
                            connection.inputStream.use { input ->
                                f.outputStream().use { output -> input.copyTo(output) }
                            }
                        } finally {
                            connection.disconnect()
                        }
                            f
                        }
                    }.onFailure { error ->
                        val errorText = error.message.orEmpty()
                        pdfErrorMessage = when {
                            error is java.net.SocketTimeoutException ->
                                "زمان دریافت فایل PDF تمام شد؛ اتصال اینترنت یا سرور را بررسی کنید."
                            error is java.net.UnknownHostException ->
                                "آدرس سرور پیدا نشد؛ اتصال اینترنت و آدرس سرور را بررسی کنید."
                            errorText == "PDF_HTTP_404" ->
                                "فایل PDF در سرور پیدا نشد (HTTP 404). احتمالاً فایل حذف شده یا فضای ذخیره‌سازی Render پاک شده است."
                            errorText == "PDF_HTTP_401" || errorText == "PDF_HTTP_403" ->
                                "دسترسی به فایل PDF مجاز نیست (HTTP ${errorText.removePrefix("PDF_HTTP_")})."
                            errorText.startsWith("PDF_HTTP_") ->
                                "سرور هنگام دریافت PDF خطای HTTP ${errorText.removePrefix("PDF_HTTP_")} برگرداند."
                            error is java.io.FileNotFoundException ->
                                "فایل PDF در مسیر سرور پیدا نشد."
                            else ->
                                "دریافت PDF با خطای فنی مواجه شد: ${errorText.ifBlank { error::class.simpleName ?: "نامشخص" }}"
                        }
                    }.getOrNull()
                }
            }
            .onFailure { loadError = true }
    }

    if (loadError) {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("اطلاعات آزمون دریافت نشد.")
            Button(onClick = { scope.launch { runCatching { api.exam(examId) }.onSuccess { exam = it; loadError = false } } }) { Text("تلاش دوباره") }
        }
        return
    }
    val currentExam = exam ?: run {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Indigo) }
        return
    }
    val total = currentExam.questionCount.coerceIn(1, 500)

    LaunchedEffect(examId, currentExam.durationSeconds, timerFinished) {
        if (timerFinished) return@LaunchedEffect
        while ((remainingSeconds ?: 0) > 0) {
            delay(1000)
            remainingSeconds = ((remainingSeconds ?: 1) - 1).coerceAtLeast(0)
        }
        if (!timerFinished && remainingSeconds == 0) {
            timerFinished = true
            onFinished(ExamResult(selectedAnswers, currentExam.durationSeconds, true, total))
        }
    }
    val timeText = remainingSeconds?.let { seconds ->
        String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
    } ?: "--:--"
    fun submitExamManually() {
        if (!timerFinished) {
            timerFinished = true
            val duration = currentExam.durationSeconds.coerceAtLeast(1)
            val left = remainingSeconds ?: duration
            onFinished(ExamResult(selectedAnswers, (duration - left).coerceAtLeast(0), false, total))
        }
    }

    if (showFinishDialog) {
        AlertDialog(
            onDismissRequest = { showFinishDialog = false },
            title = { Text("اتمام آزمون") },
            text = { Text("آیا مطمئن هستید که می‌خواهید آزمون را همین حالا پایان دهید؟ پاسخ‌های ثبت‌شده شما ذخیره و نتیجه نمایش داده می‌شود.") },
            confirmButton = {
                TextButton(onClick = {
                    showFinishDialog = false
                    submitExamManually()
                }) { Text("بله، پایان آزمون") }
            },
            dismissButton = {
                TextButton(onClick = { showFinishDialog = false }) { Text("انصراف") }
            }
        )
    }

    if (!showAnswerSheet) {
        Column(
            Modifier.fillMaxSize().background(mazBg()).padding(vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text("آزمون: ${currentExam.title}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("نمایش PDF آزمون", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Surface(shape = RoundedCornerShape(12.dp), color = if ((remainingSeconds ?: 0) <= 60) Color(0xFF7F2635) else Indigo) {
                    Text("⏱ $timeText", modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Button(onClick = { showAnswerSheet = true }) {
                    Text("نمایش پاسخ‌نامه")
                }
            }
            Button(
                onClick = { showFinishDialog = true },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3263E)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("اتمام آزمون", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Box(Modifier.fillMaxWidth().weight(1f)) {
                if (pdfFile != null) {
                    PdfCanvas(pdfFile!!, emptyList(), {}, PenTool.PEN, 5f, Color.Red)
                } else {
                    Card(Modifier.fillMaxSize()) {
                        Box(
                            Modifier.fillMaxSize().padding(20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    "PDF این آزمون در دسترس نیست",
                                    textAlign = TextAlign.Center,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                pdfErrorMessage?.let { reason ->
                                    Text(
                                        "علت:\n$reason",
                                        modifier = Modifier.fillMaxWidth(),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        style = MaterialTheme.typography.bodyMedium,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        Column(
            Modifier.fillMaxSize().background(mazBg()).padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("پاسخ‌نامه مستقل", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = { showAnswerSheet = false }) {
                    Text("بازگشت به PDF")
                }
            }
            Text("آزمون: ${currentExam.title}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items((1..total).toList()) { questionNumber ->
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
                        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${persianNumber(questionNumber)}", modifier = Modifier.width(28.dp), fontWeight = FontWeight.Bold)
                            (0..3).forEach { option ->
                                val selected = selectedAnswers[questionNumber] == option
                                OutlinedButton(onClick = { selectedAnswers = selectedAnswers + (questionNumber to option) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 0.dp, vertical = 5.dp), colors = ButtonDefaults.outlinedButtonColors(containerColor = if (selected) Indigo else Color.Transparent, contentColor = if (selected) Color.White else MaterialTheme.colorScheme.onSurface), border = BorderStroke(1.dp, if (selected) Indigo else MaterialTheme.colorScheme.outline)) { Text(persianNumber(option + 1)) }
                            }
                        }
                    }
                }
            }
            Button(onClick = { showFinishDialog = true }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3263E))) { Text("اتمام آزمون", color = Color.White) }
            OutlinedButton(onClick = { showAnswerSheet = false }, Modifier.fillMaxWidth()) { Text("بازگشت به PDF") }
        }
    }
}

@Composable
fun ExamResultScreen(examId: Long, onHome: () -> Unit) {
    var showReview by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    val api = remember { ApiFactory.create(BuildConfig.API_BASE_URL) { com.mazarchive.app.data.AuthStore(context).token() } }
    val result = LatestExamResultHolder.result
    var answerKey by remember(examId) { mutableStateOf<Map<Int, Int>>(emptyMap()) }
    LaunchedEffect(examId) { answerKey = runCatching { api.answerKey(examId).answers.associate { it.questionNumber to (it.correctOption - 1) } }.getOrDefault(emptyMap()) }
    val questions = remember(result) { sampleQuestions(result?.total ?: 0) }
    val correct = remember(result, answerKey) { if (result == null) 0 else result.answers.count { (answerKey[it.key] != null) && answerKey[it.key] == it.value } }
    val unanswered = remember(result) { if (result == null) questions.size else questions.count { !result.answers.containsKey(it.id) } }
    val wrong = questions.size - correct - unanswered
    val percent = if (questions.isEmpty()) 0 else correct * 100 / questions.size

    if (showReview) {
        Column(
            Modifier.fillMaxSize().background(mazBg()).verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("مرور پاسخ‌ها", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("آزمون شماره $examId", color = Color(0xFF979CAF))
            questions.forEach { q ->
                Card(
                    Modifier.fillMaxWidth(),
                    RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A))
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("سؤال ${persianNumber(q.id)}", color = Color(0xFFBDB4FF), fontWeight = FontWeight.Bold)
                        Text(q.text)
                        val chosen = result?.answers?.get(q.id)
                        Text(
                            "پاسخ شما: ${if (chosen == null) "بی‌پاسخ" else q.options[chosen]}",
                            color = if (answerKey[q.id] != null && chosen == answerKey[q.id]) Color(0xFF8FE3C0) else Color(0xFFFF9AA7),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text("پاسخ صحیح: ${answerKey[q.id]?.let { q.options[it] } ?: "در کلید ثبت نشده"}", color = Color(0xFF8FE3C0), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Button(onClick = onHome, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) { Text("بازگشت به خانه") }
        }
        return
    }

    Column(
        Modifier.fillMaxSize().background(mazBg()).verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("آزمون به پایان رسید", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(
            Modifier.fillMaxWidth(),
            RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171B3A))
        ) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ریاضی دهم", color = Color(0xFFB8B0FF))
                Text("$percent٪", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, color = Color(0xFFD1CAFF))
                Text("امتیاز آزمون", color = Color(0xFF8F94A8))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ResultStat("صحیح", correct.toString(), Color(0xFF76E1B4), Modifier.weight(1f))
            ResultStat("غلط", wrong.toString(), Color(0xFFFF7585), Modifier.weight(1f))
            ResultStat("بی‌پاسخ", unanswered.toString(), Color(0xFFFFC86B), Modifier.weight(1f))
        }
        ResultStat(
            "زمان استفاده‌شده",
            formatTime(result?.usedSeconds ?: 0),
            Color(0xFFBDB4FF),
            Modifier.fillMaxWidth()
        )
        Button(onClick = { showReview = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
            Text("مشاهده پاسخ‌ها")
        }
        OutlinedButton(onClick = onHome, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
            Text("بازگشت به خانه")
        }
    }
}

@Composable
fun ResultStat(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A))) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = color, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(label, color = Color(0xFF8E94A8), style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun PdfScreen(url: String, onBack: () -> Unit) {
    var file by remember { mutableStateOf<java.io.File?>(null) }
    var tool by remember { mutableStateOf(PenTool.PEN) }
    var width by remember { mutableFloatStateOf(5f) }
    var color by remember { mutableStateOf(Color.Red) }
    var tools by remember { mutableStateOf(false) }
    var strokes by remember { mutableStateOf(listOf<Stroke>()) }
    var redo by remember { mutableStateOf(listOf<Stroke>()) }

    LaunchedEffect(url) {
        file = runCatching {
            withContext(Dispatchers.IO) {
                val f = java.io.File.createTempFile("maz-", ".pdf")
                java.net.URL(url).openStream().use { input ->
                    f.outputStream().use { output -> input.copyTo(output) }
                }
                f
            }
        }.getOrNull()
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(
            Modifier.fillMaxWidth().height(48.dp).background(Color(0xFF101014)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("←") }
            TextButton(onClick = { tools = !tools }) { Text("✏️") }
            TextButton(
                onClick = {
                    val last = strokes.last()
                    strokes = strokes.dropLast(1)
                    redo = redo + last
                },
                enabled = strokes.isNotEmpty()
            ) { Text("↶") }
            TextButton(
                onClick = {
                    val last = redo.last()
                    redo = redo.dropLast(1)
                    strokes = strokes + last
                },
                enabled = redo.isNotEmpty()
            ) { Text("↷") }
        }
        if (tools) {
            Surface(color = Color(0xFF17171D)) {
                Column(Modifier.padding(10.dp)) {
                    Row {
                        listOf(
                            PenTool.PEN to "قلم",
                            PenTool.HIGHLIGHTER to "هایلایتر",
                            PenTool.ERASER to "پاک‌کن"
                        ).forEach { (t, label) ->
                            FilterChip(
                                selected = tool == t,
                                onClick = { tool = t; tools = false },
                                label = { Text(label) }
                            )
                        }
                    }
                    Row {
                        listOf(3f to "نازک", 6f to "متوسط", 12f to "ضخیم").forEach { (w, label) ->
                            FilterChip(
                                selected = width == w,
                                onClick = { width = w },
                                label = { Text(label) }
                            )
                        }
                    }
                    Row {
                        listOf(
                            Color.Black to "مشکی",
                            Color.Red to "قرمز",
                            Color.Blue to "آبی",
                            Color.Green to "سبز"
                        ).forEach { (c, label) ->
                            FilterChip(
                                selected = color == c,
                                onClick = { color = c },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }
        }
        file?.let { pdfFile ->
            PdfCanvas(pdfFile, strokes, { stroke ->
                strokes = strokes + stroke
                redo = emptyList()
            }, tool, width, color)
        } ?: Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) { CircularProgressIndicator() }
    }
}

@Composable
fun PdfCanvas(
    file: java.io.File,
    strokes: List<Stroke>,
    add: (Stroke) -> Unit,
    tool: PenTool,
    width: Float,
    color: Color
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    val renderer = remember(file) {
        PdfRenderer(ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY))
    }
    DisposableEffect(renderer) {
        onDispose { renderer.close() }
    }
    val pages = renderer.pageCount
    val bitmaps = remember(file) {
        (0 until pages).map { pageIndex ->
            renderer.openPage(pageIndex).let { page ->
                Bitmap.createBitmap(page.width, page.height, Bitmap.Config.ARGB_8888).also { bitmap ->
                    // PdfRenderer may leave transparent PDF backgrounds as black.
                    // Paint a white page background first so dark PDF text remains readable.
                    bitmap.eraseColor(android.graphics.Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()
                }
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 4f)
                    offset += pan
                }
            }
    ) {
        Surface(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp),
            shape = RoundedCornerShape(12.dp),
            color = Color.Black.copy(alpha = 0.72f),
            tonalElevation = 4.dp
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "تعداد صفحات: ${persianNumber(pages)}",
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge
                )
                TextButton(
                    onClick = {
                        scale = 1f
                        offset = androidx.compose.ui.geometry.Offset.Zero
                    }
                ) {
                    Text("بازنشانی", color = Color.White)
                }
            }
        }
        Column(
            Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(top = 54.dp)
                .verticalScroll(rememberScrollState())
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
        ) {
            bitmaps.forEachIndexed { pageIndex, bitmap ->
                Box(
                    Modifier.fillMaxWidth()
                ) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Canvas(
                        Modifier
                            .matchParentSize()
                            .pointerInput(tool, width, color, pageIndex) {
                                val points = mutableListOf<androidx.compose.ui.geometry.Offset>()
                                awaitPointerEventScope {
                                    while (true) {
                                        val event = awaitPointerEvent()
                                        if (event.changes.size == 1 && event.changes[0].pressed) {
                                            val change = event.changes[0]
                                            points += androidx.compose.ui.geometry.Offset(
                                                (change.position.x / size.width).coerceIn(0f, 1f),
                                                (change.position.y / size.height).coerceIn(0f, 1f)
                                            )
                                        } else if (points.isNotEmpty()) {
                                            add(
                                                Stroke(
                                                    page = pageIndex,
                                                    points = points.toList(),
                                                    color = if (tool == PenTool.ERASER) Color.Transparent else color,
                                                    width = width,
                                                    alpha = if (tool == PenTool.HIGHLIGHTER) 0.35f else 1f,
                                                    tool = tool
                                                )
                                            )
                                            points.clear()
                                        }
                                    }
                                }
                            }
                    ) {
                        strokes
                            .filter { it.page == pageIndex && it.points.size > 1 }
                            .forEach { stroke ->
                                val path = Path()
                                path.moveTo(
                                    stroke.points[0].x * size.width,
                                    stroke.points[0].y * size.height
                                )
                                stroke.points.drop(1).forEach { point ->
                                    path.lineTo(point.x * size.width, point.y * size.height)
                                }
                                drawPath(
                                    path = path,
                                    color = stroke.color.copy(alpha = stroke.alpha),
                                    style = DrawStroke(width = stroke.width)
                                )
                            }
                    }
                }
            }
        }
        Text(
            "1 / $pages",
            Modifier.align(Alignment.CenterEnd).padding(6.dp),
            color = Color.White
        )
    }
}
