# MazArchive Stage 110 — User Support Thread

Changes:
- Added Android API model for support messages.
- Added Android API endpoint for `/support/tickets/{id}/messages`.
- Added user-side list of submitted support tickets.
- Added ticket status display in Persian.
- Added expandable-style message retrieval per ticket, including admin replies.

Verification:
- Source-level inspection completed.
- Android Gradle build was not run because this checkout has no Gradle wrapper and the environment has no `gradle` executable.
