# Phase 31 — Workflow diagnostics hardening

Changes:
- Set a workspace-local `GRADLE_USER_HOME` for more predictable Gradle caching.
- Expanded `sdkmanager` discovery to include `cmdline-tools/latest`, `cmdline-tools/bin`, and `tools/bin`.
- Added explicit non-empty validation for the discovered sdkmanager path in both install and verification steps.

Verification:
- Static inspection of the workflow was completed.
- GitHub Actions execution and APK compilation were not run in this environment.
