# Stage 67 — GitHub Actions Android SDK Fix

- Uses the Android SDK manager from `ANDROID_HOME/cmdline-tools/latest/bin` when available.
- Falls back to `sdkmanager` on PATH.
- Uses strict shell mode for SDK installation and verification.
- Keeps the existing Java 17, Gradle 8.10.2, Android API 35 and build-tools 35.0.0 settings.
- The workflow must be run in GitHub Actions to verify the hosted environment; local Build was unavailable because Gradle is not installed in the current container.
