# Stage 51 — Archive Metadata

Adds `/exams/{id}/archive-metadata` and the Android `ArchiveMetadataDto` model for displaying year, grade, field, period, month, date, description, and PDF availability.
