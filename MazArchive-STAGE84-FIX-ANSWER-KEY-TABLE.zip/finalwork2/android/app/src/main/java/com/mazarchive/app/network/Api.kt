package com.mazarchive.app.network

import com.mazarchive.app.Exam
import com.mazarchive.app.AnnotationPayload
import retrofit2.http.*
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import okhttp3.MediaType.Companion.toMediaType
import kotlinx.serialization.json.Json
import java.util.concurrent.TimeUnit

@kotlinx.serialization.Serializable
data class AdminExamPayload(
    val id: Long = 0, val title: String, val grade: String, val field: String,
    val examNumber: Int? = null, val examDate: String, val year: Int,
    val period: String, val month: String, val description: String = "",
    val pdfUrl: String = "", val durationSeconds: Int = 1800, val questionCount: Int = 40
)

@kotlinx.serialization.Serializable
data class CreateExamPayload(
    val title: String, val grade: String, val field: String,
    val examNumber: Int? = null, val examDate: String, val year: Int,
    val period: String, val month: String, val description: String = "",
    val durationSeconds: Int = 1800, val questionCount: Int = 40
)



@kotlinx.serialization.Serializable
data class ArchiveMetadataDto(
    val id: Long = 0,
    val title: String = "",
    val grade: String = "",
    val field: String = "",
    val year: Int = 0,
    val period: String = "",
    val month: String = "",
    val examDate: String = "",
    val description: String = "",
    val hasPdf: Boolean = false
)

@kotlinx.serialization.Serializable
data class PdfUploadResponse(
    val ok: Boolean,
    val examId: Long = 0,
    val message: String = ""
)

@kotlinx.serialization.Serializable
data class ApiErrorDto(
    val ok: Boolean = false,
    val code: String = "UNKNOWN_ERROR",
    val stage: String = "UNKNOWN",
    val message: String = "خطای نامشخص",
    val details: String = "",
    val examId: Long? = null
)

@kotlinx.serialization.Serializable
data class AnswerKeyItem(val questionNumber: Int, val correctOption: Int)
@kotlinx.serialization.Serializable
data class AnswerKeyPayload(val answers: List<AnswerKeyItem> = emptyList())

@kotlinx.serialization.Serializable
data class AttemptRequest(val examId: Long, val correct: Int, val wrong: Int, val unanswered: Int, val total: Int, val percent: Float, val usedSeconds: Int, val submittedByTime: Boolean = false)
@kotlinx.serialization.Serializable
data class AttemptDto(val id: Long, val examId: Long, val correct: Int, val wrong: Int, val unanswered: Int, val total: Int, val percent: Float, val usedSeconds: Int, val submittedByTime: Boolean, val createdAt: String)

interface MazApi {
    @GET("exams") suspend fun exams(
        @Query("grade") grade:String?=null, @Query("field") field:String?=null,
        @Query("year") year:Int?=null, @Query("period") period:String?=null,
        @Query("month") month:String?=null, @Query("q") q:String?=null
    ):List<Exam>
    @GET("exams/{id}") suspend fun exam(@Path("id") id:Long):Exam
    @GET("exams/{id}/archive-metadata") suspend fun archiveMetadata(@Path("id") id:Long):ArchiveMetadataDto
    @GET("admin/exams") suspend fun adminExams():List<AdminExamPayload>
    @POST("admin/exams") suspend fun createAdminExam(@Body exam:CreateExamPayload):AdminExamPayload
    @PUT("admin/exams/{id}") suspend fun updateAdminExam(@Path("id") id:Long,@Body exam:AdminExamPayload):AdminExamPayload
    @Headers("Content-Type: application/pdf")
    @POST("admin/exams/{id}/pdf") suspend fun uploadExamPdf(@Path("id") id:Long, @Body pdf: RequestBody): PdfUploadResponse
    @DELETE("admin/exams/{id}") suspend fun deleteAdminExam(@Path("id") id:Long)
    @GET("exams/{id}/answer-key") suspend fun answerKey(@Path("id") id:Long):AnswerKeyPayload
    @GET("admin/exams/{id}/answer-key") suspend fun adminAnswerKey(@Path("id") id:Long):AnswerKeyPayload
    @PUT("admin/exams/{id}/answer-key") suspend fun saveAnswerKey(@Path("id") id:Long, @Body payload:AnswerKeyPayload):AnswerKeyPayload
    @GET("attempts") suspend fun attempts():List<AttemptDto>
    @POST("attempts") suspend fun createAttempt(@Body attempt:AttemptRequest):Map<String, Long>
    @GET("exams/{id}/annotations") suspend fun annotations(@Path("id") id:Long):List<AnnotationPayload>
    @POST("exams/{id}/annotations") suspend fun createAnnotation(@Path("id") id:Long,@Body a:AnnotationPayload):AnnotationPayload
    @PUT("annotations/{id}") suspend fun updateAnnotation(@Path("id") id:String,@Body a:AnnotationPayload):AnnotationPayload
    @DELETE("annotations/{id}") suspend fun deleteAnnotation(@Path("id") id:String)
}
object ApiFactory {
    fun create(baseUrl:String, tokenProvider:()->String? = { null }):MazApi {
        val client = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(180, TimeUnit.SECONDS)
            .writeTimeout(180, TimeUnit.SECONDS)
            .callTimeout(240, TimeUnit.SECONDS)
            .addInterceptor(AuthInterceptor(tokenProvider))
            .build()
        return Retrofit.Builder().baseUrl(baseUrl)
            .client(client).addConverterFactory(Json{ignoreUnknownKeys=true}.asConverterFactory("application/json".toMediaType())).build()
            .create(MazApi::class.java)
    }
}
