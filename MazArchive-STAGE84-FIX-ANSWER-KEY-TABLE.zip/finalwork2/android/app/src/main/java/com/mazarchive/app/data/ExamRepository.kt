package com.mazarchive.app.data

import com.mazarchive.app.Exam
import com.mazarchive.app.AnnotationEntity
import com.mazarchive.app.AnnotationPayload
import com.mazarchive.app.network.MazApi
import com.mazarchive.app.MazDb
import kotlinx.coroutines.flow.Flow
import java.time.Instant

class ExamRepository(private val api:MazApi, private val db:MazDb) {
    suspend fun exams(grade:String?=null,field:String?=null,year:Int?=null,period:String?=null,month:String?=null,q:String?=null)=api.exams(grade,field,year,period,month,q)
    suspend fun exam(id:Long)=api.exam(id)
    fun localAnnotations(examId:Long,userId:String):Flow<List<AnnotationEntity>> =
        kotlinx.coroutines.flow.flow { emit(db.annotations().byExam(examId,userId)) }
    suspend fun saveAnnotation(a:AnnotationEntity)=db.annotations().upsert(a)
    suspend fun syncPending() {
        db.annotations().pending().forEach { a ->
            runCatching {
                api.createAnnotation(a.examId,AnnotationPayload(
                    a.id,a.userId,a.examId,a.pageNumber,a.type,a.content,a.position,a.color,a.thickness,
                    Instant.now().toString(),Instant.now().toString()))
            }.onSuccess { db.annotations().markSynced(a.id) }
        }
    }
}
