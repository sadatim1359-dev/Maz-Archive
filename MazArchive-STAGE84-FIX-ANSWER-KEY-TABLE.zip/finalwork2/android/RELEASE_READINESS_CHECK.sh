#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
required=(
  "$ROOT/settings.gradle.kts"
  "$ROOT/build.gradle.kts"
  "$ROOT/app/build.gradle.kts"
  "$ROOT/app/src/main/AndroidManifest.xml"
  "$ROOT/app/src/main/java/com/mazarchive/app/MainActivity.kt"
  "$ROOT/app/src/main/java/com/mazarchive/app/network/Api.kt"
)
for file in "${required[@]}"; do
  test -f "$file" || { echo "MISSING: $file"; exit 1; }
done
grep -q 'PdfRenderer' "$ROOT/app/src/main/java/com/mazarchive/app/MainActivity.kt"
grep -q 'archiveMetadata' "$ROOT/app/src/main/java/com/mazarchive/app/network/Api.kt"
grep -q 'compileSdk = 35' "$ROOT/app/build.gradle.kts"
grep -q 'API_BASE_URL' "$ROOT/app/build.gradle.kts"
echo "Release readiness static checks passed."
echo "Gradle compilation and device installation must be run in GitHub Actions/Android environment."
