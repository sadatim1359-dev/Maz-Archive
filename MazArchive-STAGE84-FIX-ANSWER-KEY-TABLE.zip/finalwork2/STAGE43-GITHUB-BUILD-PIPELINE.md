# Stage 43 — GitHub Build Pipeline

This stage adds a workflow that:

- Uses Java 17.
- Installs Gradle 8.10.2 explicitly, avoiding a missing `gradlew` dependency.
- Compiles the Kotlin/Ktor backend with `compileKotlin`.
- Installs Android SDK components through `android-actions/setup-android`.
- Builds the Android debug APK with `assembleDebug`.
- Uploads the generated APK as a workflow artifact.

The workflow must be executed in GitHub Actions to confirm the real build result. No successful remote build is claimed by this package.
