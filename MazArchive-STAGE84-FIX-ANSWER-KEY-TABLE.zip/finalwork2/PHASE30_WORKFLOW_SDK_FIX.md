# Phase 30 — Workflow SDK Path Fix

- Removed the self-referential `ANDROID_SDK_ROOT: ${{ env.ANDROID_HOME }}` assignment.
- Added a safe `SDK_ROOT` fallback using `ANDROID_SDK_ROOT` or `ANDROID_HOME`.
- Added fallback detection for both `cmdline-tools/latest` and `cmdline-tools/bin`.
- Used the resolved SDK root consistently for sdkmanager installation and verification.

Validation performed: source-level checks and ZIP integrity check. GitHub Actions execution and APK compilation remain unverified until the workflow is run in GitHub.
