# Stage 83 — Timer + Admin Answer Key + Real Grading

Implemented:
- Exam timer with automatic submission at zero.
- Admin question count (1–500).
- Admin answer-key editor using `question:option` pairs, e.g. `1:2,2:4,3:1`.
- PostgreSQL/Exposed answer-key table with validation and cascade delete.
- Admin GET/PUT answer-key endpoints.
- Public answer-key endpoint consumed by Android result screen.
- Result grading uses the saved answer key rather than the old sample correct answers.
- Review screen shows the saved correct option where available.

Validation limitation: Gradle wrapper is not included in this project snapshot, so a local Gradle build could not be run in this environment. ZIP integrity is checked before delivery.
