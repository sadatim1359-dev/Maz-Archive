package com.mazarchive

import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.*
import io.ktor.server.auth.*
import io.ktor.server.auth.jwt.*
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.http.content.staticResources
import io.ktor.serialization.kotlinx.json.json
import io.ktor.utils.io.jvm.javaio.toInputStream
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.javatime.*
import java.io.File
import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.util.Base64
import java.util.UUID
import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import at.favre.lib.crypto.bcrypt.BCrypt
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object Users : Table("users") {
    val id = long("id").autoIncrement()
    val username = varchar("username", 64).uniqueIndex()
    val passwordHash = varchar("password_hash", 100)
    val role = varchar("role", 16).default("USER")
    val active = bool("active").default(true)
    val createdAt = timestamp("created_at")
    val lastLoginAt = timestamp("last_login_at").nullable()
    override val primaryKey = PrimaryKey(id)
}

object Exams : Table("exams") {
    val id = long("id").autoIncrement()
    val title = text("title")
    val grade = text("grade")
    val field = text("field")
    val examNumber = integer("exam_number").nullable()
    val examDate = date("exam_date")
    val year = integer("year")
    val period = text("period")
    val month = text("month")
    val description = text("description").default("")
    val pdfUrl = text("pdf_url")
    val durationSeconds = integer("duration_seconds").default(1800)
    val questionCount = integer("question_count").default(40)
    val createdAt = timestamp("created_at")
    val updatedAt = timestamp("updated_at")
    override val primaryKey = PrimaryKey(id)
}

object ExamAnswerKeys : Table("exam_answer_keys") {
    val examId = long("exam_id").references(Exams.id, onDelete = ReferenceOption.CASCADE)
    val questionNumber = integer("question_number")
    val correctOption = integer("correct_option")
    override val primaryKey = PrimaryKey(examId, questionNumber)
}

object HomeBanners : Table("home_banners") {
    val id = long("id").autoIncrement()
    val kind = text("kind")
    val title = text("title")
    val subtitle = text("subtitle")
    val imageUrl = text("image_url")
    val examId = long("exam_id").references(Exams.id, onDelete = ReferenceOption.SET_NULL).nullable()
    val active = bool("active").default(true)
    val sortOrder = integer("sort_order").default(0)
    val createdAt = timestamp("created_at")
    val updatedAt = timestamp("updated_at")
    override val primaryKey = PrimaryKey(id)
}

object ExamAttempts : Table("exam_attempts") {
    val id = long("id").autoIncrement()
    val userKey = text("user_key")
    val examId = long("exam_id").references(Exams.id, onDelete = ReferenceOption.CASCADE)
    val correct = integer("correct")
    val wrong = integer("wrong")
    val unanswered = integer("unanswered")
    val total = integer("total")
    val percent = float("percent")
    val usedSeconds = integer("used_seconds")
    val submittedByTime = bool("submitted_by_time")
    val createdAt = timestamp("created_at")
    override val primaryKey = PrimaryKey(id)
}

object Annotations : Table("annotations") {
    val id = uuid("id")
    val userId = uuid("user_id")
    val examId = long("exam_id")
    val pageNumber = integer("page_number")
    val type = text("type")
    val content = text("content").nullable()
    val position = text("position")
    val color = text("color")
    val thickness = float("thickness")
    val createdAt = timestamp("created_at")
    val updatedAt = timestamp("updated_at")
    override val primaryKey = PrimaryKey(id)
}

@Serializable data class CreateExamDto(
    val title: String,
    val grade: String,
    val field: String,
    val examNumber: Int? = null,
    val examDate: String,
    val year: Int,
    val period: String,
    val month: String,
    val description: String = "",
    val durationSeconds: Int = 1800,
    val questionCount: Int = 40
)

@Serializable data class ExamDto(
    val id: Long = 0,
    val title: String,
    val grade: String,
    val field: String,
    val examNumber: Int? = null,
    val examDate: String,
    val year: Int,
    val period: String,
    val month: String,
    val description: String = "",
    val pdfUrl: String = "",
    val durationSeconds: Int = 1800,
    val questionCount: Int = 40
)

@Serializable data class AnswerKeyItem(val questionNumber: Int, val correctOption: Int)
@Serializable data class AnswerKeyPayload(val answers: List<AnswerKeyItem>)

@Serializable data class HomeBannerDto(
    val id: Long = 0, val kind: String = "NOTICE", val title: String, val subtitle: String = "",
    val imageUrl: String = "", val examId: Long? = null, val active: Boolean = true, val sortOrder: Int = 0
)

@Serializable data class HomeBannerListDto(val banners: List<HomeBannerDto>)
@Serializable data class HomeGradeCountDto(val grade: String, val count: Int)
@Serializable data class HomeDashboardDto(
    val totalExams: Int,
    val gradeCounts: List<HomeGradeCountDto>,
    val newestExams: List<ExamDto>,
    val recommendedExams: List<ExamDto>,
    val notices: List<HomeBannerDto>
)

@Serializable data class UserActivityPointDto(val day: String, val count: Int)
@Serializable data class RecentUserDto(val userKey: String, val lastSeen: String, val attempts: Int)
@Serializable data class UserStatsDto(
    val totalUsers: Int = 0,
    val activeUsers: Int = 0,
    val totalAttempts: Int = 0,
    val recentUsers: List<RecentUserDto> = emptyList(),
    val activity: List<UserActivityPointDto> = emptyList()
)

@Serializable data class AttemptRequest(val examId: Long, val correct: Int, val wrong: Int, val unanswered: Int, val total: Int, val percent: Float, val usedSeconds: Int, val submittedByTime: Boolean = false)
@Serializable data class AttemptDto(val id: Long, val examId: Long, val correct: Int, val wrong: Int, val unanswered: Int, val total: Int, val percent: Float, val usedSeconds: Int, val submittedByTime: Boolean, val createdAt: String)
@Serializable data class Login(val username: String, val password: String)
@Serializable data class RegisterRequest(val username: String, val password: String)
@Serializable data class ProfileDto(val username: String, val role: String, val createdAt: String, val attemptCount: Int)
@Serializable data class ChangeUsernameRequest(val username: String)
@Serializable data class ChangePasswordRequest(val currentPassword: String, val newPassword: String)
@Serializable data class Token(val token: String, val role: String)
@Serializable data class AnnotationDto(
    val id: String,
    val user_id: String,
    val exam_id: Long,
    val page_number: Int,
    val type: String,
    val content: String? = null,
    val position: String,
    val color: String,
    val thickness: Float,
    val created_at: String = "",
    val updated_at: String = ""
)

@Serializable
data class PdfUploadResponse(
    val ok: Boolean,
    val examId: Long,
    val message: String = "PDF آرشیوی ذخیره شد؛ استخراج سؤال انجام نمی‌شود."
)

fun examDto(row: ResultRow) = ExamDto(
    id = row[Exams.id], title = row[Exams.title], grade = row[Exams.grade], field = row[Exams.field],
    examNumber = row[Exams.examNumber], examDate = row[Exams.examDate].toString(), year = row[Exams.year],
    period = row[Exams.period], month = row[Exams.month], description = row[Exams.description],
    pdfUrl = row[Exams.pdfUrl], durationSeconds = row[Exams.durationSeconds], questionCount = row[Exams.questionCount]
)

fun annotationDto(row: ResultRow) = AnnotationDto(
    id = row[Annotations.id].toString(), user_id = row[Annotations.userId].toString(),
    exam_id = row[Annotations.examId], page_number = row[Annotations.pageNumber], type = row[Annotations.type],
    content = row[Annotations.content], position = row[Annotations.position], color = row[Annotations.color],
    thickness = row[Annotations.thickness], created_at = row[Annotations.createdAt].toString(),
    updated_at = row[Annotations.updatedAt].toString()
)

fun homeBannerDto(row: ResultRow) = HomeBannerDto(
    id = row[HomeBanners.id], kind = row[HomeBanners.kind], title = row[HomeBanners.title],
    subtitle = row[HomeBanners.subtitle], imageUrl = row[HomeBanners.imageUrl], examId = row[HomeBanners.examId],
    active = row[HomeBanners.active], sortOrder = row[HomeBanners.sortOrder]
)

object DevRefreshTokens : MutableMap<String, Pair<String, String>> by java.util.concurrent.ConcurrentHashMap()

object JwtAuth {
    private val secret = System.getenv("JWT_SECRET") ?: "CHANGE_ME"
    fun token(subject: String, role: String): String {
        val header = Base64.getUrlEncoder().withoutPadding().encodeToString("""{"alg":"HS256","typ":"JWT"}""".toByteArray())
        val now = java.time.Instant.now().epochSecond
        val expiresAt = now + 24 * 60 * 60
        val payloadJson = """{"sub":"$subject","role":"$role","iat":$now,"exp":$expiresAt}"""
        val payload = Base64.getUrlEncoder().withoutPadding().encodeToString(payloadJson.toByteArray())
        val data = "$header.$payload"
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(), "HmacSHA256"))
        val signature = Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(data.toByteArray()))
        return "$data.$signature"
    }
    val verifier = JWT.require(Algorithm.HMAC256(secret)).build()
}

fun main() {
    embeddedServer(Netty, port = System.getenv("PORT")?.toInt() ?: 8080, host = "0.0.0.0") {
        module()
    }.start(wait = true)
}

fun Application.module() {
    // Supports both a normal JDBC URL and Supabase's postgresql:// connection string.
    // Prefer explicit DB_USER/DB_PASSWORD when provided; otherwise read credentials
    // from DATABASE_URL without logging them.
    val configuredUrl = System.getenv("DATABASE_URL")
        ?: "jdbc:postgresql://localhost:5432/mazarchive"

    // PostgreSQL JDBC does not accept Supabase credentials embedded in the host part.
    // Extract credentials from the URI and build a clean JDBC URL containing only host/port/path.
    val uriValue = if (configuredUrl.startsWith("jdbc:")) {
        configuredUrl.removePrefix("jdbc:")
    } else {
        configuredUrl
    }

    val parsedUri = runCatching { URI(uriValue) }.getOrNull()
    val urlUserInfo = parsedUri?.userInfo
    val urlUser = urlUserInfo?.substringBefore(":")?.let {
        URLDecoder.decode(it, StandardCharsets.UTF_8)
    }
    val urlPassword = urlUserInfo?.substringAfter(":", "")?.let {
        URLDecoder.decode(it, StandardCharsets.UTF_8)
    }

    val jdbcUrl = if (parsedUri?.host != null) {
        val port = if (parsedUri.port != -1) ":${parsedUri.port}" else ""
        val path = parsedUri.rawPath.orEmpty().ifBlank { "/postgres" }
        val query = parsedUri.rawQuery?.let { "?$it" } ?: ""
        "jdbc:postgresql://${parsedUri.host}$port$path$query"
    } else if (configuredUrl.startsWith("jdbc:")) {
        configuredUrl
    } else {
        "jdbc:$configuredUrl"
    }

    val dbUser = System.getenv("DB_USER") ?: urlUser ?: "postgres"
    val dbPassword = System.getenv("DB_PASSWORD") ?: urlPassword ?: "postgres"

    val hikariConfig = HikariConfig().apply {
        jdbcUrl = jdbcUrl
        username = dbUser
        password = dbPassword
        driverClassName = "org.postgresql.Driver"
        maximumPoolSize = (System.getenv("DB_POOL_MAX") ?: "8").toIntOrNull()?.coerceIn(2, 16) ?: 8
        minimumIdle = (System.getenv("DB_POOL_MIN_IDLE") ?: "2").toIntOrNull()?.coerceIn(0, 8) ?: 2
        connectionTimeout = 10_000
        validationTimeout = 5_000
        idleTimeout = 60_000
        maxLifetime = 1_500_000
        poolName = "mazarchive-db-pool"
        isAutoCommit = false
    }
    Database.connect(HikariDataSource(hikariConfig))
    transaction {
        SchemaUtils.create(Users, Exams, ExamAnswerKeys, HomeBanners, Annotations, ExamAttempts)
        exec("ALTER TABLE exams ADD COLUMN IF NOT EXISTS description TEXT NOT NULL DEFAULT ''")
        exec("ALTER TABLE exams ADD COLUMN IF NOT EXISTS duration_seconds INTEGER NOT NULL DEFAULT 1800")
        exec("ALTER TABLE exams ADD COLUMN IF NOT EXISTS question_count INTEGER NOT NULL DEFAULT 40")
        exec("CREATE TABLE IF NOT EXISTS home_banners (id BIGSERIAL PRIMARY KEY, kind TEXT NOT NULL DEFAULT 'NOTICE', title TEXT NOT NULL, subtitle TEXT NOT NULL DEFAULT '', image_url TEXT NOT NULL DEFAULT '', exam_id BIGINT NULL REFERENCES exams(id) ON DELETE SET NULL, active BOOLEAN NOT NULL DEFAULT TRUE, sort_order INTEGER NOT NULL DEFAULT 0, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now())")
        exec("CREATE TABLE IF NOT EXISTS users (id BIGSERIAL PRIMARY KEY, username VARCHAR(64) NOT NULL UNIQUE, password_hash VARCHAR(100) NOT NULL, role VARCHAR(16) NOT NULL DEFAULT 'USER', active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), last_login_at TIMESTAMPTZ NULL)")
        exec("CREATE INDEX IF NOT EXISTS idx_exams_exam_date ON exams (exam_date DESC)")
        exec("CREATE INDEX IF NOT EXISTS idx_attempts_user_created ON exam_attempts (user_key, created_at DESC)")
        exec("CREATE INDEX IF NOT EXISTS idx_banners_active_sort ON home_banners (active, sort_order)")
    }
    install(ContentNegotiation) { json() }
    install(Authentication) {
        jwt("auth") {
            verifier(JwtAuth.verifier)
            validate { principal -> if (principal.payload.subject != null) JWTPrincipal(principal.payload) else null }
        }
    }
    routing {
        staticResources("/admin", "web")
        get("/health") { call.respond(mapOf("status" to "ok")) }
        get("/home-dashboard") {
            val dashboard = transaction {
                val all = Exams.selectAll().orderBy(Exams.examDate, SortOrder.DESC).map(::examDto)
                val counts = all.groupingBy { it.grade }.eachCount().entries.sortedBy { it.key }.map { HomeGradeCountDto(it.key, it.value) }
                val banners = HomeBanners.selectAll().where { HomeBanners.active eq true }.orderBy(HomeBanners.sortOrder, SortOrder.ASC).map(::homeBannerDto)
                HomeDashboardDto(
                    totalExams = all.size,
                    gradeCounts = counts,
                    newestExams = all.take(5),
                    recommendedExams = banners.filter { it.kind == "EXAM" }.mapNotNull { banner -> banner.examId?.let { id -> all.firstOrNull { it.id == id } } }.take(5),
                    notices = banners.filter { it.kind == "NOTICE" }.take(5)
                )
            }
            call.respond(dashboard)
        }

        get("/home-banners") {
            val banners = transaction { HomeBanners.selectAll().where { HomeBanners.active eq true }.orderBy(HomeBanners.sortOrder, SortOrder.ASC).map(::homeBannerDto) }
            call.respond(HomeBannerListDto(banners))
        }

        get("/exams/{id}/answer-key") {
            val id = call.parameters["id"]!!.toLong()
            val answers = transaction { ExamAnswerKeys.selectAll().where { ExamAnswerKeys.examId eq id }.orderBy(ExamAnswerKeys.questionNumber).map { AnswerKeyItem(it[ExamAnswerKeys.questionNumber], it[ExamAnswerKeys.correctOption]) } }
            call.respond(AnswerKeyPayload(answers))
        }

        authenticate("auth") {
            get("/me") {
                val subject = call.principal<JWTPrincipal>()!!.payload.subject
                val profile = transaction {
                    val user = Users.selectAll().where { Users.username eq subject }.singleOrNull()
                    if (user == null) null else ProfileDto(
                        username = user[Users.username], role = user[Users.role],
                        createdAt = user[Users.createdAt].toString(),
                        attemptCount = ExamAttempts.selectAll().where { ExamAttempts.userKey eq subject }.count().toInt()
                    )
                }
                if (profile == null) call.respond(HttpStatusCode.NotFound, "کاربر پیدا نشد") else call.respond(profile)
            }
            put("/me/username") {
                val subject = call.principal<JWTPrincipal>()!!.payload.subject
                val body = call.receive<ChangeUsernameRequest>()
                val username = body.username.trim()
                if (!Regex("^[A-Za-z0-9_\\u0600-\\u06FF]{3,64}$").matches(username) || username.equals("admin", true)) {
                    call.respond(HttpStatusCode.BadRequest, "نام کاربری معتبر نیست"); return@put
                }
                val changed = runCatching { transaction {
                    val existing = Users.selectAll().where { Users.username eq username }.singleOrNull()
                    if (existing != null && existing[Users.username] != subject) error("duplicate")
                    Users.update({ Users.username eq subject }) { it[Users.username] = username }
                    ExamAttempts.update({ ExamAttempts.userKey eq subject }) { it[ExamAttempts.userKey] = username }
                }}
                if (changed.isFailure) { call.respond(HttpStatusCode.Conflict, "این نام کاربری قبلاً ثبت شده است"); return@put }
                val role = transaction { Users.selectAll().where { Users.username eq username }.single()[Users.role] }
                val refresh = UUID.randomUUID().toString(); DevRefreshTokens[refresh] = username to role
                call.respond(mapOf("token" to JwtAuth.token(username, role), "role" to role, "refreshToken" to refresh))
            }
            put("/me/password") {
                val subject = call.principal<JWTPrincipal>()!!.payload.subject
                val body = call.receive<ChangePasswordRequest>()
                if (body.newPassword.length < 6) { call.respond(HttpStatusCode.BadRequest, "رمز جدید باید حداقل ۶ کاراکتر باشد"); return@put }
                val user = transaction { Users.selectAll().where { Users.username eq subject }.singleOrNull() }
                if (user == null || !BCrypt.verifyer().verify(body.currentPassword.toCharArray(), user[Users.passwordHash]).verified) {
                    call.respond(HttpStatusCode.Unauthorized, "رمز فعلی نادرست است"); return@put
                }
                val hash = BCrypt.withDefaults().hashToString(12, body.newPassword.toCharArray())
                transaction { Users.update({ Users.username eq subject }) { it[Users.passwordHash] = hash } }
                call.respond(mapOf("message" to "رمز عبور با موفقیت تغییر کرد"))
            }
            get("/attempts") {
                val userKey = call.principal<JWTPrincipal>()!!.payload.subject
                val rows = transaction { ExamAttempts.selectAll().where { ExamAttempts.userKey eq userKey }.orderBy(ExamAttempts.createdAt, SortOrder.DESC).map {
                    AttemptDto(it[ExamAttempts.id], it[ExamAttempts.examId], it[ExamAttempts.correct], it[ExamAttempts.wrong], it[ExamAttempts.unanswered], it[ExamAttempts.total], it[ExamAttempts.percent], it[ExamAttempts.usedSeconds], it[ExamAttempts.submittedByTime], it[ExamAttempts.createdAt].toString())
                } }
                call.respond(rows)
            }
            post("/attempts") {
                val userKey = call.principal<JWTPrincipal>()!!.payload.subject
                val body = call.receive<AttemptRequest>()
                if (body.total <= 0 || body.correct < 0 || body.wrong < 0 || body.unanswered < 0 || body.correct + body.wrong + body.unanswered != body.total || body.percent !in 0f..100f) {
                    call.respond(HttpStatusCode.BadRequest, "اطلاعات کارنامه نامعتبر است"); return@post
                }
                val id = transaction { ExamAttempts.insert {
                    it[ExamAttempts.userKey] = userKey
                    it[ExamAttempts.examId] = body.examId
                    it[ExamAttempts.correct] = body.correct
                    it[ExamAttempts.wrong] = body.wrong
                    it[ExamAttempts.unanswered] = body.unanswered
                    it[ExamAttempts.total] = body.total
                    it[ExamAttempts.percent] = body.percent
                    it[ExamAttempts.usedSeconds] = body.usedSeconds
                    it[ExamAttempts.submittedByTime] = body.submittedByTime
                    it[ExamAttempts.createdAt] = Instant.now()
                } get ExamAttempts.id }
                call.respond(HttpStatusCode.Created, mapOf("id" to id))
            }
        }

        post("/auth/register") {
            val body = call.receive<RegisterRequest>()
            val username = body.username.trim()
            if (username.equals("admin", ignoreCase = true) || !Regex("^[A-Za-z0-9_\\u0600-\\u06FF]{3,64}$").matches(username) || body.password.length < 6) {
                call.respond(HttpStatusCode.BadRequest, "نام کاربری یا رمز عبور معتبر نیست؛ رمز باید حداقل ۶ کاراکتر باشد.")
                return@post
            }
            val hash = BCrypt.withDefaults().hashToString(12, body.password.toCharArray())
            val created = runCatching {
                transaction {
                    Users.insert {
                        it[Users.username] = username
                        it[passwordHash] = hash
                        it[role] = "USER"
                        it[active] = true
                        it[createdAt] = Instant.now()
                    }
                }
            }
            if (created.isFailure) {
                call.respond(HttpStatusCode.Conflict, "این نام کاربری قبلاً ثبت شده است.")
                return@post
            }
            val role = "USER"
            val refresh = UUID.randomUUID().toString()
            DevRefreshTokens[refresh] = username to role
            call.respond(HttpStatusCode.Created, mapOf("token" to JwtAuth.token(username, role), "role" to role, "refreshToken" to refresh))
        }

        post("/auth/login") {
            val body = call.receive<Login>()
            val adminPassword = System.getenv("ADMIN_PASSWORD") ?: "change-me"
            val isAdmin = body.username == "admin" && body.password == adminPassword
            val user = if (!isAdmin) transaction { Users.selectAll().where { Users.username eq body.username.trim() }.singleOrNull() } else null
            val validUser = user != null && user[Users.active] && BCrypt.verifyer().verify(body.password.toCharArray(), user[Users.passwordHash]).verified
            if (!isAdmin && !validUser) {
                call.respond(status = HttpStatusCode.Unauthorized, message = "نام کاربری یا رمز عبور نامعتبر است")
                return@post
            }
            val role = if (isAdmin) "ADMIN" else user!![Users.role]
            if (!isAdmin) transaction { Users.update({ Users.id eq user!![Users.id] }) { it[lastLoginAt] = Instant.now() } }
            val subject = if (isAdmin) "admin" else user!![Users.username]
            val refresh = UUID.randomUUID().toString()
            DevRefreshTokens[refresh] = subject to role
            call.respond(mapOf("token" to JwtAuth.token(subject, role), "role" to role, "refreshToken" to refresh))
        }

        post("/auth/refresh") {
            val body = call.receive<Map<String, String>>()
            val refresh = body["refreshToken"]
            if (refresh == null) {
                call.respond(HttpStatusCode.BadRequest)
                return@post
            }
            val entry = DevRefreshTokens[refresh]
            if (entry == null) {
                call.respond(HttpStatusCode.Unauthorized)
                return@post
            }
            call.respond(Token(JwtAuth.token(entry.first, entry.second), entry.second))
        }

        // Public exam catalog endpoints: regular users must be able to browse exams
        // without an admin JWT. Keep attempts, annotations, and admin operations protected.
        get("/exams") {
            val grade = call.request.queryParameters["grade"]
            val field = call.request.queryParameters["field"]
            val year = call.request.queryParameters["year"]?.toIntOrNull()
            val period = call.request.queryParameters["period"]
            val month = call.request.queryParameters["month"]
            val query = call.request.queryParameters["q"]?.trim()
            val conditions = listOfNotNull(
                grade?.let { Exams.grade eq it }, field?.let { Exams.field eq it },
                year?.let { Exams.year eq it }, period?.let { Exams.period eq it },
                month?.let { Exams.month eq it }, query?.takeIf { it.isNotEmpty() }?.let { Exams.title eq it }
            )
            val rows = transaction {
                if (conditions.isEmpty()) {
                    Exams.selectAll().orderBy(Exams.examDate, SortOrder.DESC).map(::examDto)
                } else {
                    val predicate = conditions.drop(1).fold(conditions.first()) { acc, condition ->
                        Op.build { acc and condition }
                    }
                    Exams.selectAll().where { predicate }.orderBy(Exams.examDate, SortOrder.DESC).map(::examDto)
                }
            }
            call.respond(rows)
        }

        get("/exams/{id}") {
            val id = call.parameters["id"]!!.toLong()
            val row = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull() }
            if (row == null) call.respond(HttpStatusCode.NotFound) else call.respond(examDto(row))
        }

        get("/exams/{id}/archive-metadata") {
            val id = call.parameters["id"]!!.toLong()
            val row = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull() }
            if (row == null) {
                call.respond(HttpStatusCode.NotFound)
            } else {
                call.respond(mapOf(
                    "id" to id, "title" to row[Exams.title], "grade" to row[Exams.grade],
                    "field" to row[Exams.field], "year" to row[Exams.year], "period" to row[Exams.period],
                    "month" to row[Exams.month], "examDate" to row[Exams.examDate].toString(),
                    "description" to row[Exams.description], "hasPdf" to row[Exams.pdfUrl].isNotBlank()
                ))
            }
        }

        get("/exams/{id}/pdf") {
            val id = call.parameters["id"]!!.toLong()
            val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
            if (path == null) { call.respond(HttpStatusCode.NotFound); return@get }
            val root = File(System.getenv("STORAGE_DIR") ?: "./storage").canonicalFile
            // Older records may contain an absolute path from a previous working directory.
            // Prefer the stored path, but safely fall back to the current storage directory.
            val storedFile = File(path)
            val candidates = listOf(
                storedFile,
                if (storedFile.isAbsolute) File(root, storedFile.name) else File(root, path),
                File(root, "exams/$id.pdf")
            ).map { it.canonicalFile }.distinct()
            val file = candidates.firstOrNull { candidate ->
                candidate.toPath().startsWith(root.toPath()) && candidate.isFile
            }
            if (file == null) { call.respond(HttpStatusCode.NotFound); return@get }
            call.respondFile(file)
        }

        authenticate("auth") {
            get("/exams/{id}/annotations") {
                val id = call.parameters["id"]!!.toLong()
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                val rows = transaction { Annotations.selectAll().where { (Annotations.examId eq id) and (Annotations.userId eq uid) }.map(::annotationDto) }
                call.respond(rows)
            }

            post("/exams/{id}/annotations") {
                val id = call.parameters["id"]!!.toLong()
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                val annotation = call.receive<AnnotationDto>()
                val annotationId = UUID.fromString(annotation.id)
                transaction {
                    Annotations.insert {
                        it[Annotations.id] = annotationId; it[userId] = uid; it[examId] = id
                        it[pageNumber] = annotation.page_number; it[type] = annotation.type; it[content] = annotation.content
                        it[position] = annotation.position; it[color] = annotation.color; it[thickness] = annotation.thickness
                        it[createdAt] = Instant.now(); it[updatedAt] = Instant.now()
                    }
                }
                call.respond(status = HttpStatusCode.Created, message = annotation.copy(user_id = uid.toString()))
            }

            put("/annotations/{id}") {
                val annotationId = UUID.fromString(call.parameters["id"]!!)
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                val annotation = call.receive<AnnotationDto>()
                transaction {
                    Annotations.update({ (Annotations.id eq annotationId) and (Annotations.userId eq uid) }) {
                        it[position] = annotation.position; it[color] = annotation.color; it[thickness] = annotation.thickness
                        it[content] = annotation.content; it[updatedAt] = Instant.now()
                    }
                }
                call.respond(annotation)
            }

            delete("/annotations/{id}") {
                val annotationId = UUID.fromString(call.parameters["id"]!!)
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                transaction { Annotations.deleteWhere { (Annotations.id eq annotationId) and (Annotations.userId eq uid) } }
                call.respond(HttpStatusCode.NoContent)
            }

            route("/admin") {
                suspend fun ApplicationCall.requireAdmin(): Boolean {
                    val isAdmin = principal<JWTPrincipal>()?.payload?.getClaim("role")?.asString() == "ADMIN"
                    if (!isAdmin) respond(status = HttpStatusCode.Forbidden, message = "دسترسی مدیر لازم است")
                    return isAdmin
                }

                get("/exams") {
                    if (!call.requireAdmin()) return@get
                    val rows = transaction { Exams.selectAll().orderBy(Exams.examDate, SortOrder.DESC).map(::examDto) }
                    call.respond(rows)
                }
                get("/stats") {
                    if (!call.requireAdmin()) return@get
                    val rows = transaction { Exams.selectAll().toList() }
                    call.respond(mapOf("total" to rows.size, "withPdf" to rows.count { it[Exams.pdfUrl].isNotBlank() }, "withoutPdf" to rows.count { it[Exams.pdfUrl].isBlank() }))
                }
                get("/user-stats") {
                    if (!call.requireAdmin()) return@get
                    val now = Instant.now()
                    val since = now.minusSeconds(30L * 24L * 60L * 60L)
                    val result = transaction {
                        val users = Users.selectAll().toList()
                        val rows = ExamAttempts.selectAll().toList()
                        val active = users.count { it[Users.lastLoginAt]?.isAfter(since) == true }
                        val attemptsByUser = rows.groupingBy { it[ExamAttempts.userKey] }.eachCount()
                        val recent = users.filter { it[Users.role] == "USER" }.sortedByDescending { it[Users.createdAt] }.take(8).map { user ->
                            RecentUserDto(user[Users.username], user[Users.lastLoginAt]?.toString() ?: user[Users.createdAt].toString(), attemptsByUser[user[Users.username]] ?: 0)
                        }
                        val activity = users.filter { it[Users.createdAt].isAfter(since) }
                            .groupingBy { it[Users.createdAt].atZone(java.time.ZoneOffset.UTC).toLocalDate().toString() }.eachCount()
                            .toSortedMap().map { UserActivityPointDto(it.key, it.value) }
                        UserStatsDto(users.count { it[Users.role] == "USER" }, active, rows.size, recent, activity)
                    }
                    call.respond(result)
                }
                post("/exams") {
                    if (!call.requireAdmin()) return@post
                    val exam = call.receive<CreateExamDto>()
                    val newId = transaction {
                        Exams.insert {
                            it[title] = exam.title; it[grade] = exam.grade; it[field] = exam.field; it[examNumber] = exam.examNumber
                            it[examDate] = java.time.LocalDate.parse(exam.examDate); it[year] = exam.year; it[period] = exam.period
                            it[month] = exam.month; it[description] = exam.description; it[pdfUrl] = ""
                            it[durationSeconds] = exam.durationSeconds; it[questionCount] = exam.questionCount.coerceIn(1, 500); it[createdAt] = Instant.now(); it[updatedAt] = Instant.now()
                        } get Exams.id
                    }
                    call.respond(
                        status = HttpStatusCode.Created,
                        message = ExamDto(
                            id = newId,
                            title = exam.title,
                            grade = exam.grade,
                            field = exam.field,
                            examNumber = exam.examNumber,
                            examDate = exam.examDate,
                            year = exam.year,
                            period = exam.period,
                            month = exam.month,
                            description = exam.description,
                            pdfUrl = "",
                            durationSeconds = exam.durationSeconds,
                            questionCount = exam.questionCount.coerceIn(1, 500)
                        )
                    )
                }
                put("/exams/{id}") {
                    if (!call.requireAdmin()) return@put
                    val id = call.parameters["id"]!!.toLong(); val exam = call.receive<ExamDto>()
                    transaction {
                        Exams.update({ Exams.id eq id }) {
                            it[title] = exam.title; it[grade] = exam.grade; it[field] = exam.field; it[examNumber] = exam.examNumber
                            it[examDate] = java.time.LocalDate.parse(exam.examDate); it[year] = exam.year; it[period] = exam.period
                            it[month] = exam.month; it[description] = exam.description; it[durationSeconds] = exam.durationSeconds; it[questionCount] = exam.questionCount.coerceIn(1, 500)
                            it[updatedAt] = Instant.now()
                        }
                    }
                    call.respond(exam)
                }
                delete("/exams/{id}") {
                    if (!call.requireAdmin()) return@delete
                    transaction { Exams.deleteWhere { Exams.id eq call.parameters["id"]!!.toLong() } }
                    call.respond(HttpStatusCode.NoContent)
                }
                get("/exams/{id}/answer-key") {
                    if (!call.requireAdmin()) return@get
                    val id = call.parameters["id"]!!.toLong()
                    val answers = transaction { ExamAnswerKeys.selectAll().where { ExamAnswerKeys.examId eq id }.orderBy(ExamAnswerKeys.questionNumber).map { AnswerKeyItem(it[ExamAnswerKeys.questionNumber], it[ExamAnswerKeys.correctOption]) } }
                    call.respond(AnswerKeyPayload(answers))
                }
                put("/exams/{id}/answer-key") {
                    if (!call.requireAdmin()) return@put
                    val id = call.parameters["id"]!!.toLong()
                    val body = call.receive<AnswerKeyPayload>()
                    val clean = body.answers.filter { it.questionNumber in 1..500 && it.correctOption in 1..4 }.distinctBy { it.questionNumber }
                    transaction {
                        ExamAnswerKeys.deleteWhere { ExamAnswerKeys.examId eq id }
                        clean.forEach { item -> ExamAnswerKeys.insert { it[examId] = id; it[questionNumber] = item.questionNumber; it[correctOption] = item.correctOption } }
                    }
                    call.respond(AnswerKeyPayload(clean))
                }
                get("/home-banners") {
                    if (!call.requireAdmin()) return@get
                    call.respond(transaction { HomeBanners.selectAll().orderBy(HomeBanners.sortOrder, SortOrder.ASC).map(::homeBannerDto) })
                }
                post("/home-banners") {
                    if (!call.requireAdmin()) return@post
                    val body = call.receive<HomeBannerDto>()
                    val id = transaction { HomeBanners.insert {
                        it[kind] = body.kind.takeIf { k -> k == "NOTICE" || k == "EXAM" } ?: "NOTICE"
                        it[title] = body.title.trim(); it[subtitle] = body.subtitle.trim(); it[imageUrl] = body.imageUrl.trim()
                        it[examId] = body.examId; it[active] = body.active; it[sortOrder] = body.sortOrder; it[createdAt] = Instant.now(); it[updatedAt] = Instant.now()
                    } get HomeBanners.id }
                    call.respond(transaction { HomeBanners.selectAll().where { HomeBanners.id eq id }.single().let(::homeBannerDto) })
                }
                put("/home-banners/{id}") {
                    if (!call.requireAdmin()) return@put
                    val id = call.parameters["id"]!!.toLong(); val body = call.receive<HomeBannerDto>()
                    transaction { HomeBanners.update({ HomeBanners.id eq id }) {
                        it[kind] = body.kind.takeIf { k -> k == "NOTICE" || k == "EXAM" } ?: "NOTICE"
                        it[title] = body.title.trim(); it[subtitle] = body.subtitle.trim(); it[imageUrl] = body.imageUrl.trim(); it[examId] = body.examId
                        it[active] = body.active; it[sortOrder] = body.sortOrder; it[updatedAt] = Instant.now()
                    } }
                    call.respond(transaction { HomeBanners.selectAll().where { HomeBanners.id eq id }.single().let(::homeBannerDto) })
                }
                delete("/home-banners/{id}") {
                    if (!call.requireAdmin()) return@delete
                    transaction { HomeBanners.deleteWhere { HomeBanners.id eq call.parameters["id"]!!.toLong() } }
                    call.respond(HttpStatusCode.NoContent)
                }
                post("/exams/{id}/pdf") {
                    if (!call.requireAdmin()) return@post
                    val id = call.parameters["id"]!!.toLong()
                    val receivedType = call.request.contentType()?.toString() ?: "none"
                    val root = File(System.getenv("STORAGE_DIR") ?: "./storage")
                    val target = File(root, "exams/$id.pdf")
                    target.parentFile.mkdirs()
                    withContext(Dispatchers.IO) {
                        call.receiveChannel().toInputStream().use { input ->
                            target.outputStream().use { output -> input.copyTo(output) }
                        }
                    }
                    val size = target.length()
                    val magic = target.inputStream().use { it.readNBytes(5) }
                    if (!magic.contentEquals(byteArrayOf(0x25, 0x50, 0x44, 0x46, 0x2D))) {
                        target.delete()
                        call.respond(HttpStatusCode.BadRequest, "Invalid PDF: size=$size contentType=$receivedType header=${magic.joinToString()}")
                        return@post
                    }
                    withContext(Dispatchers.IO) {
                        transaction {
                            Exams.update({ Exams.id eq id }) {
                                it[pdfUrl] = target.absolutePath
                                it[updatedAt] = Instant.now()
                            }
                        }
                    }
                    call.respond(PdfUploadResponse(ok = true, examId = id))
                }
            }
        }
    }
}
