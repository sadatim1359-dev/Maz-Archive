# Phase 40 — Backend Compatibility Audit

## Purpose
Make the existing backend compatible with the questions/options-only extraction policy.

## Changes applied
- `Questions.correctIndex` is nullable in Exposed (`Int?`).
- `QuestionDto.correctIndex` is nullable and defaults to `null`.
- POST/PUT question validation accepts `null` and still validates a supplied index.
- Admin HTML supports `بدون پاسخ صحیح` and sends `null` when no answer is provided.
- SQL schema permits `correct_index` to be `NULL`.
- Added `MIGRATION_OPTIONS_ONLY.sql` for existing PostgreSQL installations.

## Policy
- Only question text and options are imported.
- No answer key is inferred or processed.
- Internal extraction sentinel `-1` must be converted to database `NULL`; `-1` must not be inserted into the constrained database column.

## Static validation performed
- Extraction export contains 40 questions.
- Question numbers are 1..40.
- Every question has four options.
- Export answer key processing is disabled.
- Backend source has nullable `correctIndex` and null-tolerant POST/PUT validation.

## Remaining work
A dedicated authenticated import endpoint or import service still needs to be implemented and tested against the running Render/PostgreSQL deployment. This package does not claim that a live deployment was changed.
