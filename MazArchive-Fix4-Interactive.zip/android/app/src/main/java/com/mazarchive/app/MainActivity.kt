package com.mazarchive.app

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.serialization.Serializable
import androidx.compose.ui.text.input.PasswordVisualTransformation
import java.net.URLDecoder
import java.net.URLEncoder

@Serializable
data class Exam(
    val id: Long,
    val title: String,
    val grade: String,
    val field: String,
    val examNumber: Int? = null,
    val examDate: String,
    val year: Int,
    val period: String,
    val month: String,
    val pdfUrl: String
)

enum class PenTool { PEN, HIGHLIGHTER, ERASER }

data class Stroke(
    val id: String = java.util.UUID.randomUUID().toString(),
    val page: Int,
    val points: List<androidx.compose.ui.geometry.Offset>,
    val color: Color,
    val width: Float,
    val alpha: Float,
    val tool: PenTool
)

private val Indigo = Color(0xFF7167E8)
private val Bg = Color(0xFF0B0B0F)
private val Card = Color(0xFF15151C)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { MazTheme { App() } }
    }
}

@Composable
fun MazTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Indigo,
            background = Bg,
            surface = Card
        ),
        content = content
    )
}

@Composable
fun App() {
    val nav = rememberNavController()
    val context = LocalContext.current
    val authStore = remember { com.mazarchive.app.data.AuthStore(context) }
    var showSplash by rememberSaveable { mutableStateOf(true) }
    var loggedIn by rememberSaveable { mutableStateOf(authStore.isLoggedIn()) }
    var registered by rememberSaveable { mutableStateOf(authStore.isRegistered()) }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(2600)
        showSplash = false
    }

    if (showSplash) {
        SplashScreen()
        return
    }

    if (!registered) {
        RegisterScreen { username, password ->
            authStore.registerLocal(username, password)
            registered = true
            loggedIn = true
        }
        return
    }

    if (!loggedIn) {
        LoginScreen { username, password ->
            if (authStore.checkLocalCredentials(username, password)) {
                authStore.save("local-session", "USER")
                loggedIn = true
            }
        }
        return
    }

    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            AppScaffold(nav, "home") {
                Home { grade -> nav.navigate("fields/${URLEncoder.encode(grade, "UTF-8")}") }
            }
        }
        composable("fields/{g}") { entry ->
            val grade = URLDecoder.decode(entry.arguments?.getString("g")!!, "UTF-8")
            AppScaffold(nav, "archive") {
                Fields(grade) { field ->
                    nav.navigate("archive/${URLEncoder.encode(grade, "UTF-8")}/${URLEncoder.encode(field, "UTF-8")}")
                }
            }
        }
        composable("archive/{g}/{f}") { entry ->
            val grade = URLDecoder.decode(entry.arguments?.getString("g")!!, "UTF-8")
            val field = URLDecoder.decode(entry.arguments?.getString("f")!!, "UTF-8")
            AppScaffold(nav, "archive") {
                Archive(grade, field) { id -> nav.navigate("exam/$id") }
            }
        }
        composable("exam/{id}") { entry ->
            ExamDetail(entry.arguments?.getString("id")!!.toLong()) { id ->
                nav.navigate("interactive/$id")
            }
        }
        composable("interactive/{id}") { entry ->
            InteractiveExam(entry.arguments?.getString("id")!!.toLong()) { nav.popBackStack("home", false) }
        }
        composable("search") {
            AppScaffold(nav, "search") { SearchScreen { grade, field ->
                nav.navigate("archive/${URLEncoder.encode(grade, "UTF-8")}/${URLEncoder.encode(field, "UTF-8")}")
            } }
        }
        composable("profile") { AppScaffold(nav, "profile") { ProfileScreen() } }
        composable("pdf/{url}") { entry ->
            PdfScreen(URLDecoder.decode(entry.arguments?.getString("url")!!, "UTF-8")) { nav.popBackStack() }
        }
    }
}

@Composable
fun AppScaffold(nav: androidx.navigation.NavHostController, selected: String, content: @Composable () -> Unit) {
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0D0F18), tonalElevation = 0.dp) {
                NavItem("⌂", "خانه", selected == "home") { nav.navigate("home") { launchSingleTop = true; popUpTo("home") { saveState = true } } }
                NavItem("▣", "آرشیو", selected == "archive") { nav.navigate("home") { launchSingleTop = true; popUpTo("home") { saveState = true } } }
                NavItem("⌕", "جستجو", selected == "search") { nav.navigate("search") { launchSingleTop = true } }
                NavItem("♙", "پروفایل", selected == "profile") { nav.navigate("profile") { launchSingleTop = true } }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) { content() }
    }
}

@Composable
fun RowScope.NavItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { Text(icon, style = MaterialTheme.typography.titleLarge) },
        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = Color.White,
            selectedTextColor = Color.White,
            indicatorColor = Indigo.copy(alpha = 0.28f),
            unselectedIconColor = Color(0xFF8E91A3),
            unselectedTextColor = Color(0xFF8E91A3)
        )
    )
}

@Composable
fun SplashScreen() {
    Box(
        Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.mipmap.ic_launcher),
            contentDescription = "Maz-Archive",
            modifier = Modifier
                .size(150.dp)
                .clip(RoundedCornerShape(38.dp))
        )
    }
}

@Composable
fun RegisterScreen(onRegister: (String, String) -> Unit) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(
            Modifier.fillMaxWidth().align(Alignment.Center).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(id = R.mipmap.ic_launcher),
                contentDescription = "Maz-Archive",
                modifier = Modifier.size(104.dp).clip(RoundedCornerShape(28.dp))
            )
            Text("Maz-Archive", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Indigo)
            Text("ثبت‌نام در آرشیو", style = MaterialTheme.typography.titleLarge)
            Text("برای اولین ورود، حساب خودت را بساز", color = Color(0xFFAAAEC0))

            OutlinedTextField(
                value = user,
                onValueChange = { user = it; error = "" },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("نام کاربری") },
                singleLine = true,
                shape = RoundedCornerShape(18.dp)
            )
            OutlinedTextField(
                value = pass,
                onValueChange = { pass = it; error = "" },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("رمز عبور") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(18.dp)
            )
            OutlinedTextField(
                value = confirm,
                onValueChange = { confirm = it; error = "" },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("تکرار رمز عبور") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(18.dp)
            )
            if (error.isNotBlank()) Text(error, color = Color(0xFFFF6B6B))
            Button(
                onClick = {
                    when {
                        user.trim().length < 3 -> error = "نام کاربری حداقل ۳ حرف باشد"
                        pass.length < 4 -> error = "رمز عبور حداقل ۴ کاراکتر باشد"
                        pass != confirm -> error = "رمزهای عبور یکسان نیستند"
                        else -> onRegister(user.trim(), pass)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = user.isNotBlank() && pass.isNotBlank() && confirm.isNotBlank(),
                shape = RoundedCornerShape(16.dp)
            ) { Text("ساخت حساب و ورود") }
        }
    }
}

@Composable
fun LoginScreen(onLogin: (String, String) -> Unit) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(
            Modifier.fillMaxWidth().align(Alignment.Center).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(id = R.mipmap.ic_launcher),
                contentDescription = "Maz-Archive",
                modifier = Modifier
                    .size(104.dp)
                    .clip(RoundedCornerShape(28.dp))
            )
            Text(
                "Maz-Archive",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = Indigo
            )
            Text("آرشیو آزمون‌ها و منابع آموزشی", color = Color(0xFFAAAEC0))
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = user,
                onValueChange = { user = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("نام کاربری") },
                shape = RoundedCornerShape(18.dp)
            )
            OutlinedTextField(
                value = pass,
                onValueChange = { pass = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("رمز عبور") },
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(18.dp)
            )
            Button(
                onClick = {
                    val u = user.trim()
                    if (u.isNotBlank() && pass.isNotBlank()) {
                        error = false
                        onLogin(u, pass)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = user.isNotBlank() && pass.isNotBlank(),
                shape = RoundedCornerShape(16.dp)
            ) { Text("ورود به آرشیو") }
            if (error) Text("نام کاربری یا رمز عبور نادرست است", color = Color(0xFFFF6B6B))
        }
    }
}

@Composable
fun Home(onGrade: (String) -> Unit) {
    val grades = listOf(
        Triple("دهم", "۲۴ آزمون", Color(0xFF10C99A)),
        Triple("یازدهم", "۱۸ آزمون", Color(0xFF2686FF)),
        Triple("دوازدهم", "۳۲ آزمون", Color(0xFF8247FF))
    )
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(id = R.mipmap.ic_launcher), "Maz-Archive", Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)))
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("Maz-Archive", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("آرشیو هوشمند آزمون‌ها", color = Color(0xFF9EA2B4), style = MaterialTheme.typography.bodySmall)
            }
            Surface(shape = CircleShape, color = Color(0xFF171C31)) { Text("M", Modifier.padding(horizontal = 13.dp, vertical = 9.dp), color = Color(0xFFBDAFFF), fontWeight = FontWeight.Bold) }
        }

        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("سلام، کاربر عزیز 👋", color = Color(0xFFB5B8C8))
            Text("آماده‌ای برای آزمون بعدی؟", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF171B3A)), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(Modifier.size(52.dp), RoundedCornerShape(16.dp), color = Indigo.copy(alpha = .22f)) { Box(contentAlignment = Alignment.Center) { Text("✦", color = Color(0xFFB8AEFF), style = MaterialTheme.typography.headlineSmall) } }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("جدیدترین آزمون", color = Color(0xFFC3BEFF), style = MaterialTheme.typography.labelLarge)
                        Text("آزمون مرحله دوم", fontWeight = FontWeight.Bold)
                        Text("یازدهم • ریاضی • شیمی", color = Color(0xFFAEB2C5), style = MaterialTheme.typography.bodySmall)
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("۳۰ سوال", color = Color(0xFFAEB2C5), style = MaterialTheme.typography.labelSmall)
                    Text("۱۵ آبان ۱۴۰۴", color = Color(0xFFBDAFFF), style = MaterialTheme.typography.labelSmall)
                }
                Button(onClick = { onGrade("یازدهم") }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("مشاهده آزمون  →") }
            }
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text("پایه‌های تحصیلی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("پایه موردنظر را انتخاب کن", color = Color(0xFF8E92A4), style = MaterialTheme.typography.bodySmall)
            }
            Text("۳ پایه", color = Color(0xFF777C90), style = MaterialTheme.typography.labelSmall)
        }

        grades.forEach { (grade, count, accent) ->
            Card(Modifier.fillMaxWidth().clickable { onGrade(grade) }, RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF131827))) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(Modifier.size(58.dp), RoundedCornerShape(18.dp), color = accent.copy(alpha = .15f)) { Box(contentAlignment = Alignment.Center) { Text("🎓", style = MaterialTheme.typography.titleLarge) } }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("پایه $grade", fontWeight = FontWeight.Bold)
                        Text(count, color = accent, style = MaterialTheme.typography.labelLarge)
                        Text("آزمون‌های این پایه", color = Color(0xFF8E92A4), style = MaterialTheme.typography.bodySmall)
                    }
                    Text("›", color = accent, style = MaterialTheme.typography.headlineMedium)
                }
            }
        }
        Text("Maz-Archive  •  نسخه 1.0.0", Modifier.fillMaxWidth(), color = Color(0xFF555A6C), textAlign = androidx.compose.ui.text.style.TextAlign.Center, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun Fields(grade: String, onField: (String) -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("انتخاب رشته", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("پایه $grade", color = Color(0xFF9EA2B4))
        Spacer(Modifier.height(4.dp))
        listOf("ریاضی" to Color(0xFF2686FF), "تجربی" to Color(0xFF10C99A), "انسانی" to Color(0xFF8247FF)).forEach { (field, accent) ->
            Card(Modifier.fillMaxWidth().clickable { onField(field) }, RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A))) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(Modifier.size(52.dp), RoundedCornerShape(16.dp), color = accent.copy(alpha = .16f)) { Box(contentAlignment = Alignment.Center) { Text("◆", color = accent) } }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) { Text("رشته $field", fontWeight = FontWeight.Bold); Text("مشاهده آزمون‌های $grade", color = Color(0xFF8F94A8), style = MaterialTheme.typography.bodySmall) }
                    Text("›", color = accent, style = MaterialTheme.typography.headlineMedium)
                }
            }
        }
    }
}

@Composable
fun Archive(grade: String, field: String, open: (Long) -> Unit) {
    var q by remember { mutableStateOf("") }
    var year by remember { mutableStateOf<Int?>(null) }
    var period by remember { mutableStateOf<String?>(null) }
    var month by remember { mutableStateOf<String?>(null) }
    var showFilter by remember { mutableStateOf(false) }
    val data = remember(grade, field, q, year, period, month) {
        (1..18).map { n -> Exam(n.toLong(), "آزمون $n", grade, field, n, "۱۴۰۴/۰۸/${(25 - n).coerceAtLeast(1)}", 1404, "شروع از مهر", "آبان", "") }
            .filter { q.isBlank() || it.title.contains(q) || it.examDate.contains(q) }
            .filter { year == null || it.year == year }
    }
    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("آزمون‌های $grade", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("$field", color = Indigo) }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("نام آزمون، درس یا تاریخ...") }, leadingIcon = { Text("⌕") }, shape = RoundedCornerShape(16.dp))
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("همه", "تخصصی", "عمومی").forEachIndexed { i, label -> FilterChip(selected = (i == 0 && !showFilter) || (i == 1 && showFilter), onClick = { showFilter = i == 1 }, label = { Text(label) }) }
            Spacer(Modifier.weight(1f)); TextButton(onClick = { showFilter = !showFilter }) { Text("فیلتر ☷") }
        }
        if (showFilter) FilterPanel(year, { year = it }, period, { period = it }, month, { month = it })
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(data) { exam ->
                Card(Modifier.fillMaxWidth().clickable { open(exam.id) }, RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A))) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(Modifier.size(48.dp), RoundedCornerShape(14.dp), color = Indigo.copy(alpha = .15f)) { Box(contentAlignment = Alignment.Center) { Text("▤", color = Indigo) } }
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) { Text("${exam.title} • $field", fontWeight = FontWeight.SemiBold); Text("${exam.examDate}  •  ۳۰ سوال", color = Color(0xFF858B9F), style = MaterialTheme.typography.bodySmall) }
                        Text("›", color = Indigo, style = MaterialTheme.typography.headlineSmall)
                    }
                }
            }
        }
    }
}

@Composable
fun SearchScreen(open: (String, String) -> Unit) {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("جستجو", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("آزمون موردنظرت را سریع پیدا کن", color = Color(0xFF969BAD))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("نام آزمون، درس یا پایه...") }, leadingIcon = { Text("⌕") }, shape = RoundedCornerShape(17.dp))
        Text("فیلترهای سریع", fontWeight = FontWeight.Bold)
        listOf("دهم • ریاضی", "یازدهم • فیزیک", "دوازدهم • شیمی").forEach { label ->
            val parts = label.split(" • ")
            Card(Modifier.fillMaxWidth().clickable { open(parts[0], parts[1]) }, RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A))) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text("⌕", color = Indigo); Spacer(Modifier.width(12.dp)); Text(label, Modifier.weight(1f)); Text("›", color = Indigo) }
            }
        }
    }
}

@Composable
fun ProfileScreen() {
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("پروفایل", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("⚙", color = Color(0xFFB4B8CA), style = MaterialTheme.typography.titleLarge) }
        Card(Modifier.fillMaxWidth(), RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A))) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(Modifier.size(64.dp), CircleShape, color = Color(0xFF1D5FEA)) { Box(contentAlignment = Alignment.Center) { Text("م", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }
                Spacer(Modifier.width(14.dp)); Column { Text("کاربر Maz-Archive", fontWeight = FontWeight.Bold); Text("حساب کاربری", color = Color(0xFF8E94A8), style = MaterialTheme.typography.bodySmall) }
            }
        }
        listOf("حالت نمایش  ◐", "اطلاعات برنامه  ⓘ", "درباره ما  i", "تماس با ما  ◌").forEach { item ->
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111622))) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(item, Modifier.weight(1f)); Text("‹", color = Color(0xFF7D8398)) } }
        }
        OutlinedButton(onClick = {}, Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) { Text("خروج از حساب", color = Color(0xFFFF6B7A)) }
    }
}

@Composable
fun FilterPanel(
    year: Int?, setYear: (Int?) -> Unit,
    period: String?, setPeriod: (String?) -> Unit,
    month: String?, setMonth: (String?) -> Unit
) {
    Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), color = Color(0xFF111522)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("فیلتر آزمون‌ها", fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(1404, 1403, 1402).forEach { value -> FilterChip(year == value, { setYear(if (year == value) null else value) }, label = { Text(value.toString()) }) } }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("تابستانه", "شروع از مهر").forEach { value -> FilterChip(period == value, { setPeriod(if (period == value) null else value) }, label = { Text(value) }) } }
            val months = if (period == "تابستانه") listOf("تیر", "مرداد", "شهریور") else listOf("مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) { months.forEach { value -> FilterChip(month == value, { setMonth(if (month == value) null else value) }, label = { Text(value) }) } }
        }
    }
}

@Composable
fun ExamDetail(id: Long, start: (Long) -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("آماده‌ای؟", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth(), RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF151A35))) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("آزمون شماره $id", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("ریاضی دهم", color = Indigo, style = MaterialTheme.typography.titleMedium)
                Text("آزمون تعاملی • ۲۰ سؤال • ۳۰ دقیقه", color = Color(0xFFA8AEC2))
                LinearProgressIndicator(progress = { 0f }, Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(8.dp)), color = Indigo, trackColor = Color(0xFF30334A))
            }
        }
        Card(Modifier.fillMaxWidth(), RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111622))) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("قوانین آزمون", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("• زمان آزمون واقعی است و با پایان زمان، آزمون خودکار ثبت می‌شود.\n• می‌توانی سؤال‌ها را علامت‌گذاری کنی و بین آن‌ها جابه‌جا شوی.\n• پاسخ‌های ثبت‌نشده به‌عنوان بی‌پاسخ محاسبه می‌شوند.", color = Color(0xFF9DA3B6))
            }
        }
        Button(onClick = { start(id) }, Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp)) { Text("شروع آزمون  ▶", style = MaterialTheme.typography.titleMedium) }
    }
}

data class InteractiveQuestion(val text: String, val options: List<String>, val correct: Int)

data class ExamResult(val correct: Int, val wrong: Int, val unanswered: Int, val usedSeconds: Int, val total: Int)

private fun demoQuestions(): List<InteractiveQuestion> = listOf(
    InteractiveQuestion("اگر f(x)=2x+3 باشد، مقدار f(4) کدام است؟", listOf("۷", "۱۱", "۱۲", "۱۴"), 1),
    InteractiveQuestion("حاصل ۳² + ۴² کدام است؟", listOf("۱۲", "۲۵", "۲۷", "۳۲"), 1),
    InteractiveQuestion("کدام گزینه یک عدد اول است؟", listOf("۲۱", "۲۷", "۲۹", "۳۹"), 2),
    InteractiveQuestion("شیب خط y=3x-2 برابر است با؟", listOf("-۲", "۲", "۳", "۵"), 2),
    InteractiveQuestion("حاصل √۴۹ کدام است؟", listOf("۵", "۶", "۷", "۸"), 2),
    InteractiveQuestion("اگر x+5=12 باشد، x چند است؟", listOf("۵", "۶", "۷", "۸"), 2),
    InteractiveQuestion("کدام عبارت با 2(a+b) برابر است؟", listOf("2a+b", "a+2b", "2a+2b", "a+b+2"), 2),
    InteractiveQuestion("میانگین ۴، ۶ و ۸ چند است؟", listOf("۵", "۶", "۷", "۸"), 1),
    InteractiveQuestion("مساحت مربع با ضلع ۵ چند است؟", listOf("۱۰", "۲۰", "۲۵", "۳۰"), 2),
    InteractiveQuestion("حاصل ۱۵÷۳ کدام است؟", listOf("۳", "۵", "۶", "۸"), 1),
    InteractiveQuestion("کدام عدد بر ۳ بخش‌پذیر است؟", listOf("۱۴", "۱۶", "۱۸", "۲۰"), 2),
    InteractiveQuestion("اگر 2x=18 باشد، x چند است؟", listOf("۷", "۸", "۹", "۱۰"), 2),
    InteractiveQuestion("محیط مستطیل با طول ۶ و عرض ۳؟", listOf("۹", "۱۲", "۱۸", "۲۴"), 3),
    InteractiveQuestion("حاصل ۱۰−۳×۲ کدام است؟", listOf("۴", "۸", "۱۴", "۱۶"), 0),
    InteractiveQuestion("کدام گزینه کسری بزرگ‌تر از ۱ است؟", listOf("۱/۲", "۲/۳", "۵/۴", "۳/۴"), 2),
    InteractiveQuestion("اگر a=3 باشد، a²+1 چند است؟", listOf("۷", "۹", "۱۰", "۱۲"), 2),
    InteractiveQuestion("مجموع زوایای مثلث چند درجه است؟", listOf("۹۰", "۱۸۰", "۲۷۰", "۳۶۰"), 1),
    InteractiveQuestion("حاصل 2³ کدام است؟", listOf("۶", "۸", "۹", "۱۲"), 1),
    InteractiveQuestion("ریشه دوم ۱۰۰ کدام است؟", listOf("۸", "۹", "۱۰", "۱۲"), 2),
    InteractiveQuestion("اگر x²=16 و x مثبت باشد، x چند است؟", listOf("۲", "۳", "۴", "۸"), 2)
)

@Composable
fun InteractiveExam(id: Long, finish: () -> Unit) {
    val questions = remember { demoQuestions() }
    var current by rememberSaveable { mutableIntStateOf(0) }
    var answers by rememberSaveable { mutableStateOf(List(questions.size) { -1 }) }
    var flagged by rememberSaveable { mutableStateOf(emptySet<Int>()) }
    var secondsLeft by rememberSaveable { mutableIntStateOf(30 * 60) }
    var startedAt by rememberSaveable { mutableLongStateOf(System.currentTimeMillis()) }
    var showGrid by remember { mutableStateOf(false) }
    var showLowTime by remember { mutableStateOf(false) }
    var showEnd by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ExamResult?>(null) }

    fun submit() {
        val correct = answers.indices.count { answers[it] == questions[it].correct }
        val answered = answers.count { it >= 0 }
        result = ExamResult(correct, answered - correct, questions.size - answered, (30 * 60 - secondsLeft).coerceAtLeast(0), questions.size)
    }

    LaunchedEffect(Unit) {
        while (secondsLeft > 0 && result == null) {
            delay(1000)
            secondsLeft--
            if (secondsLeft == 300) showLowTime = true
        }
        if (secondsLeft == 0 && result == null) submit()
    }

    result?.let { r ->
        ExamResultScreen(r, finish)
        return
    }

    val q = questions[current]
    val percent = (current + 1).toFloat() / questions.size
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("آزمون ریاضی دهم", Modifier.weight(1f), fontWeight = FontWeight.Bold)
            Surface(shape = RoundedCornerShape(14.dp), color = if (secondsLeft <= 300) Color(0xFF6B2430) else Color(0xFF1A1D38)) {
                Text("${secondsLeft / 60}:${(secondsLeft % 60).toString().padStart(2, '0')}", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        LinearProgressIndicator(progress = { percent }, Modifier.fillMaxWidth().height(6.dp), color = Indigo, trackColor = Color(0xFF292C3A))
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("سؤال ${current + 1} از ${questions.size}", color = Color(0xFFBDB4FF), fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { showGrid = true }) { Text("شماره سؤال‌ها ▦") }
            }
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF151A35))) {
                Text(q.text, Modifier.padding(20.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            q.options.forEachIndexed { i, option ->
                val selected = answers[current] == i
                Card(Modifier.fillMaxWidth().clickable { answers = answers.toMutableList().also { it[current] = i } }, RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = if (selected) Indigo.copy(alpha = .28f) else Color(0xFF111622))) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(Modifier.size(34.dp), CircleShape, color = if (selected) Indigo else Color(0xFF24283A)) { Box(contentAlignment = Alignment.Center) { Text("${i + 1}", color = Color.White) } }
                        Spacer(Modifier.width(12.dp)); Text(option, Modifier.weight(1f)); if (selected) Text("✓", color = Indigo, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { flagged = if (current in flagged) flagged - current else flagged + current }, shape = RoundedCornerShape(15.dp)) { Text(if (current in flagged) "⚑ علامت‌گذاری شد" else "⚐ علامت‌گذاری") }
                Spacer(Modifier.weight(1f))
                Text("${(percent * 100).toInt()}٪", color = Color(0xFF8F95AA))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { if (current > 0) current-- }, enabled = current > 0, Modifier.weight(1f), shape = RoundedCornerShape(15.dp)) { Text("قبلی") }
                Button(onClick = { if (current < questions.lastIndex) current++ else showEnd = true }, Modifier.weight(1f), shape = RoundedCornerShape(15.dp)) { Text(if (current == questions.lastIndex) "پایان آزمون" else "بعدی") }
            }
            OutlinedButton(onClick = { showEnd = true }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) { Text("پایان و ثبت آزمون") }
        }
    }

    if (showGrid) AlertDialog(onDismissRequest = { showGrid = false }, title = { Text("ناوبری سؤال‌ها") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { Text("پاسخ‌داده: ${answers.count { it >= 0 }}"); Text("بی‌پاسخ: ${answers.count { it < 0 }}") }
            Column(Modifier.verticalScroll(rememberScrollState())) {
                (0 until questions.size step 5).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { (row until minOf(row + 5, questions.size)).forEach { i -> Button(onClick = { current = i; showGrid = false }, modifier = Modifier.size(48.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = if (answers[i] >= 0) Indigo else Color(0xFF292C3A))) { Text("${i + 1}") } } } }
            }
        }
    }, confirmButton = { TextButton(onClick = { showGrid = false }) { Text("بستن") } })
    if (showLowTime) AlertDialog(onDismissRequest = { showLowTime = false }, title = { Text("⏱ زمان رو به پایان است") }, text = { Text("فقط ۵ دقیقه از زمان آزمون باقی مانده است.") }, confirmButton = { Button(onClick = { showLowTime = false }) { Text("متوجه شدم") } })
    if (showEnd) AlertDialog(onDismissRequest = { showEnd = false }, title = { Text("پایان آزمون") }, text = { Text("${answers.count { it < 0 }} سؤال هنوز بی‌پاسخ است. آزمون ثبت شود؟") }, confirmButton = { Button(onClick = { showEnd = false; submit() }) { Text("ثبت آزمون") } }, dismissButton = { TextButton(onClick = { showEnd = false }) { Text("ادامه") } })
}

@Composable
fun ExamResultScreen(r: ExamResult, finish: () -> Unit) {
    val percent = r.correct * 100 / r.total
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(18.dp))
        Text("آزمون به پایان رسید", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("نتیجه آزمون شما", color = Color(0xFF9298AA))
        Card(Modifier.fillMaxWidth(), RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF171B3A))) {
            Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("$percent٪", style = MaterialTheme.typography.displaySmall, color = Indigo, fontWeight = FontWeight.Bold)
                Text("درصد کسب‌شده")
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            ResultBox("صحیح", r.correct.toString(), Modifier.weight(1f)); ResultBox("غلط", r.wrong.toString(), Modifier.weight(1f)); ResultBox("بی‌پاسخ", r.unanswered.toString(), Modifier.weight(1f))
        }
        ResultBox("زمان استفاده‌شده", "${r.usedSeconds / 60}:${(r.usedSeconds % 60).toString().padStart(2, '0')}", Modifier.fillMaxWidth())
        Button(onClick = finish, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("بازگشت به خانه") }
    }
}

@Composable
fun ResultBox(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111622))) { Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge); Text(title, color = Color(0xFF858B9F), style = MaterialTheme.typography.bodySmall) } }
}

@Composable
fun PdfScreen(url: String, onBack: () -> Unit) {
    var file by remember { mutableStateOf<java.io.File?>(null) }
    var tool by remember { mutableStateOf(PenTool.PEN) }
    var width by remember { mutableFloatStateOf(5f) }
    var color by remember { mutableStateOf(Color.Red) }
    var tools by remember { mutableStateOf(false) }
    var strokes by remember { mutableStateOf(listOf<Stroke>()) }
    var redo by remember { mutableStateOf(listOf<Stroke>()) }

    LaunchedEffect(url) {
        file = runCatching {
            val f = java.io.File.createTempFile("maz-", ".pdf")
            java.net.URL(url).openStream().use { input ->
                f.outputStream().use { output -> input.copyTo(output) }
            }
            f
        }.getOrNull()
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(
            Modifier.fillMaxWidth().height(48.dp).background(Color(0xFF101014)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("←") }
            TextButton(onClick = { tools = !tools }) { Text("✏️") }
            TextButton(
                onClick = {
                    val last = strokes.last()
                    strokes = strokes.dropLast(1)
                    redo = redo + last
                },
                enabled = strokes.isNotEmpty()
            ) { Text("↶") }
            TextButton(
                onClick = {
                    val last = redo.last()
                    redo = redo.dropLast(1)
                    strokes = strokes + last
                },
                enabled = redo.isNotEmpty()
            ) { Text("↷") }
        }
        if (tools) {
            Surface(color = Color(0xFF17171D)) {
                Column(Modifier.padding(10.dp)) {
                    Row {
                        listOf(
                            PenTool.PEN to "قلم",
                            PenTool.HIGHLIGHTER to "هایلایتر",
                            PenTool.ERASER to "پاک‌کن"
                        ).forEach { (t, label) ->
                            FilterChip(
                                selected = tool == t,
                                onClick = { tool = t; tools = false },
                                label = { Text(label) }
                            )
                        }
                    }
                    Row {
                        listOf(3f to "نازک", 6f to "متوسط", 12f to "ضخیم").forEach { (w, label) ->
                            FilterChip(
                                selected = width == w,
                                onClick = { width = w },
                                label = { Text(label) }
                            )
                        }
                    }
                    Row {
                        listOf(
                            Color.Black to "مشکی",
                            Color.Red to "قرمز",
                            Color.Blue to "آبی",
                            Color.Green to "سبز"
                        ).forEach { (c, label) ->
                            FilterChip(
                                selected = color == c,
                                onClick = { color = c },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }
        }
        file?.let { pdfFile ->
            PdfCanvas(pdfFile, strokes, { stroke ->
                strokes = strokes + stroke
                redo = emptyList()
            }, tool, width, color)
        } ?: Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) { CircularProgressIndicator() }
    }
}

@Composable
fun PdfCanvas(
    file: java.io.File,
    strokes: List<Stroke>,
    add: (Stroke) -> Unit,
    tool: PenTool,
    width: Float,
    color: Color
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    val renderer = remember(file) {
        PdfRenderer(ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY))
    }
    DisposableEffect(renderer) {
        onDispose { renderer.close() }
    }
    val pages = renderer.pageCount
    val bitmaps = remember(file) {
        (0 until pages).map { pageIndex ->
            renderer.openPage(pageIndex).let { page ->
                Bitmap.createBitmap(page.width, page.height, Bitmap.Config.ARGB_8888).also { bitmap ->
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()
                }
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 4f)
                    offset += pan
                }
            }
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
        ) {
            bitmaps.forEachIndexed { pageIndex, bitmap ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Canvas(
                        Modifier
                            .matchParentSize()
                            .pointerInput(tool, width, color, pageIndex) {
                                val points = mutableListOf<androidx.compose.ui.geometry.Offset>()
                                awaitPointerEventScope {
                                    while (true) {
                                        val event = awaitPointerEvent()
                                        if (event.changes.size == 1 && event.changes[0].pressed) {
                                            val change = event.changes[0]
                                            points += androidx.compose.ui.geometry.Offset(
                                                (change.position.x / size.width).coerceIn(0f, 1f),
                                                (change.position.y / size.height).coerceIn(0f, 1f)
                                            )
                                        } else if (points.isNotEmpty()) {
                                            add(
                                                Stroke(
                                                    page = pageIndex,
                                                    points = points.toList(),
                                                    color = if (tool == PenTool.ERASER) Color.Transparent else color,
                                                    width = width,
                                                    alpha = if (tool == PenTool.HIGHLIGHTER) 0.35f else 1f,
                                                    tool = tool
                                                )
                                            )
                                            points.clear()
                                        }
                                    }
                                }
                            }
                    ) {
                        strokes
                            .filter { it.page == pageIndex && it.points.size > 1 }
                            .forEach { stroke ->
                                val path = Path()
                                path.moveTo(
                                    stroke.points[0].x * size.width,
                                    stroke.points[0].y * size.height
                                )
                                stroke.points.drop(1).forEach { point ->
                                    path.lineTo(point.x * size.width, point.y * size.height)
                                }
                                drawPath(
                                    path = path,
                                    color = stroke.color.copy(alpha = stroke.alpha),
                                    style = DrawStroke(width = stroke.width)
                                )
                            }
                    }
                }
            }
        }
        Text(
            "1 / $pages",
            Modifier.align(Alignment.CenterEnd).padding(6.dp),
            color = Color.White
        )
    }
}
