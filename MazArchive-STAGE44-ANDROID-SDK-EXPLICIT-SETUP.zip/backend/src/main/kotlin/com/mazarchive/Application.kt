package com.mazarchive

import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.*
import io.ktor.server.auth.*
import io.ktor.server.auth.jwt.*
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.http.content.staticResources
import io.ktor.serialization.kotlinx.json.json
import io.ktor.utils.io.jvm.javaio.toInputStream
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.javatime.*
import java.io.File
import org.apache.pdfbox.Loader
import org.apache.pdfbox.text.PDFTextStripper
import org.apache.pdfbox.text.TextPosition
import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.util.Base64
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object Exams : Table("exams") {
    val id = long("id").autoIncrement()
    val title = text("title")
    val grade = text("grade")
    val field = text("field")
    val examNumber = integer("exam_number").nullable()
    val examDate = date("exam_date")
    val year = integer("year")
    val period = text("period")
    val month = text("month")
    val description = text("description").default("")
    val pdfUrl = text("pdf_url")
    val durationSeconds = integer("duration_seconds").default(1800)
    val createdAt = timestamp("created_at")
    val updatedAt = timestamp("updated_at")
    override val primaryKey = PrimaryKey(id)
}

object Questions : Table("questions") {
    val id = long("id").autoIncrement()
    val examId = long("exam_id").references(Exams.id, onDelete = ReferenceOption.CASCADE)
    val number = integer("number")
    val text = text("question_text")
    val options = text("options_json")
    val correctIndex = integer("correct_index").nullable()
    val createdAt = timestamp("created_at")
    val updatedAt = timestamp("updated_at")
    override val primaryKey = PrimaryKey(id)
}


object ExamAttempts : Table("exam_attempts") {
    val id = long("id").autoIncrement()
    val userKey = text("user_key")
    val examId = long("exam_id").references(Exams.id, onDelete = ReferenceOption.CASCADE)
    val correct = integer("correct")
    val wrong = integer("wrong")
    val unanswered = integer("unanswered")
    val total = integer("total")
    val percent = float("percent")
    val usedSeconds = integer("used_seconds")
    val submittedByTime = bool("submitted_by_time")
    val createdAt = timestamp("created_at")
    override val primaryKey = PrimaryKey(id)
}

object Annotations : Table("annotations") {
    val id = uuid("id")
    val userId = uuid("user_id")
    val examId = long("exam_id")
    val pageNumber = integer("page_number")
    val type = text("type")
    val content = text("content").nullable()
    val position = text("position")
    val color = text("color")
    val thickness = float("thickness")
    val createdAt = timestamp("created_at")
    val updatedAt = timestamp("updated_at")
    override val primaryKey = PrimaryKey(id)
}

@Serializable data class CreateExamDto(
    val title: String,
    val grade: String,
    val field: String,
    val examNumber: Int? = null,
    val examDate: String,
    val year: Int,
    val period: String,
    val month: String,
    val description: String = "",
    val durationSeconds: Int = 1800
)

@Serializable data class ExamDto(
    val id: Long = 0,
    val title: String,
    val grade: String,
    val field: String,
    val examNumber: Int? = null,
    val examDate: String,
    val year: Int,
    val period: String,
    val month: String,
    val description: String = "",
    val pdfUrl: String = "",
    val durationSeconds: Int = 1800
)

@Serializable data class QuestionDto(
    val id: Long = 0, val examId: Long, val number: Int, val text: String,
    val options: List<String>, val correctIndex: Int? = null, val imageUrl: String? = null,
    val createdAt: String = "", val updatedAt: String = ""
)

@Serializable data class AnnotationDto(
    val id: String, val user_id: String, val exam_id: Long, val page_number: Int,
    val type: String, val content: String? = null, val position: String,
    val color: String, val thickness: Float, val created_at: String = "",
    val updated_at: String = ""
)

@Serializable data class Login(val username: String, val password: String)

@Serializable
data class ApiErrorDto(
    val ok: Boolean = false,
    val code: String,
    val stage: String,
    val message: String,
    val details: String = "",
    val examId: Long? = null
)

private suspend fun ApplicationCall.respondApiError(
    status: HttpStatusCode,
    code: String,
    stage: String,
    message: String,
    details: String = "",
    examId: Long? = null
) {
    respond(status, ApiErrorDto(false, code, stage, message, details, examId))
}
@Serializable data class AttemptRequest(val examId: Long, val correct: Int, val wrong: Int, val unanswered: Int, val total: Int, val percent: Float, val usedSeconds: Int, val submittedByTime: Boolean = false)
@Serializable data class AttemptDto(val id: Long, val examId: Long, val correct: Int, val wrong: Int, val unanswered: Int, val total: Int, val percent: Float, val usedSeconds: Int, val submittedByTime: Boolean, val createdAt: String)

@Serializable
data class PdfExtractionSummary(
    val pages: Int,
    val extractedCharacters: Int,
    val detectedQuestionNumbers: List<Int>,
    val needsReview: Boolean = true,
    val message: String = "استخراج اولیه انجام شد؛ بررسی مدیر لازم است."
)

/** Stable API contract returned after a PDF upload.
 *  Keep this as a concrete DTO instead of Map<String, Any> so Kotlin Serialization
 *  always knows the exact JSON schema.
 */
@Serializable
data class PdfUploadResponse(
    val ok: Boolean,
    val extraction: PdfExtractionSummary
)


@Serializable
data class PdfLayoutPageSummary(
    val page: Int,
    val characters: Int,
    val lines: Int,
    val columns: Int = 0,
    val minX: Float? = null,
    val maxX: Float? = null,
    val minY: Float? = null,
    val maxY: Float? = null
)

private data class LayoutPageResult(
    val page: Int,
    val text: String,
    val characters: Int,
    val lines: Int,
    val columns: Int,
    val minX: Float?,
    val maxX: Float?,
    val minY: Float?,
    val maxY: Float?
)

private data class LayoutFragment(
    val text: String,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float
)

private class CoordinateAwareStripper : PDFTextStripper() {
    val fragments = mutableListOf<LayoutFragment>()
    var totalCharacters: Int = 0
        private set

    init {
        sortByPosition = true
        addMoreFormatting = false
    }

    override fun writeString(text: String, textPositions: List<TextPosition>) {
        if (textPositions.isNotEmpty()) {
            val first = textPositions.first()
            fragments += LayoutFragment(
                text = text,
                x = first.x,
                y = first.y,
                width = textPositions.sumOf { it.width.toDouble() }.toFloat(),
                height = textPositions.maxOf { it.height }
            )
        }
        totalCharacters += text.count { !it.isWhitespace() }
        super.writeString(text, textPositions)
    }
}

private fun estimateLineCount(fragments: List<LayoutFragment>): Int {
    if (fragments.isEmpty()) return 0
    val tolerance = fragments.map { it.height }.average().toFloat().coerceAtLeast(2f) * 0.55f
    return fragments.map { it.y }.sorted().fold(mutableListOf<Float>()) { lines, y ->
        if (lines.isEmpty() || kotlin.math.abs(lines.last() - y) > tolerance) lines += y
        lines
    }.size
}

private fun estimateColumnCount(fragments: List<LayoutFragment>): Int {
    if (fragments.size < 4) return if (fragments.isEmpty()) 0 else 1
    val xs = fragments.map { it.x }.sorted()
    val gapThreshold = 45f
    var columns = 1
    for (i in 1 until xs.size) {
        if (xs[i] - xs[i - 1] > gapThreshold) columns++
    }
    return columns.coerceAtMost(4)
}

private fun analyzePdfLayout(file: File): List<PdfLayoutPageSummary> {
    Loader.loadPDF(file).use { document ->
        val summaries = mutableListOf<PdfLayoutPageSummary>()
        for (pageNumber in 1..document.numberOfPages) {
            val stripper = CoordinateAwareStripper()
            stripper.startPage = pageNumber
            stripper.endPage = pageNumber
            stripper.getText(document)
            val fragments = stripper.fragments
            val xs = fragments.map { it.x }
            val ys = fragments.map { it.y }
            summaries += PdfLayoutPageSummary(
                page = pageNumber,
                characters = stripper.totalCharacters,
                lines = estimateLineCount(fragments),
                columns = estimateColumnCount(fragments),
                minX = xs.minOrNull(),
                maxX = fragments.map { it.x + it.width }.maxOrNull(),
                minY = ys.minOrNull(),
                maxY = fragments.map { it.y + it.height }.maxOrNull()
            )
        }
        return summaries
    }
}


private data class RebuiltLayoutLine(
    val page: Int,
    val y: Float,
    val xStart: Float,
    val xEnd: Float,
    val text: String,
    val fragments: Int
)

private data class LayoutColumnBlock(
    val page: Int,
    val column: Int,
    val xStart: Float,
    val xEnd: Float,
    val lines: List<RebuiltLayoutLine>
)

private fun rebuildLayoutLines(page: Int, fragments: List<LayoutFragment>): List<RebuiltLayoutLine> {
    if (fragments.isEmpty()) return emptyList()
    val averageHeight = fragments.map { it.height }.average().toFloat().coerceAtLeast(2f)
    val yTolerance = (averageHeight * 0.65f).coerceAtLeast(2.5f)
    val buckets = mutableListOf<MutableList<LayoutFragment>>()
    for (fragment in fragments.sortedWith(compareBy<LayoutFragment> { it.y }.thenBy { it.x })) {
        val bucket = buckets.lastOrNull()
        if (bucket == null || kotlin.math.abs(bucket.map { it.y }.average().toFloat() - fragment.y) > yTolerance) {
            buckets += mutableListOf(fragment)
        } else {
            bucket += fragment
        }
    }
    return buckets.map { bucket ->
        val ordered = bucket.sortedBy { it.x }
        RebuiltLayoutLine(
            page = page,
            y = ordered.map { it.y }.average().toFloat(),
            xStart = ordered.minOf { it.x },
            xEnd = ordered.maxOf { it.x + it.width },
            text = ordered.joinToString(" ") { it.text.trim() }.replace(Regex("\\s+"), " ").trim(),
            fragments = ordered.size
        )
    }
}

private fun rebuildColumnBlocks(page: Int, lines: List<RebuiltLayoutLine>): List<LayoutColumnBlock> {
    if (lines.isEmpty()) return emptyList()

    // Stage 14: build columns from horizontal bands instead of assuming that
    // every large X gap represents a new column. The center of each line is
    // used so wrapped lines remain attached to the same visual column.
    val orderedByX = lines.sortedBy { (it.xStart + it.xEnd) / 2f }
    val centers = orderedByX.map { (it.xStart + it.xEnd) / 2f }
    val gaps = centers.zipWithNext { a, b -> b - a }.filter { it > 0f }
    val adaptiveGap = if (gaps.isEmpty()) 90f else {
        val typicalGap = gaps.sorted()[gaps.size / 2]
        maxOf(55f, typicalGap * 2.2f)
    }

    val bands = mutableListOf<MutableList<RebuiltLayoutLine>>()
    for (line in orderedByX) {
        val center = (line.xStart + line.xEnd) / 2f
        val nearest = bands.minByOrNull { band ->
            kotlin.math.abs(band.map { (it.xStart + it.xEnd) / 2f }.average().toFloat() - center)
        }
        if (nearest == null || kotlin.math.abs(
                nearest.map { (it.xStart + it.xEnd) / 2f }.average().toFloat() - center
            ) > adaptiveGap
        ) {
            bands += mutableListOf(line)
        } else {
            nearest += line
        }
    }

    // Number columns in RTL reading order: the rightmost column is 1.
    return bands.sortedByDescending { band -> band.map { it.xStart }.average() }
        .mapIndexed { index, band ->
            LayoutColumnBlock(
                page = page,
                column = index + 1,
                xStart = band.minOf { it.xStart },
                xEnd = band.maxOf { it.xEnd },
                lines = band.sortedBy { it.y }
            )
        }
}

private fun analyzeStructuredLayout(file: File): List<LayoutColumnBlock> {
    Loader.loadPDF(file).use { document ->
        val blocks = mutableListOf<LayoutColumnBlock>()
        for (pageNumber in 1..document.numberOfPages) {
            val stripper = CoordinateAwareStripper()
            stripper.startPage = pageNumber
            stripper.endPage = pageNumber
            stripper.getText(document)
            val lines = rebuildLayoutLines(pageNumber, stripper.fragments)
            blocks += rebuildColumnBlocks(pageNumber, lines)
        }
        // Reading order for RTL exam layouts: top-to-bottom inside each column,
        // then columns from right to left. This prevents a left column from
        // being appended before the continuation in the right column.
        return blocks.sortedWith(
            compareBy<LayoutColumnBlock> { it.page }
                .thenBy { it.column }
        )
    }
}

@Serializable
data class PdfLayoutOrderIssue(
    val page: Int,
    val lineIndex: Int,
    val previousColumn: Int,
    val currentColumn: Int,
    val message: String
)

@Serializable
data class PdfLayoutOrderAuditReport(
    val pages: Int,
    val totalLines: Int,
    val columnTransitions: Int,
    val issues: List<PdfLayoutOrderIssue>,
    val warnings: List<String>
)

/** Stage 20: audit the reconstructed reading order without changing source text. */
fun buildPdfLayoutOrderAudit(file: File): PdfLayoutOrderAuditReport {
    val trace = buildPdfLayoutTraceReport(file)
    val issues = mutableListOf<PdfLayoutOrderIssue>()
    var transitions = 0
    trace.lines.groupBy { it.page }.forEach { (page, pageLines) ->
        var previousColumn: Int? = null
        var previousY: Float? = null
        pageLines.forEachIndexed { index, line ->
            if (previousColumn != null && previousColumn != line.column) {
                transitions++
                if (previousY != null && line.y + 3f < previousY!!) {
                    issues += PdfLayoutOrderIssue(
                        page = page,
                        lineIndex = index,
                        previousColumn = previousColumn!!,
                        currentColumn = line.column,
                        message = "انتقال ستون همراه با برگشت عمودی مشکوک است؛ ترتیب خواندن بررسی شود."
                    )
                }
            }
            previousColumn = line.column
            previousY = line.y
        }
    }
    val warnings = mutableListOf<String>()
    if (issues.isNotEmpty()) warnings += "برخی انتقال‌های ستونی نیازمند بررسی دستی هستند."
    warnings += "این ممیزی فقط هشدار تولید می‌کند و متن یا خطوط را حذف یا جابه‌جا نمی‌کند."
    return PdfLayoutOrderAuditReport(
        pages = trace.pages,
        totalLines = trace.lines.size,
        columnTransitions = transitions,
        issues = issues,
        warnings = warnings
    )
}

@Serializable
data class PdfDiagnosticPage(
    val page: Int,
    val columns: Int,
    val lines: Int,
    val characters: Int
)

@Serializable
data class PdfDiagnosticReport(
    val pages: List<PdfDiagnosticPage>,
    val totalColumns: Int,
    val totalLines: Int,
    val totalCharacters: Int,
    val warnings: List<String>
)


@Serializable
data class PdfDiagnosticLine(
    val page: Int,
    val column: Int,
    val y: Float,
    val xStart: Float,
    val xEnd: Float,
    val text: String,
    val fragments: Int
)

@Serializable
data class PdfLayoutTraceReport(
    val pages: Int,
    val lines: List<PdfDiagnosticLine>,
    val warnings: List<String>
)

/** Stage 18: expose reconstructed lines and column order without extracting questions. */
fun buildPdfLayoutTraceReport(file: File): PdfLayoutTraceReport {
    Loader.loadPDF(file).use { document ->
        val output = mutableListOf<PdfDiagnosticLine>()
        for (pageNumber in 1..document.numberOfPages) {
            val stripper = CoordinateAwareStripper()
            stripper.startPage = pageNumber
            stripper.endPage = pageNumber
            stripper.getText(document)
            val lines = rebuildLayoutLines(pageNumber, stripper.fragments)
            val blocks = rebuildColumnBlocks(pageNumber, lines)
            for (block in blocks) {
                for (line in block.lines) {
                    output += PdfDiagnosticLine(
                        page = line.page,
                        column = block.column,
                        y = line.y,
                        xStart = line.xStart,
                        xEnd = line.xEnd,
                        text = line.text,
                        fragments = line.fragments
                    )
                }
            }
        }
        val warnings = mutableListOf<String>()
        if (output.isEmpty()) warnings += "هیچ خط متنی از PDF بازسازی نشد."
        if (output.any { it.text.length < 2 }) warnings += "برخی خطوط بسیار کوتاه هستند و نیاز به بررسی دارند."
        warnings += "این گزارش فقط برای بررسی ترتیب خطوط و ستون‌هاست و سؤال یا گزینه را تأیید نمی‌کند."
        return PdfLayoutTraceReport(document.numberOfPages, output, warnings)
    }
}

/** Stage 16: produce a deterministic, non-destructive layout diagnostic report. */
fun buildPdfDiagnosticReport(file: File): PdfDiagnosticReport {
    val pageSummaries = analyzePdfLayout(file)
    val pages = pageSummaries.map {
        PdfDiagnosticPage(
            page = it.page,
            columns = it.columns,
            lines = it.lines,
            characters = it.characters
        )
    }
    val warnings = mutableListOf<String>()
    if (pages.any { it.columns > 2 }) warnings += "برخی صفحات بیش از دو نوار افقی احتمالی دارند؛ نیازمند بررسی مختصات هستند."
    if (pages.any { it.lines == 0 }) warnings += "حداقل یک صفحه بدون خط بازسازی‌شده شناسایی شد."
    warnings += "گزارش تشخیصی فقط داده جمع‌آوری می‌کند و متن یا سؤال را حذف نمی‌کند."
    return PdfDiagnosticReport(
        pages = pages,
        totalColumns = pages.sumOf { it.columns },
        totalLines = pages.sumOf { it.lines },
        totalCharacters = pages.sumOf { it.characters },
        warnings = warnings
    )
}


@Serializable
data class PdfProfilePage(
    val page: Int,
    val characters: Int,
    val lines: Int,
    val estimatedColumns: Int,
    val textDensity: String
)

@Serializable
data class PdfProfileReport(
    val pages: Int,
    val profile: String,
    val textBased: Boolean,
    val likelyMultiColumn: Boolean,
    val pagesWithNoText: List<Int>,
    val pageProfiles: List<PdfProfilePage>,
    val warnings: List<String>
)

/** Stage 25: classify the PDF before question extraction. This is descriptive only. */
fun buildPdfProfileReport(file: File): PdfProfileReport {
    val layout = analyzePdfLayout(file)
    val pageProfiles = layout.map { page ->
        val density = when {
            page.characters == 0 -> "NONE"
            page.characters < 300 -> "LOW"
            page.characters < 1200 -> "MEDIUM"
            else -> "HIGH"
        }
        PdfProfilePage(page.page, page.characters, page.lines, page.columns, density)
    }
    val noText = pageProfiles.filter { it.characters == 0 }.map { it.page }
    val textBased = pageProfiles.any { it.characters > 0 }
    val likelyMultiColumn = pageProfiles.any { it.estimatedColumns >= 2 }
    val warnings = mutableListOf<String>()
    if (!textBased) warnings += "متن قابل استخراج شناسایی نشد؛ احتمال اسکن بودن PDF وجود دارد."
    if (noText.isNotEmpty()) warnings += "صفحات بدون متن: ${noText.joinToString(", ")}."
    if (likelyMultiColumn) warnings += "حداقل یک صفحه دارای چند ستون احتمالی است؛ ترتیب خواندن باید با مختصات بررسی شود."
    warnings += "این پروفایل فقط بر اساس متن و مختصات PDF است و تشخیص سؤال انجام نمی‌دهد."
    val profile = when {
        !textBased -> "IMAGE_OR_SCANNED"
        likelyMultiColumn -> "TEXT_MULTI_COLUMN"
        else -> "TEXT_SINGLE_FLOW"
    }
    return PdfProfileReport(
        pages = pageProfiles.size,
        profile = profile,
        textBased = textBased,
        likelyMultiColumn = likelyMultiColumn,
        pagesWithNoText = noText,
        pageProfiles = pageProfiles,
        warnings = warnings
    )
}


@Serializable
data class PdfExtractionStrategy(
    val profile: String,
    val primaryStrategy: String,
    val fallbackStrategy: String,
    val requiresCoordinateOrdering: Boolean,
    val requiresOcrFallback: Boolean,
    val warnings: List<String>
)

/** Stage 26: choose a processing route from the descriptive PDF profile. */
fun choosePdfExtractionStrategy(file: File): PdfExtractionStrategy {
    val profile = buildPdfProfileReport(file)
    return when (profile.profile) {
        "IMAGE_OR_SCANNED" -> PdfExtractionStrategy(
            profile = profile.profile,
            primaryStrategy = "OCR_WITH_LAYOUT_REVIEW",
            fallbackStrategy = "MANUAL_REVIEW",
            requiresCoordinateOrdering = true,
            requiresOcrFallback = true,
            warnings = profile.warnings + "مسیر OCR فقط به‌عنوان راهکار جایگزین انتخاب شده و هنوز اجرا نمی‌شود."
        )
        "TEXT_MULTI_COLUMN" -> PdfExtractionStrategy(
            profile = profile.profile,
            primaryStrategy = "TEXT_COORDINATE_LAYOUT",
            fallbackStrategy = "RAW_TEXT_WITH_REVIEW",
            requiresCoordinateOrdering = true,
            requiresOcrFallback = false,
            warnings = profile.warnings + "ترتیب خواندن باید با مختصات و ستون‌ها کنترل شود."
        )
        else -> PdfExtractionStrategy(
            profile = profile.profile,
            primaryStrategy = "TEXT_LINE_RECONSTRUCTION",
            fallbackStrategy = "TEXT_COORDINATE_LAYOUT",
            requiresCoordinateOrdering = false,
            requiresOcrFallback = false,
            warnings = profile.warnings + "مسیر متنی انتخاب شد؛ خروجی سؤال‌ها همچنان نیازمند اعتبارسنجی است."
        )
    }
}

@Serializable
data class OcrFallbackReadiness(
    val profile: String,
    val ocrRequired: Boolean,
    val ocrAvailable: Boolean,
    val status: String,
    val reason: String,
    val nextAction: String
)

/** Stage 27: report OCR fallback readiness without silently pretending OCR is installed. */
fun assessOcrFallbackReadiness(file: File): OcrFallbackReadiness {
    val profile = buildPdfProfileReport(file)
    val required = profile.profile == "IMAGE_OR_SCANNED" || profile.pagesWithNoText.isNotEmpty()
    return if (required) {
        OcrFallbackReadiness(
            profile = profile.profile,
            ocrRequired = true,
            ocrAvailable = false,
            status = "NOT_CONFIGURED",
            reason = "برای این PDF احتمال نیاز به OCR وجود دارد؛ موتور OCR هنوز به پروژه متصل نشده است.",
            nextAction = "MANUAL_REVIEW_OR_CONFIGURE_OCR"
        )
    } else {
        OcrFallbackReadiness(
            profile = profile.profile,
            ocrRequired = false,
            ocrAvailable = false,
            status = "NOT_NEEDED",
            reason = "پروفایل PDF دارای متن قابل استخراج است؛ OCR به‌عنوان مسیر اصلی لازم نیست.",
            nextAction = "USE_TEXT_COORDINATE_PIPELINE"
        )
    }
}

fun extractPdfSummary(file: File): PdfExtractionSummary {
    val pages = analyzePdfLayout(file)
    return PdfExtractionSummary(
        pages = pages.size,
        extractedCharacters = pages.sumOf { it.characters },
        detectedQuestionNumbers = emptyList(),
        needsReview = true,
        message = "مرحله دوم بازسازی خطوط و برآورد ستون‌ها انجام شد؛ تشخیص سؤال و گزینه هنوز فعال نیست."
    )
}

@Serializable
data class ExtractedQuestionCandidate(
    val number: Int,
    val text: String,
    val options: List<String>,
    val correctIndex: Int = -1,
    val needsReview: Boolean = true,
    val validationStatus: String = "REVIEW",
    val validationReasons: List<String> = emptyList(),
    val confidenceScore: Int = 0,
    val confidenceReasons: List<String> = emptyList()
)

@Serializable
data class ReviewQueueItem(
    val questionNumber: Int,
    val status: String,
    val confidenceScore: Int,
    val reasons: List<String>,
    val suggestedAction: String
)

@Serializable
data class PdfQuestionExtraction(
    val pages: Int,
    val questions: List<ExtractedQuestionCandidate>,
    val warnings: List<String> = emptyList(),
    val reviewQueue: List<ReviewQueueItem> = emptyList()
)

private data class QuestionStartMarker(
    val number: Int,
    val remainder: String,
    val page: Int,
    val column: Int,
    val lineIndex: Int
)

private fun normalizeDigits(value: String): String = value
    .map { ch -> when (ch) {
        in '۰'..'۹' -> ('0'.code + (ch.code - '۰'.code)).toChar()
        in '٠'..'٩' -> ('0'.code + (ch.code - '٠'.code)).toChar()
        else -> ch
    } }.joinToString("")

private fun detectQuestionStart(line: RebuiltLayoutLine, lineIndex: Int, column: Int): QuestionStartMarker? {
    // Stage 31: recognize Persian/Arabic digits as well as ASCII digits.
    val match = Regex("""^\s*(?:سؤال|سوال)?\s*([0-9۰-۹٠-٩]{1,3})\s*[\)\.\-:؛،]\s*(.*)$""").matchEntire(line.text)
        ?: return null
    val number = normalizeDigits(match.groupValues[1]).toIntOrNull() ?: return null
    if (number !in 1..999) return null
    val remainder = match.groupValues[2].trim()
    // Stage 35: reject weak numeric markers that are likely page noise,
    // isolated years, measurements, or option fragments. Explicit question
    // labels remain accepted even when the remainder is short.
    val hasExplicitQuestionLabel = Regex("""^\s*(?:سؤال|سوال)""").containsMatchIn(line.text)
    val looksLikeNoise = remainder.isBlank() ||
        remainder.length < 8 ||
        Regex("""^(?:[۰-۹٠-٩0-9]{1,4}|[۰-۹٠-٩0-9]{1,4}\s*[٪%]?)$""").matches(remainder)
    if (!hasExplicitQuestionLabel && looksLikeNoise) return null
    return QuestionStartMarker(number, remainder, line.page, column, lineIndex)
}

private fun detectQuestionStarts(blocks: List<LayoutColumnBlock>): List<QuestionStartMarker> = buildList {
    for (block in blocks) {
        block.lines.forEachIndexed { index, line ->
            detectQuestionStart(line, index, block.column)?.let { add(it) }
        }
    }
}

private fun detectOptionStart(text: String): Pair<String, String>? {
    // Stage 31: support ASCII/Persian/Arabic option digits and common Persian labels.
    val match = Regex("""^\s*(?:[\(\[]?([1-4۱-۴١-٤]|[الفبجد])[»«\)\]\.\-:؛،]*)\s*(.+)$""").matchEntire(text)
        ?: return null
    val marker = match.groupValues[1]
    val content = match.groupValues[2].trim()
    if (content.isBlank()) return null
    return marker to content
}

private fun buildQuestionCandidates(blocks: List<LayoutColumnBlock>): List<ExtractedQuestionCandidate> {
    val orderedLines = blocks.flatMap { block ->
        block.lines.map { line -> Triple(block.column, line.y, line) }
    }.sortedWith(compareBy<Triple<Int, Float, RebuiltLayoutLine>> { it.third.page }
        // Stage 33: Persian exam pages are commonly laid out RTL; visit the
        // right-hand column before the left-hand column while preserving
        // top-to-bottom order inside each column.
        .thenByDescending { it.first }.thenBy { it.second })

    val starts = orderedLines.mapIndexedNotNull { index, item ->
        detectQuestionStart(item.third, index, item.first)?.let { it to index }
    }

    return starts.mapIndexed { index, pair ->
        val marker = pair.first
        val startIndex = pair.second
        val endIndex = starts.getOrNull(index + 1)?.second ?: orderedLines.size
        val lines = orderedLines.subList(startIndex, endIndex)
            .map { it.third.text.trim() }
            .filter { it.isNotBlank() }

        val questionLines = mutableListOf<String>()
        val options = mutableListOf<String>()
        var currentOption = -1
        for (line in lines) {
            val option = detectOptionStart(line)
            if (option != null) {
                currentOption++
                options += option.second
            } else if (currentOption >= 0) {
                options[currentOption] = (options[currentOption] + " " + line).trim()
            } else {
                questionLines += line
            }
        }

        val cleanedQuestion = questionLines.joinToString(" ")
            .replace(Regex("""\s+"""), " ").trim()
        val validOptions = options.toList()
        val optionCountValid = options.size == 4
        val optionTextsValid = options.all { it.trim().isNotBlank() }
        val questionTextValid = cleanedQuestion.length >= 3
        val reasons = buildList {
            if (!questionTextValid) add("متن سؤال خالی یا بسیار کوتاه است.")
            if (!optionCountValid) add("تعداد گزینه‌ها ${options.size} است؛ مقدار مورد انتظار ۴ است.")
            if (!optionTextsValid) add("حداقل یک گزینه متن معتبر ندارد.")
        }
        val suspicious = reasons.isNotEmpty()
        val confidenceReasons = buildList {
            if (questionTextValid) add("متن سؤال دارای طول حداقلی معتبر است.")
            else add("متن سؤال کوتاه یا خالی است.")
            if (optionCountValid) add("تعداد گزینه‌ها دقیقاً ۴ است.")
            else add("تعداد گزینه‌ها با مقدار مورد انتظار تفاوت دارد.")
            if (optionTextsValid) add("متن همه گزینه‌ها غیرخالی است.")
            else add("حداقل یک گزینه خالی است.")
        }
        val confidenceScore = listOf(
            if (questionTextValid) 35 else 0,
            if (optionCountValid) 40 else 0,
            if (optionTextsValid) 25 else 0
        ).sum()

        ExtractedQuestionCandidate(
            number = marker.number,
            text = cleanedQuestion,
            options = validOptions,
            correctIndex = -1,
            needsReview = suspicious || confidenceScore < 100,
            validationStatus = if (suspicious) "QUARANTINED" else "PRELIMINARILY_VALID",
            validationReasons = reasons,
            confidenceScore = confidenceScore,
            confidenceReasons = confidenceReasons
        )
    }
}

private fun reprocessQuestionCandidate(candidate: ExtractedQuestionCandidate): ExtractedQuestionCandidate {
    val cleanedOptions = candidate.options
        .map { it.replace(Regex("\\s+"), " ").trim() }
        .filter { it.isNotBlank() }

    val repairNotes = mutableListOf<String>()
    if (cleanedOptions.size != candidate.options.size) {
        repairNotes += "گزینه‌های خالی یا دارای فاصله اضافی پاک‌سازی شدند."
    }

    val text = candidate.text.replace(Regex("\\s+"), " ").trim()
    val questionValid = text.length >= 3
    val optionsCountValid = cleanedOptions.size == 4
    val optionsTextValid = cleanedOptions.all { it.isNotBlank() }
    val reasons = buildList {
        if (!questionValid) add("متن سؤال خالی یا بسیار کوتاه است.")
        if (!optionsCountValid) add("پس از بازپردازش تعداد گزینه‌ها ${cleanedOptions.size} است؛ مقدار مورد انتظار ۴ است.")
        if (!optionsTextValid) add("حداقل یک گزینه پس از بازپردازش متن معتبر ندارد.")
    }
    val score = (if (questionValid) 35 else 0) +
        (if (optionsCountValid) 40 else 0) +
        (if (optionsTextValid) 25 else 0)
    val confidenceReasons = buildList {
        add(if (questionValid) "متن سؤال پس از پاک‌سازی معتبر است." else "متن سؤال پس از بازپردازش معتبر نیست.")
        add(if (optionsCountValid) "تعداد گزینه‌ها پس از بازپردازش دقیقاً ۴ است." else "تعداد گزینه‌ها پس از بازپردازش ۴ نیست.")
        add(if (optionsTextValid) "متن همه گزینه‌ها پس از پاک‌سازی غیرخالی است." else "حداقل یک گزینه پس از پاک‌سازی خالی است.")
        addAll(repairNotes)
    }
    return candidate.copy(
        text = text,
        options = cleanedOptions,
        needsReview = reasons.isNotEmpty() || score < 100,
        validationStatus = if (reasons.isNotEmpty()) "QUARANTINED" else "PRELIMINARILY_VALID",
        validationReasons = reasons,
        confidenceScore = score,
        confidenceReasons = confidenceReasons
    )
}


@Serializable
data class PdfQuestionReconstructionReport(
    val pages: Int,
    val inputQuestions: Int,
    val reconstructedQuestions: List<ExtractedQuestionCandidate>,
    val repairedCount: Int,
    val warnings: List<String> = emptyList()
)

/** Stage 24: conservative reconstruction of already detected candidates.
 * No new question is invented and no option is silently discarded. Text is
 * normalized, continuation fragments are joined, and every changed candidate
 * remains reviewable.
 */
fun buildPdfQuestionReconstructionReport(file: File): PdfQuestionReconstructionReport {
    val blocks = analyzeStructuredLayout(file)
    val candidates = buildQuestionCandidates(blocks)
    val reconstructed = candidates.map { candidate ->
        val beforeText = candidate.text
        val beforeOptions = candidate.options
        val repaired = reprocessQuestionCandidate(candidate)
        val changed = beforeText != repaired.text || beforeOptions != repaired.options
        if (changed) {
            repaired.copy(
                needsReview = true,
                validationStatus = if (repaired.validationStatus == "PRELIMINARILY_VALID") "REVIEW" else repaired.validationStatus,
                confidenceReasons = repaired.confidenceReasons + "بازسازی محافظه‌کارانه انجام شد؛ بررسی دستی همچنان لازم است."
            )
        } else repaired
    }
    val warnings = mutableListOf<String>()
    if (reconstructed.isEmpty()) warnings += "هیچ کاندیدای سؤال برای بازسازی شناسایی نشد."
    if (reconstructed.any { it.options.size != 4 }) warnings += "برخی کاندیداها پس از بازسازی هنوز چهار گزینه معتبر ندارند."
    warnings += "بازسازی محافظه‌کارانه است؛ داده‌ای بدون شواهد کافی حذف یا به سؤال دیگری منتقل نمی‌شود."
    return PdfQuestionReconstructionReport(
        pages = Loader.loadPDF(file).use { it.numberOfPages },
        inputQuestions = candidates.size,
        reconstructedQuestions = reconstructed,
        repairedCount = reconstructed.zip(candidates).count { (after, before) -> after.text != before.text || after.options != before.options },
        warnings = warnings
    )
}

/** Stage 11: audit numbering continuity without silently deleting any candidate. */
private fun buildNumberingAudit(numbers: List<Int>): List<String> {
    if (numbers.isEmpty()) return listOf("ممیزی شماره‌گذاری: هیچ شماره سؤالی شناسایی نشد.")
    val warnings = mutableListOf<String>()
    val sorted = numbers.sorted()
    val duplicates = numbers.groupBy { it }.filterValues { it.size > 1 }.keys.sorted()
    if (duplicates.isNotEmpty()) {
        warnings += "ممیزی شماره‌گذاری: شماره‌های تکراری: ${duplicates.joinToString(", ")}."
    }
    val min = sorted.first()
    val max = sorted.last()
    val missing = (min..max).filter { it !in sorted.toSet() }
    if (missing.isNotEmpty()) {
        warnings += "ممیزی شماره‌گذاری: شماره‌های گمشده در بازه $min تا $max: ${missing.joinToString(", ")}."
    }
    val outOfTypicalRange = sorted.filter { it !in 1..200 }
    if (outOfTypicalRange.isNotEmpty()) {
        warnings += "ممیزی شماره‌گذاری: شماره‌های خارج از بازه معمول ۱ تا ۲۰۰: ${outOfTypicalRange.joinToString(", ")}."
    }
    if (warnings.isEmpty()) warnings += "ممیزی شماره‌گذاری: تکرار یا شکاف شماره‌گذاری در کاندیداهای شناسایی‌شده مشاهده نشد."
    return warnings
}

/** Stage 12: audit page transitions so a question can continue across pages/columns. */
private fun buildPageContinuationAudit(
    blocks: List<LayoutColumnBlock>,
    starts: List<QuestionStartMarker>
): List<String> {
    val warnings = mutableListOf<String>()
    if (blocks.isEmpty()) return listOf("ممیزی ادامه صفحه: هیچ بلوک متنی برای بررسی وجود ندارد.")

    val pageNumbers = blocks.map { it.page }.distinct().sorted()
    val startsByPage = starts.groupBy { it.page }
    for (page in pageNumbers) {
        if (page > pageNumbers.first() && startsByPage[page].isNullOrEmpty()) {
            warnings += "ممیزی ادامه صفحه: در صفحه $page شروع سؤال مستقلی دیده نشد؛ احتمال ادامه سؤال از صفحه قبل باید بررسی شود."
        }
    }

    val orderedStarts = starts.sortedWith(compareBy<QuestionStartMarker> { it.page }.thenBy { it.column }.thenBy { it.lineIndex })
    for (index in 0 until (orderedStarts.size - 1)) {
        val current = orderedStarts[index]
        val next = orderedStarts[index + 1]
        if (next.page > current.page) {
            warnings += "ممیزی ادامه صفحه: سؤال ${current.number} از صفحه ${current.page} تا پیش از شروع سؤال ${next.number} در صفحه ${next.page} امتداد دارد؛ اتصال متن و گزینه‌ها باید بررسی شود."
        }
    }

    if (warnings.isEmpty()) {
        warnings += "ممیزی ادامه صفحه: مورد مشکوک مشخصی درباره عبور سؤال از صفحه شناسایی نشد؛ بررسی مختصات همچنان فعال است."
    }
    return warnings
}

/** Stage 15: audit transitions between visual columns before attaching continuation lines. */
private fun buildColumnTransitionAudit(blocks: List<LayoutColumnBlock>): List<String> {
    if (blocks.isEmpty()) return listOf("ممیزی انتقال ستون: هیچ ستونی برای بررسی وجود ندارد.")
    val warnings = mutableListOf<String>()
    val byPage = blocks.groupBy { it.page }
    for ((page, pageBlocks) in byPage.toSortedMap()) {
        val ordered = pageBlocks.sortedBy { it.column }
        for (index in 0 until (ordered.size - 1)) {
            val current = ordered[index]
            val next = ordered[index + 1]
            val currentLast = current.lines.lastOrNull()?.text.orEmpty()
            val nextFirst = next.lines.firstOrNull()?.text.orEmpty()
            if (currentLast.isNotBlank() && nextFirst.isNotBlank()) {
                warnings += "ممیزی انتقال ستون: صفحه $page، انتقال از ستون ${current.column} به ${next.column} ثبت شد؛ اتصال متن فقط با بررسی شماره سؤال و مختصات انجام شود."
            }
        }
    }
    if (warnings.isEmpty()) warnings += "ممیزی انتقال ستون: انتقال ستونی قابل گزارش یافت نشد."
    return warnings
}

/** Stage 12: reprocess candidates, audit numbering, and report page continuations. */
fun extractPdfQuestions(file: File): PdfQuestionExtraction {
    val layout = analyzePdfLayout(file)
    val blocks = analyzeStructuredLayout(file)
    val initialCandidates = buildQuestionCandidates(blocks)
    val candidates = initialCandidates.map { reprocessQuestionCandidate(it) }
    val starts = detectQuestionStarts(blocks)
    val duplicateNumbers = starts.groupBy { it.number }.filterValues { it.size > 1 }.keys.sorted()
    val suspiciousCandidates = candidates.count { it.needsReview }
    val validCandidates = candidates.size - suspiciousCandidates
    val missingOrExtraOptions = candidates.count { it.options.size != 4 }
    val blankQuestions = candidates.count { it.text.isBlank() }
    val warnings = mutableListOf(
        "مرحله یازدهم: گزارش تشخیصی، بازپردازش و ممیزی پیوستگی شماره‌ها تولید شد.",
        "تعداد شروع‌های شناسایی‌شده: ${starts.size}؛ کاندیداهای ساخته‌شده: ${candidates.size}.",
        "کاندیداهای قابل قبول اولیه: $validCandidates؛ کاندیداهای مشکوک و قرنطینه‌شده: $suspiciousCandidates.",
        "قانون اعتبارسنجی: هر سؤال باید متن غیرخالی و دقیقاً ۴ گزینه غیرخالی داشته باشد.",
        "تعداد کاندیداهای دارای تعداد گزینه نامعتبر: $missingOrExtraOptions؛ متن سؤال خالی: $blankQuestions.",
        "هیچ کاندیدای مشکوکی برای ورود مستقیم به آزمون تأیید نشده است؛ موارد مشکوک باید پیش از ذخیره بررسی یا بازپردازش شوند.",
        "امتیاز اطمینان: متن سؤال ۳۵ امتیاز، تعداد دقیقاً ۴ گزینه ۴۰ امتیاز و غیرخالی بودن گزینه‌ها ۲۵ امتیاز؛ سقف ۱۰۰ است.",
        "امتیاز کمتر از ۱۰۰ به‌صورت خودکار نیازمند بررسی باقی می‌ماند.",
        "بازپردازش ایمن: پاک‌سازی فاصله‌ها، حذف گزینه‌های کاملاً خالی و اعتبارسنجی دوباره؛ هیچ گزینه‌ای بدون شواهد مکانی ادغام یا حذف نمی‌شود."
    )
    if (duplicateNumbers.isNotEmpty()) warnings += "شماره‌های تکراری یا مشکوک: ${duplicateNumbers.joinToString(", ")}."
    warnings += buildNumberingAudit(candidates.map { it.number })
    warnings += "ممیزی شماره‌گذاری فقط گزارش تشخیصی است و هیچ کاندیدایی را حذف یا جابه‌جا نمی‌کند."
    warnings += "مرحله دوازدهم: بررسی عبور سؤال از مرز صفحه و احتمال ادامه متن در صفحه بعد."
    warnings += buildPageContinuationAudit(blocks, starts)
    warnings += buildColumnTransitionAudit(blocks)
    warnings += "مرحله پانزدهم: انتقال بین ستون‌ها فقط به‌عنوان رویداد ممیزی ثبت می‌شود و اتصال خودکار متن انجام نمی‌گیرد.",
        "مرحله شانزدهم: گزارش تشخیصی صفحه‌به‌صفحه شامل تعداد خطوط، ستون‌ها و نویسه‌ها تولید می‌شود؛ تأیید استخراج هنوز انجام نشده است."

    val reviewQueue = candidates
        .filter { it.needsReview }
        .map { candidate ->
            ReviewQueueItem(
                questionNumber = candidate.number,
                status = candidate.validationStatus,
                confidenceScore = candidate.confidenceScore,
                reasons = candidate.validationReasons.ifEmpty { candidate.confidenceReasons },
                suggestedAction = if (candidate.options.size != 4) {
                    "بازپردازش محدوده گزینه‌ها و بررسی دستی"
                } else if (candidate.text.isBlank()) {
                    "بازسازی متن سؤال از خطوط و مختصات PDF"
                } else {
                    "بررسی دستی پیش از تأیید نهایی"
                }
            )
        }

    warnings += "صف بررسی مجدد ساخته شد؛ تعداد موارد منتظر بررسی: ${reviewQueue.size}."
    return PdfQuestionExtraction(
        pages = layout.size,
        questions = candidates,
        warnings = warnings,
        reviewQueue = reviewQueue
    )
}

@Serializable data class Token(val token: String, val role: String)

private val jsonCodec = Json { ignoreUnknownKeys = true }

fun questionDto(row: ResultRow) = QuestionDto(
    id = row[Questions.id], examId = row[Questions.examId], number = row[Questions.number],
    text = row[Questions.text], options = jsonCodec.decodeFromString(row[Questions.options]),
    correctIndex = row[Questions.correctIndex], createdAt = row[Questions.createdAt].toString(),
    updatedAt = row[Questions.updatedAt].toString()
)

fun examDto(row: ResultRow) = ExamDto(
    id = row[Exams.id], title = row[Exams.title], grade = row[Exams.grade], field = row[Exams.field],
    examNumber = row[Exams.examNumber], examDate = row[Exams.examDate].toString(), year = row[Exams.year],
    period = row[Exams.period], month = row[Exams.month], description = row[Exams.description],
    pdfUrl = row[Exams.pdfUrl], durationSeconds = row[Exams.durationSeconds]
)

fun annotationDto(row: ResultRow) = AnnotationDto(
    id = row[Annotations.id].toString(), user_id = row[Annotations.userId].toString(),
    exam_id = row[Annotations.examId], page_number = row[Annotations.pageNumber], type = row[Annotations.type],
    content = row[Annotations.content], position = row[Annotations.position], color = row[Annotations.color],
    thickness = row[Annotations.thickness], created_at = row[Annotations.createdAt].toString(),
    updated_at = row[Annotations.updatedAt].toString()
)

object DevRefreshTokens : MutableMap<String, Pair<String, String>> by java.util.concurrent.ConcurrentHashMap()

object JwtAuth {
    private val secret = System.getenv("JWT_SECRET") ?: "CHANGE_ME"
    fun token(subject: String, role: String): String {
        val header = Base64.getUrlEncoder().withoutPadding().encodeToString("""{"alg":"HS256","typ":"JWT"}""".toByteArray())
        val now = java.time.Instant.now().epochSecond
        val expiresAt = now + 24 * 60 * 60
        val payloadJson = """{"sub":"$subject","role":"$role","iat":$now,"exp":$expiresAt}"""
        val payload = Base64.getUrlEncoder().withoutPadding().encodeToString(payloadJson.toByteArray())
        val data = "$header.$payload"
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(), "HmacSHA256"))
        val signature = Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(data.toByteArray()))
        return "$data.$signature"
    }
    val verifier = JWT.require(Algorithm.HMAC256(secret)).build()
}

fun main() {
    embeddedServer(Netty, port = System.getenv("PORT")?.toInt() ?: 8080, host = "0.0.0.0") {
        module()
    }.start(wait = true)
}

fun Application.module() {
    // Supports both a normal JDBC URL and Supabase's postgresql:// connection string.
    // Prefer explicit DB_USER/DB_PASSWORD when provided; otherwise read credentials
    // from DATABASE_URL without logging them.
    val configuredUrl = System.getenv("DATABASE_URL")
        ?: "jdbc:postgresql://localhost:5432/mazarchive"

    // PostgreSQL JDBC does not accept Supabase credentials embedded in the host part.
    // Extract credentials from the URI and build a clean JDBC URL containing only host/port/path.
    val uriValue = if (configuredUrl.startsWith("jdbc:")) {
        configuredUrl.removePrefix("jdbc:")
    } else {
        configuredUrl
    }

    val parsedUri = runCatching { URI(uriValue) }.getOrNull()
    val urlUserInfo = parsedUri?.userInfo
    val urlUser = urlUserInfo?.substringBefore(":")?.let {
        URLDecoder.decode(it, StandardCharsets.UTF_8)
    }
    val urlPassword = urlUserInfo?.substringAfter(":", "")?.let {
        URLDecoder.decode(it, StandardCharsets.UTF_8)
    }

    val jdbcUrl = if (parsedUri?.host != null) {
        val port = if (parsedUri.port != -1) ":${parsedUri.port}" else ""
        val path = parsedUri.rawPath.orEmpty().ifBlank { "/postgres" }
        val query = parsedUri.rawQuery?.let { "?$it" } ?: ""
        "jdbc:postgresql://${parsedUri.host}$port$path$query"
    } else if (configuredUrl.startsWith("jdbc:")) {
        configuredUrl
    } else {
        "jdbc:$configuredUrl"
    }

    val dbUser = System.getenv("DB_USER") ?: urlUser ?: "postgres"
    val dbPassword = System.getenv("DB_PASSWORD") ?: urlPassword ?: "postgres"

    Database.connect(
        url = jdbcUrl,
        driver = "org.postgresql.Driver",
        user = dbUser,
        password = dbPassword
    )
    transaction {
        SchemaUtils.create(Exams, Questions, Annotations, ExamAttempts)
        exec("ALTER TABLE exams ADD COLUMN IF NOT EXISTS description TEXT NOT NULL DEFAULT ''")
        exec("ALTER TABLE exams ADD COLUMN IF NOT EXISTS duration_seconds INTEGER NOT NULL DEFAULT 1800")
    }
    install(ContentNegotiation) { json() }
    install(Authentication) {
        jwt("auth") {
            verifier(JwtAuth.verifier)
            validate { principal -> if (principal.payload.subject != null) JWTPrincipal(principal.payload) else null }
        }
    }
    routing {
        staticResources("/admin", "web")
        get("/health") { call.respond(mapOf("status" to "ok")) }

        authenticate("auth") {
            get("/attempts") {
                val userKey = call.principal<JWTPrincipal>()!!.payload.subject
                val rows = transaction { ExamAttempts.selectAll().where { ExamAttempts.userKey eq userKey }.orderBy(ExamAttempts.createdAt, SortOrder.DESC).map {
                    AttemptDto(it[ExamAttempts.id], it[ExamAttempts.examId], it[ExamAttempts.correct], it[ExamAttempts.wrong], it[ExamAttempts.unanswered], it[ExamAttempts.total], it[ExamAttempts.percent], it[ExamAttempts.usedSeconds], it[ExamAttempts.submittedByTime], it[ExamAttempts.createdAt].toString())
                } }
                call.respond(rows)
            }
            post("/attempts") {
                val userKey = call.principal<JWTPrincipal>()!!.payload.subject
                val body = call.receive<AttemptRequest>()
                if (body.total <= 0 || body.correct < 0 || body.wrong < 0 || body.unanswered < 0 || body.correct + body.wrong + body.unanswered != body.total || body.percent !in 0f..100f) {
                    call.respond(HttpStatusCode.BadRequest, "اطلاعات کارنامه نامعتبر است"); return@post
                }
                val id = transaction { ExamAttempts.insert {
                    it[ExamAttempts.userKey] = userKey
                    it[ExamAttempts.examId] = body.examId
                    it[ExamAttempts.correct] = body.correct
                    it[ExamAttempts.wrong] = body.wrong
                    it[ExamAttempts.unanswered] = body.unanswered
                    it[ExamAttempts.total] = body.total
                    it[ExamAttempts.percent] = body.percent
                    it[ExamAttempts.usedSeconds] = body.usedSeconds
                    it[ExamAttempts.submittedByTime] = body.submittedByTime
                    it[ExamAttempts.createdAt] = Instant.now()
                } get ExamAttempts.id }
                call.respond(HttpStatusCode.Created, mapOf("id" to id))
            }
        }

        post("/auth/login") {
            val body = call.receive<Login>()
            val isAdmin = body.username == "admin" && body.password == (System.getenv("ADMIN_PASSWORD") ?: "change-me")
            if (!isAdmin) {
                call.respond(status = HttpStatusCode.Unauthorized, message = "نام کاربری یا رمز عبور نامعتبر است")
                return@post
            }
            val role = "ADMIN"
            val refresh = UUID.randomUUID().toString()
            DevRefreshTokens[refresh] = body.username to role
            call.respond(mapOf("token" to JwtAuth.token(body.username, role), "role" to role, "refreshToken" to refresh))
        }

        post("/auth/refresh") {
            val body = call.receive<Map<String, String>>()
            val refresh = body["refreshToken"]
            if (refresh == null) {
                call.respond(HttpStatusCode.BadRequest)
                return@post
            }
            val entry = DevRefreshTokens[refresh]
            if (entry == null) {
                call.respond(HttpStatusCode.Unauthorized)
                return@post
            }
            call.respond(Token(JwtAuth.token(entry.first, entry.second), entry.second))
        }

        authenticate("auth") {
            get("/exams") {
                val grade = call.request.queryParameters["grade"]
                val field = call.request.queryParameters["field"]
                val year = call.request.queryParameters["year"]?.toIntOrNull()
                val period = call.request.queryParameters["period"]
                val month = call.request.queryParameters["month"]
                val query = call.request.queryParameters["q"]?.trim()
                val conditions = listOfNotNull(
                    grade?.let { Exams.grade eq it }, field?.let { Exams.field eq it },
                    year?.let { Exams.year eq it }, period?.let { Exams.period eq it },
                    month?.let { Exams.month eq it }, query?.takeIf { it.isNotEmpty() }?.let { Exams.title eq it }
                )
                val rows = transaction {
                    if (conditions.isEmpty()) {
                        Exams.selectAll().orderBy(Exams.examDate, SortOrder.DESC).map(::examDto)
                    } else {
                        val predicate = conditions.drop(1).fold(conditions.first()) { acc, condition ->
                            Op.build { acc and condition }
                        }
                        Exams.selectAll().where { predicate }.orderBy(Exams.examDate, SortOrder.DESC).map(::examDto)
                    }
                }
                call.respond(rows)
            }

            get("/exams/{id}") {
                val id = call.parameters["id"]!!.toLong()
                val row = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull() }
                if (row == null) call.respond(HttpStatusCode.NotFound) else call.respond(examDto(row))
            }

            get("/exams/{id}/questions") {
                val id = call.parameters["id"]!!.toLong()
                val rows = transaction { Questions.selectAll().where { Questions.examId eq id }.orderBy(Questions.number).map(::questionDto) }
                call.respond(rows)
            }

            get("/exams/{id}/pdf") {
                val id = call.parameters["id"]!!.toLong()
                val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                if (path == null) { call.respond(HttpStatusCode.NotFound); return@get }
                val root = File(System.getenv("STORAGE_DIR") ?: "./storage")
                val file = File(path)
                if (!file.canonicalPath.startsWith(root.canonicalPath)) { call.respond(HttpStatusCode.Forbidden); return@get }
                if (!file.exists()) { call.respond(HttpStatusCode.NotFound); return@get }
                call.respondFile(file)
            }

            get("/exams/{id}/annotations") {
                val id = call.parameters["id"]!!.toLong()
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                val rows = transaction { Annotations.selectAll().where { (Annotations.examId eq id) and (Annotations.userId eq uid) }.map(::annotationDto) }
                call.respond(rows)
            }

            post("/exams/{id}/annotations") {
                val id = call.parameters["id"]!!.toLong()
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                val annotation = call.receive<AnnotationDto>()
                val annotationId = UUID.fromString(annotation.id)
                transaction {
                    Annotations.insert {
                        it[Annotations.id] = annotationId; it[userId] = uid; it[examId] = id
                        it[pageNumber] = annotation.page_number; it[type] = annotation.type; it[content] = annotation.content
                        it[position] = annotation.position; it[color] = annotation.color; it[thickness] = annotation.thickness
                        it[createdAt] = Instant.now(); it[updatedAt] = Instant.now()
                    }
                }
                call.respond(status = HttpStatusCode.Created, message = annotation.copy(user_id = uid.toString()))
            }

            put("/annotations/{id}") {
                val annotationId = UUID.fromString(call.parameters["id"]!!)
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                val annotation = call.receive<AnnotationDto>()
                transaction {
                    Annotations.update({ (Annotations.id eq annotationId) and (Annotations.userId eq uid) }) {
                        it[position] = annotation.position; it[color] = annotation.color; it[thickness] = annotation.thickness
                        it[content] = annotation.content; it[updatedAt] = Instant.now()
                    }
                }
                call.respond(annotation)
            }

            delete("/annotations/{id}") {
                val annotationId = UUID.fromString(call.parameters["id"]!!)
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                transaction { Annotations.deleteWhere { (Annotations.id eq annotationId) and (Annotations.userId eq uid) } }
                call.respond(HttpStatusCode.NoContent)
            }

            route("/admin") {
                suspend fun ApplicationCall.requireAdmin(): Boolean {
                    val isAdmin = principal<JWTPrincipal>()?.payload?.getClaim("role")?.asString() == "ADMIN"
                    if (!isAdmin) respond(status = HttpStatusCode.Forbidden, message = "دسترسی مدیر لازم است")
                    return isAdmin
                }

                get("/exams") {
                    if (!call.requireAdmin()) return@get
                    val rows = transaction { Exams.selectAll().orderBy(Exams.examDate, SortOrder.DESC).map(::examDto) }
                    call.respond(rows)
                }
                get("/stats") {
                    if (!call.requireAdmin()) return@get
                    val rows = transaction { Exams.selectAll().toList() }
                    call.respond(mapOf("total" to rows.size, "withPdf" to rows.count { it[Exams.pdfUrl].isNotBlank() }, "withoutPdf" to rows.count { it[Exams.pdfUrl].isBlank() }))
                }
                post("/exams") {
                    if (!call.requireAdmin()) return@post
                    val exam = call.receive<CreateExamDto>()
                    val newId = transaction {
                        Exams.insert {
                            it[title] = exam.title; it[grade] = exam.grade; it[field] = exam.field; it[examNumber] = exam.examNumber
                            it[examDate] = java.time.LocalDate.parse(exam.examDate); it[year] = exam.year; it[period] = exam.period
                            it[month] = exam.month; it[description] = exam.description; it[pdfUrl] = ""
                            it[durationSeconds] = exam.durationSeconds; it[createdAt] = Instant.now(); it[updatedAt] = Instant.now()
                        } get Exams.id
                    }
                    call.respond(
                        status = HttpStatusCode.Created,
                        message = ExamDto(
                            id = newId,
                            title = exam.title,
                            grade = exam.grade,
                            field = exam.field,
                            examNumber = exam.examNumber,
                            examDate = exam.examDate,
                            year = exam.year,
                            period = exam.period,
                            month = exam.month,
                            description = exam.description,
                            pdfUrl = "",
                            durationSeconds = exam.durationSeconds
                        )
                    )
                }
                put("/exams/{id}") {
                    if (!call.requireAdmin()) return@put
                    val id = call.parameters["id"]!!.toLong(); val exam = call.receive<ExamDto>()
                    transaction {
                        Exams.update({ Exams.id eq id }) {
                            it[title] = exam.title; it[grade] = exam.grade; it[field] = exam.field; it[examNumber] = exam.examNumber
                            it[examDate] = java.time.LocalDate.parse(exam.examDate); it[year] = exam.year; it[period] = exam.period
                            it[month] = exam.month; it[description] = exam.description; it[durationSeconds] = exam.durationSeconds
                            it[updatedAt] = Instant.now()
                        }
                    }
                    call.respond(exam)
                }
                delete("/exams/{id}") {
                    if (!call.requireAdmin()) return@delete
                    transaction { Exams.deleteWhere { Exams.id eq call.parameters["id"]!!.toLong() } }
                    call.respond(HttpStatusCode.NoContent)
                }
                get("/exams/{id}/questions") {
                    if (!call.requireAdmin()) return@get
                    val examId = call.parameters["id"]!!.toLong()
                    val rows = transaction { Questions.selectAll().where { Questions.examId eq examId }.orderBy(Questions.number).map(::questionDto) }
                    call.respond(rows)
                }
                post("/exams/{id}/questions") {
                    if (!call.requireAdmin()) return@post
                    val examId = call.parameters["id"]!!.toLong(); val question = call.receive<QuestionDto>()
                    if (question.text.isBlank() || question.options.size != 4 || question.options.any { it.isBlank() } || (question.correctIndex != null && question.correctIndex !in question.options.indices)) {
                        call.respond(status = HttpStatusCode.BadRequest, message = "ذخیره نشد: متن سؤال باید غیرخالی و تعداد گزینه‌ها دقیقاً ۴ گزینه غیرخالی باشد؛ پاسخ صحیح نیز باید معتبر باشد"); return@post
                    }
                    val duplicate = transaction {
                        Questions.selectAll().where { (Questions.examId eq examId) and (Questions.number eq question.number) }.count()
                    }
                    if (duplicate > 0) {
                        call.respond(HttpStatusCode.Conflict, "این شماره سؤال قبلاً برای این آزمون ثبت شده است؛ از ویرایش استفاده کنید"); return@post
                    }
                    val newId = transaction {
                        Questions.insert {
                            it[Questions.examId] = examId; it[number] = question.number; it[text] = question.text
                            it[options] = jsonCodec.encodeToString(ListSerializer(String.serializer()), question.options); it[correctIndex] = question.correctIndex
                            it[createdAt] = Instant.now(); it[updatedAt] = Instant.now()
                        } get Questions.id
                    }
                    call.respond(status = HttpStatusCode.Created, message = question.copy(id = newId, examId = examId))
                }
                put("/exams/{examId}/questions/{id}") {
                    if (!call.requireAdmin()) return@put
                    val examId = call.parameters["examId"]!!.toLong(); val id = call.parameters["id"]!!.toLong(); val question = call.receive<QuestionDto>()
                    if (question.text.isBlank() || question.options.size != 4 || question.options.any { it.isBlank() } || (question.correctIndex != null && question.correctIndex !in question.options.indices)) {
                        call.respond(status = HttpStatusCode.BadRequest, message = "ذخیره نشد: متن سؤال باید غیرخالی و تعداد گزینه‌ها دقیقاً ۴ گزینه غیرخالی باشد؛ پاسخ صحیح نیز باید معتبر باشد"); return@put
                    }
                    val duplicate = transaction {
                        Questions.selectAll().where { (Questions.examId eq examId) and (Questions.number eq question.number) and (Questions.id neq id) }.count()
                    }
                    if (duplicate > 0) {
                        call.respond(HttpStatusCode.Conflict, "این شماره سؤال قبلاً برای سؤال دیگری ثبت شده است"); return@put
                    }
                    val updated = transaction {
                        Questions.update({ (Questions.id eq id) and (Questions.examId eq examId) }) {
                            it[number] = question.number; it[text] = question.text; it[options] = jsonCodec.encodeToString(ListSerializer(String.serializer()), question.options)
                            it[correctIndex] = question.correctIndex; it[updatedAt] = Instant.now()
                        }
                    }
                    if (updated == 0) {
                        call.respond(HttpStatusCode.NotFound, "سؤال پیدا نشد"); return@put
                    }
                    call.respond(question.copy(id = id, examId = examId))
                }
                delete("/exams/{examId}/questions/{id}") {
                    if (!call.requireAdmin()) return@delete
                    val examId = call.parameters["examId"]!!.toLong(); val id = call.parameters["id"]!!.toLong()
                    transaction { Questions.deleteWhere { (Questions.id eq id) and (Questions.examId eq examId) } }
                    call.respond(HttpStatusCode.NoContent)
                }
                get("/exams/{id}/pdf/profile") {
                    if (!call.requireAdmin()) return@get
                    val id = call.parameters["id"]!!.toLong()
                    val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                    if (path.isNullOrBlank()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_NOT_REGISTERED", "PDF", "برای این آزمون فایل PDF ثبت نشده است.", examId = id)
                        return@get
                    }
                    val file = File(path)
                    if (!file.exists()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_FILE_MISSING", "PDF", "فایل PDF روی سرور پیدا نشد.", "مسیر ثبت‌شده: ${file.absolutePath}", id)
                        return@get
                    }
                    val report = try {
                        withContext(Dispatchers.IO) { buildPdfProfileReport(file) }
                    } catch (error: Exception) {
                        call.respondApiError(HttpStatusCode.UnprocessableEntity, "PDF_PROFILE_FAILED", "PDF_PROFILE", "پروفایل PDF تولید نشد.", error.message ?: error::class.simpleName ?: "خطای نامشخص", id)
                        return@get
                    }
                    call.respond(report)
                }
                get("/exams/{id}/pdf/extraction-strategy") {
                    if (!call.requireAdmin()) return@get
                    val id = call.parameters["id"]!!.toLong()
                    val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                    if (path.isNullOrBlank()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_NOT_REGISTERED", "PDF", "برای این آزمون فایل PDF ثبت نشده است.", examId = id)
                        return@get
                    }
                    val file = File(path)
                    if (!file.exists()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_FILE_MISSING", "PDF", "فایل PDF روی سرور پیدا نشد.", "مسیر ثبت‌شده: ${file.absolutePath}", id)
                        return@get
                    }
                    val strategy = try {
                        withContext(Dispatchers.IO) { choosePdfExtractionStrategy(file) }
                    } catch (error: Exception) {
                        call.respondApiError(HttpStatusCode.UnprocessableEntity, "PDF_STRATEGY_FAILED", "PDF_STRATEGY", "استراتژی استخراج تعیین نشد.", error.message ?: error::class.simpleName ?: "خطای نامشخص", id)
                        return@get
                    }
                    call.respond(strategy)
                }
                get("/exams/{id}/pdf/ocr-fallback-readiness") {
                    if (!call.requireAdmin()) return@get
                    val id = call.parameters["id"]!!.toLong()
                    val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                    if (path.isNullOrBlank()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_NOT_REGISTERED", "PDF", "برای این آزمون فایل PDF ثبت نشده است.", examId = id)
                        return@get
                    }
                    val file = File(path)
                    if (!file.exists()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_FILE_MISSING", "PDF", "فایل PDF روی سرور پیدا نشد.", "مسیر ثبت‌شده: ${file.absolutePath}", id)
                        return@get
                    }
                    val readiness = try {
                        withContext(Dispatchers.IO) { assessOcrFallbackReadiness(file) }
                    } catch (error: Exception) {
                        call.respondApiError(HttpStatusCode.UnprocessableEntity, "OCR_READINESS_FAILED", "PDF_OCR", "آمادگی مسیر OCR بررسی نشد.", error.message ?: error::class.simpleName ?: "خطای نامشخص", id)
                        return@get
                    }
                    call.respond(readiness)
                }
                get("/exams/{id}/pdf/extraction-summary") {
                    if (!call.requireAdmin()) return@get
                    val id = call.parameters["id"]!!.toLong()
                    val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                    if (path.isNullOrBlank()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_NOT_REGISTERED", "PDF", "برای این آزمون فایل PDF ثبت نشده است.", examId = id)
                        return@get
                    }
                    val file = File(path)
                    if (!file.exists()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_FILE_MISSING", "PDF", "فایل PDF روی سرور پیدا نشد.", "مسیر ثبت‌شده: ${file.absolutePath}", id)
                        return@get
                    }
                    val extraction = try {
                        extractPdfSummary(file)
                    } catch (error: Exception) {
                        call.respond(HttpStatusCode.UnprocessableEntity, "استخراج PDF ناموفق بود: ${error.message ?: "خطای نامشخص"}")
                        return@get
                    }
                    call.respond(extraction)
                }
                get("/exams/{id}/pdf/layout-order-audit") {
                    if (!call.requireAdmin()) return@get
                    val id = call.parameters["id"]!!.toLong()
                    val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                    if (path.isNullOrBlank()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_NOT_REGISTERED", "PDF", "برای این آزمون فایل PDF ثبت نشده است.", examId = id)
                        return@get
                    }
                    val file = File(path)
                    if (!file.exists()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_FILE_MISSING", "PDF", "فایل PDF روی سرور پیدا نشد.", "مسیر ثبت‌شده: ${file.absolutePath}", id)
                        return@get
                    }
                    val report = try {
                        withContext(Dispatchers.IO) { buildPdfLayoutOrderAudit(file) }
                    } catch (error: Exception) {
                        call.respondApiError(HttpStatusCode.UnprocessableEntity, "PDF_LAYOUT_ORDER_AUDIT_FAILED", "LAYOUT_ORDER_AUDIT", "ممیزی ترتیب خواندن PDF تولید نشد.", error.message ?: error::class.simpleName ?: "خطای نامشخص", id)
                        return@get
                    }
                    call.respond(report)
                }
                get("/exams/{id}/pdf/question-reconstruction") {
                    if (!call.requireAdmin()) return@get
                    val id = call.parameters["id"]!!.toLong()
                    val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                    if (path.isNullOrBlank()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_NOT_REGISTERED", "PDF", "برای این آزمون فایل PDF ثبت نشده است.", examId = id)
                        return@get
                    }
                    val file = File(path)
                    if (!file.exists()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_FILE_MISSING", "PDF", "فایل PDF روی سرور پیدا نشد.", "مسیر ثبت‌شده: ${file.absolutePath}", id)
                        return@get
                    }
                    val report = try {
                        withContext(Dispatchers.IO) { buildPdfQuestionReconstructionReport(file) }
                    } catch (error: Exception) {
                        call.respondApiError(HttpStatusCode.UnprocessableEntity, "PDF_RECONSTRUCTION_FAILED", "QUESTION_RECONSTRUCTION", "بازسازی سؤال‌های PDF ناموفق بود.", error.message ?: error::class.simpleName ?: "خطای نامشخص", id)
                        return@get
                    }
                    call.respond(report)
                }
                get("/exams/{id}/pdf/question-extraction") {
                    if (!call.requireAdmin()) return@get
                    val id = call.parameters["id"]!!.toLong()
                    val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                    if (path.isNullOrBlank()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_NOT_REGISTERED", "PDF", "برای این آزمون فایل PDF ثبت نشده است.", examId = id)
                        return@get
                    }
                    val file = File(path)
                    if (!file.exists()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_FILE_MISSING", "PDF", "فایل PDF روی سرور پیدا نشد.", "مسیر ثبت‌شده: ${file.absolutePath}", id)
                        return@get
                    }
                    val extraction = try {
                        withContext(Dispatchers.IO) { extractPdfQuestions(file) }
                    } catch (error: Exception) {
                        call.respondApiError(HttpStatusCode.UnprocessableEntity, "PDF_QUESTION_EXTRACTION_FAILED", "QUESTION_EXTRACTION", "استخراج تشخیصی سؤال‌ها ناموفق بود.", error.message ?: error::class.simpleName ?: "خطای نامشخص", id)
                        return@get
                    }
                    call.respond(extraction)
                }
                get("/exams/{id}/pdf/layout-trace") {
                    if (!call.requireAdmin()) return@get
                    val id = call.parameters["id"]!!.toLong()
                    val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                    if (path.isNullOrBlank()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_NOT_REGISTERED", "PDF", "برای این آزمون فایل PDF ثبت نشده است.", examId = id)
                        return@get
                    }
                    val file = File(path)
                    if (!file.exists()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_FILE_MISSING", "PDF", "فایل PDF روی سرور پیدا نشد.", "مسیر ثبت‌شده: ${file.absolutePath}", id)
                        return@get
                    }
                    val report = try {
                        withContext(Dispatchers.IO) { buildPdfLayoutTraceReport(file) }
                    } catch (error: Exception) {
                        call.respondApiError(HttpStatusCode.UnprocessableEntity, "PDF_LAYOUT_TRACE_FAILED", "LAYOUT_TRACE", "گزارش خطوط و ستون‌های PDF تولید نشد.", error.message ?: error::class.simpleName ?: "خطای نامشخص", id)
                        return@get
                    }
                    call.respond(report)
                }
                get("/exams/{id}/pdf/diagnostic-report") {
                    if (!call.requireAdmin()) return@get
                    val id = call.parameters["id"]!!.toLong()
                    val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                    if (path.isNullOrBlank()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_NOT_REGISTERED", "PDF", "برای این آزمون فایل PDF ثبت نشده است.", examId = id)
                        return@get
                    }
                    val file = File(path)
                    if (!file.exists()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_FILE_MISSING", "PDF", "فایل PDF روی سرور پیدا نشد.", "مسیر ثبت‌شده: ${file.absolutePath}", id)
                        return@get
                    }
                    val report = try {
                        withContext(Dispatchers.IO) { extractPdfQuestions(file) }
                    } catch (error: Exception) {
                        call.respondApiError(
                            HttpStatusCode.UnprocessableEntity,
                            "PDF_DIAGNOSTIC_FAILED",
                            "DIAGNOSTIC",
                            "گزارش تشخیصی PDF تولید نشد.",
                            error.message ?: error::class.simpleName ?: "خطای نامشخص",
                            id
                        )
                        return@get
                    }
                    call.respond(report)
                }
                get("/exams/{id}/pdf/extracted-questions") {
                    if (!call.requireAdmin()) return@get
                    val id = call.parameters["id"]!!.toLong()
                    val path = transaction { Exams.selectAll().where { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                    if (path.isNullOrBlank()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_NOT_REGISTERED", "PDF", "برای این آزمون فایل PDF ثبت نشده است.", examId = id)
                        return@get
                    }
                    val file = File(path)
                    if (!file.exists()) {
                        call.respondApiError(HttpStatusCode.NotFound, "PDF_FILE_MISSING", "PDF", "فایل PDF روی سرور پیدا نشد.", "مسیر ثبت‌شده: ${file.absolutePath}", id)
                        return@get
                    }
                    val extraction = try {
                        withContext(Dispatchers.IO) { extractPdfQuestions(file) }
                    } catch (error: Exception) {
                        call.application.environment.log.error("PDF question extraction failed for exam $id; path=${file.absolutePath}", error)
                        call.respondApiError(
                            HttpStatusCode.UnprocessableEntity,
                            "PDF_EXTRACTION_FAILED",
                            "EXTRACTION",
                            "استخراج سؤال‌ها از PDF ناموفق بود.",
                            error.message ?: error::class.simpleName ?: "خطای نامشخص",
                            id
                        )
                        return@get
                    }
                    call.respond(extraction)
                }
                post("/exams/{id}/pdf") {
                    if (!call.requireAdmin()) return@post
                    val id = call.parameters["id"]!!.toLong()
                    val receivedType = call.request.contentType()?.toString() ?: "none"
                    val root = File(System.getenv("STORAGE_DIR") ?: "./storage")
                    val target = File(root, "exams/$id.pdf")
                    target.parentFile.mkdirs()
                    withContext(Dispatchers.IO) {
                        call.receiveChannel().toInputStream().use { input ->
                            target.outputStream().use { output -> input.copyTo(output) }
                        }
                    }
                    val size = target.length()
                    val magic = target.inputStream().use { it.readNBytes(5) }
                    if (!magic.contentEquals(byteArrayOf(0x25, 0x50, 0x44, 0x46, 0x2D))) {
                        target.delete()
                        call.respond(HttpStatusCode.BadRequest, "Invalid PDF: size=$size contentType=$receivedType header=${magic.joinToString()}")
                        return@post
                    }
                    val extraction = try {
                        withContext(Dispatchers.IO) { extractPdfSummary(target) }
                    } catch (error: Exception) {
                        call.respond(HttpStatusCode.UnprocessableEntity, "استخراج PDF ناموفق بود: ${error.message ?: "خطای نامشخص"}")
                        return@post
                    }
                    withContext(Dispatchers.IO) {
                        transaction {
                            Exams.update({ Exams.id eq id }) {
                                it[pdfUrl] = target.absolutePath
                                it[updatedAt] = Instant.now()
                            }
                        }
                    }
                    call.respond(PdfUploadResponse(ok = true, extraction = extraction))
                }
            }
        }
    }
}
