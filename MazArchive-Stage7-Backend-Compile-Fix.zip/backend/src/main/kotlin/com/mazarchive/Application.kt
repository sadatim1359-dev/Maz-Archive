package com.mazarchive

import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.*
import io.ktor.server.auth.*
import io.ktor.server.auth.jwt.*
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.http.content.staticResources
import io.ktor.serialization.kotlinx.json.json
import io.ktor.utils.io.jvm.javaio.toInputStream
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.javatime.*
import java.io.File
import java.time.Instant
import java.util.Base64
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object Exams : Table("exams") {
    val id = long("id").autoIncrement()
    val title = text("title")
    val grade = text("grade")
    val field = text("field")
    val examNumber = integer("exam_number").nullable()
    val examDate = date("exam_date")
    val year = integer("year")
    val period = text("period")
    val month = text("month")
    val description = text("description").default("")
    val pdfUrl = text("pdf_url")
    val durationSeconds = integer("duration_seconds").default(1800)
    val createdAt = timestamp("created_at")
    val updatedAt = timestamp("updated_at")
    override val primaryKey = PrimaryKey(id)
}

object Questions : Table("questions") {
    val id = long("id").autoIncrement()
    val examId = long("exam_id").references(Exams.id, onDelete = ReferenceOption.CASCADE)
    val number = integer("number")
    val text = text("question_text")
    val options = text("options_json")
    val correctIndex = integer("correct_index")
    val createdAt = timestamp("created_at")
    val updatedAt = timestamp("updated_at")
    override val primaryKey = PrimaryKey(id)
}

object Annotations : Table("annotations") {
    val id = uuid("id")
    val userId = uuid("user_id")
    val examId = long("exam_id")
    val pageNumber = integer("page_number")
    val type = text("type")
    val content = text("content").nullable()
    val position = text("position")
    val color = text("color")
    val thickness = float("thickness")
    val createdAt = timestamp("created_at")
    val updatedAt = timestamp("updated_at")
    override val primaryKey = PrimaryKey(id)
}

@Serializable data class ExamDto(
    val id: Long, val title: String, val grade: String, val field: String,
    val examNumber: Int? = null, val examDate: String, val year: Int,
    val period: String, val month: String, val description: String = "",
    val pdfUrl: String, val durationSeconds: Int = 1800
)

@Serializable data class QuestionDto(
    val id: Long = 0, val examId: Long, val number: Int, val text: String,
    val options: List<String>, val correctIndex: Int, val imageUrl: String? = null,
    val createdAt: String = "", val updatedAt: String = ""
)

@Serializable data class AnnotationDto(
    val id: String, val user_id: String, val exam_id: Long, val page_number: Int,
    val type: String, val content: String? = null, val position: String,
    val color: String, val thickness: Float, val created_at: String = "",
    val updated_at: String = ""
)

@Serializable data class Login(val username: String, val password: String)
@Serializable data class Token(val token: String, val role: String)

private val jsonCodec = Json { ignoreUnknownKeys = true }

fun questionDto(row: ResultRow) = QuestionDto(
    id = row[Questions.id], examId = row[Questions.examId], number = row[Questions.number],
    text = row[Questions.text], options = jsonCodec.decodeFromString(row[Questions.options]),
    correctIndex = row[Questions.correctIndex], createdAt = row[Questions.createdAt].toString(),
    updatedAt = row[Questions.updatedAt].toString()
)

fun examDto(row: ResultRow) = ExamDto(
    id = row[Exams.id], title = row[Exams.title], grade = row[Exams.grade], field = row[Exams.field],
    examNumber = row[Exams.examNumber], examDate = row[Exams.examDate].toString(), year = row[Exams.year],
    period = row[Exams.period], month = row[Exams.month], description = row[Exams.description],
    pdfUrl = row[Exams.pdfUrl], durationSeconds = row[Exams.durationSeconds]
)

fun annotationDto(row: ResultRow) = AnnotationDto(
    id = row[Annotations.id].toString(), user_id = row[Annotations.userId].toString(),
    exam_id = row[Annotations.examId], page_number = row[Annotations.pageNumber], type = row[Annotations.type],
    content = row[Annotations.content], position = row[Annotations.position], color = row[Annotations.color],
    thickness = row[Annotations.thickness], created_at = row[Annotations.createdAt].toString(),
    updated_at = row[Annotations.updatedAt].toString()
)

object DevRefreshTokens : MutableMap<String, Pair<String, String>> by java.util.concurrent.ConcurrentHashMap()

object JwtAuth {
    private val secret = System.getenv("JWT_SECRET") ?: "CHANGE_ME"
    fun token(subject: String, role: String): String {
        val header = Base64.getUrlEncoder().withoutPadding().encodeToString("""{"alg":"HS256","typ":"JWT"}""".toByteArray())
        val payload = Base64.getUrlEncoder().withoutPadding().encodeToString("""{"sub":"$subject","role":"$role"}""".toByteArray())
        val data = "$header.$payload"
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(), "HmacSHA256"))
        val signature = Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(data.toByteArray()))
        return "$data.$signature"
    }
    val verifier = JWT.require(Algorithm.HMAC256(secret)).build()
}

fun main() {
    embeddedServer(Netty, port = System.getenv("PORT")?.toInt() ?: 8080, host = "0.0.0.0") {
        module()
    }.start(wait = true)
}

fun Application.module() {
    Database.connect(
        System.getenv("DATABASE_URL") ?: "jdbc:postgresql://localhost:5432/mazarchive",
        driver = "org.postgresql.Driver",
        user = System.getenv("DB_USER") ?: "postgres",
        password = System.getenv("DB_PASSWORD") ?: "postgres"
    )
    transaction {
        SchemaUtils.create(Exams, Questions, Annotations)
        exec("ALTER TABLE exams ADD COLUMN IF NOT EXISTS description TEXT NOT NULL DEFAULT ''")
        exec("ALTER TABLE exams ADD COLUMN IF NOT EXISTS duration_seconds INTEGER NOT NULL DEFAULT 1800")
    }
    install(ContentNegotiation) { json() }
    install(Authentication) {
        jwt("auth") {
            verifier(JwtAuth.verifier)
            validate { principal -> if (principal.payload.subject != null) JWTPrincipal(principal.payload) else null }
        }
    }
    routing {
        staticResources("/admin", "web")
        get("/health") { call.respond(mapOf("status" to "ok")) }

        post("/auth/login") {
            val body = call.receive<Login>()
            val isAdmin = body.username == "admin" && body.password == (System.getenv("ADMIN_PASSWORD") ?: "change-me")
            if (!isAdmin) {
                call.respond(HttpStatusCode.Unauthorized, "نام کاربری یا رمز عبور نامعتبر است")
                return@post
            }
            val role = "ADMIN"
            val refresh = UUID.randomUUID().toString()
            DevRefreshTokens[refresh] = body.username to role
            call.respond(mapOf("token" to JwtAuth.token(body.username, role), "role" to role, "refreshToken" to refresh))
        }

        post("/auth/refresh") {
            val body = call.receive<Map<String, String>>()
            val refresh = body["refreshToken"]
            if (refresh == null) {
                call.respond(HttpStatusCode.BadRequest)
                return@post
            }
            val entry = DevRefreshTokens[refresh]
            if (entry == null) {
                call.respond(HttpStatusCode.Unauthorized)
                return@post
            }
            call.respond(Token(JwtAuth.token(entry.first, entry.second), entry.second))
        }

        authenticate("auth") {
            get("/exams") {
                val grade = call.request.queryParameters["grade"]
                val field = call.request.queryParameters["field"]
                val year = call.request.queryParameters["year"]?.toIntOrNull()
                val period = call.request.queryParameters["period"]
                val month = call.request.queryParameters["month"]
                val query = call.request.queryParameters["q"]?.trim()
                val conditions = listOfNotNull(
                    grade?.let { Exams.grade eq it }, field?.let { Exams.field eq it },
                    year?.let { Exams.year eq it }, period?.let { Exams.period eq it },
                    month?.let { Exams.month eq it }, query?.takeIf { it.isNotEmpty() }?.let { Exams.title like "%$it%" }
                )
                val rows = transaction {
                    if (conditions.isEmpty()) {
                        Exams.selectAll().orderBy(Exams.examDate, SortOrder.DESC).map(::examDto)
                    } else {
                        val predicate = conditions.drop(1).fold(conditions.first()) { acc, condition ->
                            Op.build { acc and condition }
                        }
                        Exams.selectAll().where { predicate }.orderBy(Exams.examDate, SortOrder.DESC).map(::examDto)
                    }
                }
                call.respond(rows)
            }

            get("/exams/{id}") {
                val id = call.parameters["id"]!!.toLong()
                val row = transaction { Exams.select { Exams.id eq id }.singleOrNull() }
                if (row == null) call.respond(HttpStatusCode.NotFound) else call.respond(examDto(row))
            }

            get("/exams/{id}/questions") {
                val id = call.parameters["id"]!!.toLong()
                val rows = transaction { Questions.select { Questions.examId eq id }.orderBy(Questions.number).map(::questionDto) }
                call.respond(rows)
            }

            get("/exams/{id}/pdf") {
                val id = call.parameters["id"]!!.toLong()
                val path = transaction { Exams.select { Exams.id eq id }.singleOrNull()?.get(Exams.pdfUrl) }
                if (path == null) { call.respond(HttpStatusCode.NotFound); return@get }
                val root = File(System.getenv("STORAGE_DIR") ?: "./storage")
                val file = File(path)
                if (!file.canonicalPath.startsWith(root.canonicalPath)) { call.respond(HttpStatusCode.Forbidden); return@get }
                if (!file.exists()) { call.respond(HttpStatusCode.NotFound); return@get }
                call.respondFile(file)
            }

            get("/exams/{id}/annotations") {
                val id = call.parameters["id"]!!.toLong()
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                val rows = transaction { Annotations.select { (Annotations.examId eq id) and (Annotations.userId eq uid) }.map(::annotationDto) }
                call.respond(rows)
            }

            post("/exams/{id}/annotations") {
                val id = call.parameters["id"]!!.toLong()
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                val annotation = call.receive<AnnotationDto>()
                val annotationId = UUID.fromString(annotation.id)
                transaction {
                    Annotations.insert {
                        it[Annotations.id] = annotationId; it[userId] = uid; it[examId] = id
                        it[pageNumber] = annotation.page_number; it[type] = annotation.type; it[content] = annotation.content
                        it[position] = annotation.position; it[color] = annotation.color; it[thickness] = annotation.thickness
                        it[createdAt] = Instant.now(); it[updatedAt] = Instant.now()
                    }
                }
                call.respond(annotation.copy(user_id = uid.toString()), HttpStatusCode.Created)
            }

            put("/annotations/{id}") {
                val annotationId = UUID.fromString(call.parameters["id"]!!)
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                val annotation = call.receive<AnnotationDto>()
                transaction {
                    Annotations.update({ (Annotations.id eq annotationId) and (Annotations.userId eq uid) }) {
                        it[position] = annotation.position; it[color] = annotation.color; it[thickness] = annotation.thickness
                        it[content] = annotation.content; it[updatedAt] = Instant.now()
                    }
                }
                call.respond(annotation)
            }

            delete("/annotations/{id}") {
                val annotationId = UUID.fromString(call.parameters["id"]!!)
                val uid = UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject)
                transaction { Annotations.deleteWhere { (Annotations.id eq annotationId) and (Annotations.userId eq uid) } }
                call.respond(HttpStatusCode.NoContent)
            }

            route("/admin") {
                suspend fun ApplicationCall.requireAdmin(): Boolean {
                    val isAdmin = principal<JWTPrincipal>()?.payload?.getClaim("role")?.asString() == "ADMIN"
                    if (!isAdmin) respond(HttpStatusCode.Forbidden, "دسترسی مدیر لازم است")
                    return isAdmin
                }

                get("/exams") {
                    if (!call.requireAdmin()) return@get
                    val rows = transaction { Exams.selectAll().orderBy(Exams.examDate, SortOrder.DESC).map(::examDto) }
                    call.respond(rows)
                }
                get("/stats") {
                    if (!call.requireAdmin()) return@get
                    val rows = transaction { Exams.selectAll().toList() }
                    call.respond(mapOf("total" to rows.size, "withPdf" to rows.count { it[Exams.pdfUrl].isNotBlank() }, "withoutPdf" to rows.count { it[Exams.pdfUrl].isBlank() }))
                }
                post("/exams") {
                    if (!call.requireAdmin()) return@post
                    val exam = call.receive<ExamDto>()
                    val newId = transaction {
                        Exams.insert {
                            it[title] = exam.title; it[grade] = exam.grade; it[field] = exam.field; it[examNumber] = exam.examNumber
                            it[examDate] = java.time.LocalDate.parse(exam.examDate); it[year] = exam.year; it[period] = exam.period
                            it[month] = exam.month; it[description] = exam.description; it[pdfUrl] = exam.pdfUrl
                            it[durationSeconds] = exam.durationSeconds; it[createdAt] = Instant.now(); it[updatedAt] = Instant.now()
                        } get Exams.id
                    }
                    call.respond(exam.copy(id = newId), HttpStatusCode.Created)
                }
                put("/exams/{id}") {
                    if (!call.requireAdmin()) return@put
                    val id = call.parameters["id"]!!.toLong(); val exam = call.receive<ExamDto>()
                    transaction {
                        Exams.update({ Exams.id eq id }) {
                            it[title] = exam.title; it[grade] = exam.grade; it[field] = exam.field; it[examNumber] = exam.examNumber
                            it[examDate] = java.time.LocalDate.parse(exam.examDate); it[year] = exam.year; it[period] = exam.period
                            it[month] = exam.month; it[description] = exam.description; it[durationSeconds] = exam.durationSeconds
                            it[updatedAt] = Instant.now()
                        }
                    }
                    call.respond(exam)
                }
                delete("/exams/{id}") {
                    if (!call.requireAdmin()) return@delete
                    transaction { Exams.deleteWhere { Exams.id eq call.parameters["id"]!!.toLong() } }
                    call.respond(HttpStatusCode.NoContent)
                }
                get("/exams/{id}/questions") {
                    if (!call.requireAdmin()) return@get
                    val examId = call.parameters["id"]!!.toLong()
                    val rows = transaction { Questions.select { Questions.examId eq examId }.orderBy(Questions.number).map(::questionDto) }
                    call.respond(rows)
                }
                post("/exams/{id}/questions") {
                    if (!call.requireAdmin()) return@post
                    val examId = call.parameters["id"]!!.toLong(); val question = call.receive<QuestionDto>()
                    if (question.options.size < 2 || question.correctIndex !in question.options.indices) {
                        call.respond(HttpStatusCode.BadRequest, "گزینه‌ها یا پاسخ صحیح نامعتبر است"); return@post
                    }
                    val newId = transaction {
                        Questions.insert {
                            it[Questions.examId] = examId; it[number] = question.number; it[text] = question.text
                            it[options] = jsonCodec.encodeToString(question.options); it[correctIndex] = question.correctIndex
                            it[createdAt] = Instant.now(); it[updatedAt] = Instant.now()
                        } get Questions.id
                    }
                    call.respond(question.copy(id = newId, examId = examId), HttpStatusCode.Created)
                }
                put("/exams/{examId}/questions/{id}") {
                    if (!call.requireAdmin()) return@put
                    val examId = call.parameters["examId"]!!.toLong(); val id = call.parameters["id"]!!.toLong(); val question = call.receive<QuestionDto>()
                    if (question.options.size < 2 || question.correctIndex !in question.options.indices) {
                        call.respond(HttpStatusCode.BadRequest, "گزینه‌ها یا پاسخ صحیح نامعتبر است"); return@put
                    }
                    transaction {
                        Questions.update({ (Questions.id eq id) and (Questions.examId eq examId) }) {
                            it[number] = question.number; it[text] = question.text; it[options] = jsonCodec.encodeToString(question.options)
                            it[correctIndex] = question.correctIndex; it[updatedAt] = Instant.now()
                        }
                    }
                    call.respond(question.copy(id = id, examId = examId))
                }
                delete("/exams/{examId}/questions/{id}") {
                    if (!call.requireAdmin()) return@delete
                    val examId = call.parameters["examId"]!!.toLong(); val id = call.parameters["id"]!!.toLong()
                    transaction { Questions.deleteWhere { (Questions.id eq id) and (Questions.examId eq examId) } }
                    call.respond(HttpStatusCode.NoContent)
                }
                post("/exams/{id}/pdf") {
                    if (!call.requireAdmin()) return@post
                    val id = call.parameters["id"]!!.toLong()
                    if (call.request.contentType() != ContentType.Application.Pdf) { call.respond(HttpStatusCode.UnsupportedMediaType); return@post }
                    val root = File(System.getenv("STORAGE_DIR") ?: "./storage")
                    val target = File(root, "exams/$id.pdf")
                    target.parentFile.mkdirs()
                    call.receiveChannel().toInputStream().use { input -> target.outputStream().use { output -> input.copyTo(output) } }
                    val magic = target.inputStream().use { it.readNBytes(5) }
                    if (!magic.contentEquals(byteArrayOf(0x25, 0x50, 0x44, 0x46, 0x2D))) {
                        target.delete(); call.respond(HttpStatusCode.BadRequest, "Invalid PDF"); return@post
                    }
                    transaction { Exams.update({ Exams.id eq id }) { it[pdfUrl] = target.absolutePath; it[updatedAt] = Instant.now() } }
                    call.respond(mapOf("ok" to true))
                }
            }
        }
    }
}
