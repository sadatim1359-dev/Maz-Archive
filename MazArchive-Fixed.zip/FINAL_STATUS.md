# MazArchive — consolidated final source status

Implemented in the source tree:
- Android Kotlin + Jetpack Compose + Material 3, RTL dark UI
- Grade/field archive flow, archive-scoped search and filters
- Exam detail and in-app PDF rendering foundation
- Pinch zoom and annotation canvas foundation
- Pen/highlighter/eraser, colors, thickness, undo/redo state
- Normalized per-page annotation model
- Room local annotation cache and repository
- Retrofit API client and token interceptor
- Authentication/session abstractions and refresh-token contract
- Ktor backend, PostgreSQL/Exposed persistence
- User-scoped annotation authorization
- Admin exam CRUD and PDF upload validation
- Private filesystem PDF storage outside PostgreSQL
- Admin HTML console
- Deployment/release documentation

Final environment-dependent steps:
- Run Gradle/Android SDK compilation
- Instrumented tests on emulator/device
- Deploy PostgreSQL and private S3/MinIO storage
- Configure production secrets and HTTPS
- Configure production identity/token rotation
- Perform end-to-end acceptance tests
- Sign and publish APK/AAB

No copyrighted Maz exam PDFs are bundled.
