package com.mazarchive.app.network
import kotlinx.serialization.Serializable
import retrofit2.http.Body
import retrofit2.http.POST

@Serializable data class LoginRequest(val username:String,val password:String)
@Serializable data class TokenResponse(val token:String,val role:String,val refreshToken:String?=null)
@Serializable data class RefreshRequest(val refreshToken:String)
interface AuthApi {
 @POST("auth/login") suspend fun login(@Body request:LoginRequest):TokenResponse
 @POST("auth/refresh") suspend fun refresh(@Body request:RefreshRequest):TokenResponse
}
