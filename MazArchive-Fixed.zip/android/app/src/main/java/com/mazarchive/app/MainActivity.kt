package com.mazarchive.app

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import kotlinx.serialization.Serializable
import androidx.compose.ui.text.input.PasswordVisualTransformation
import java.net.URLDecoder
import java.net.URLEncoder

@Serializable data class Exam(val id:Long,val title:String,val grade:String,val field:String,val examNumber:Int?=null,val examDate:String,val year:Int,val period:String,val month:String,val pdfUrl:String)
@Serializable data class AnnotationPayload(val id:String,val user_id:String,val exam_id:Long,val page_number:Int,val type:String,val content:String?=null,val position:String,val color:String,val thickness:Float,val created_at:String="",val updated_at:String="")

enum class PenTool { PEN,HIGHLIGHTER,ERASER }
data class Stroke(val id:String=java.util.UUID.randomUUID().toString(),val page:Int,val points:List<androidx.compose.ui.geometry.Offset>,val color:Color,val width:Float,val alpha:Float,val tool:PenTool)

private val Indigo=Color(0xFF7167E8); private val Bg=Color(0xFF0B0B0F); private val Card=Color(0xFF15151C)

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{MazTheme{App()}}}
}
@Composable fun MazTheme(content:@Composable()->Unit)=MaterialTheme(colorScheme=darkColorScheme(primary=Indigo,background=Bg,surface=Card),content=content)

@Composable fun App(){
 val nav=rememberNavController()
 var loggedIn by rememberSaveable { mutableStateOf(false) }
 if(!loggedIn){ LoginScreen{ loggedIn=true }; return }
 NavHost(nav,"home"){
  composable("home"){Home{nav.navigate("fields/${URLEncoder.encode(it,"UTF-8")}")}}
  composable("fields/{g}"){b->val g=URLDecoder.decode(b.arguments?.getString("g")!!,"UTF-8");Fields(g){f->nav.navigate("archive/${URLEncoder.encode(g,"UTF-8")}/${URLEncoder.encode(f,"UTF-8")}")}}
  composable("archive/{g}/{f}"){b->Archive(URLDecoder.decode(b.arguments?.getString("g")!!,"UTF-8"),URLDecoder.decode(b.arguments?.getString("f")!!,"UTF-8")){id->nav.navigate("exam/$id")}}
  composable("exam/{id}"){b->ExamDetail(b.arguments?.getString("id")!!.toLong()){url->nav.navigate("pdf/${URLEncoder.encode(url,"UTF-8")}")}}
  composable("pdf/{url}"){b->PdfScreen(URLDecoder.decode(b.arguments?.getString("url")!!,"UTF-8")){nav.popBackStack()}}
 }
}

@Composable fun LoginScreen(onLogin:()->Unit){
 var user by remember{mutableStateOf("")}; var pass by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().background(Bg).padding(24.dp),verticalArrangement=Arrangement.spacedBy(14.dp),horizontalAlignment=Alignment.CenterHorizontally){
  Spacer(Modifier.height(50.dp));Text("MazArchive",style=MaterialTheme.typography.headlineLarge);Text("ورود به آرشیو",color=Color.Gray)
  OutlinedTextField(user,{user=it},Modifier.fillMaxWidth(),label={Text("نام کاربری")})
  OutlinedTextField(pass,{pass=it},Modifier.fillMaxWidth(),label={Text("رمز عبور")},visualTransformation=PasswordVisualTransformation())
  Button({onLogin()},Modifier.fillMaxWidth(),enabled=user.isNotBlank()&&pass.isNotBlank()){Text("ورود")}
 }
}
@Composable fun Home(onGrade:(String)->Unit){
 Column(Modifier.fillMaxSize().background(Bg).padding(20.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){
  Text("MazArchive",style=MaterialTheme.typography.headlineMedium);Text("آرشیو ماز",color=Color.LightGray)
  Text("جدیدترین آزمون‌های ماز",style=MaterialTheme.typography.titleLarge)
  Card(Modifier.fillMaxWidth().height(175.dp),colors=CardDefaults.cardColors(containerColor=Card)){Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){Text("آزمون مرحله دوم");Text("یازدهم ریاضی");Text("شیمی");Text("۱۵ آبان ۱۴۰۴",color=Indigo);Text("مشاهده آزمون ›",color=Indigo)}}
  Text("انتخاب پایه",style=MaterialTheme.typography.titleMedium)
  listOf("دهم","یازدهم","دوازدهم").forEach{TextButton({onGrade(it)},Modifier.fillMaxWidth()){Text(it,Modifier.fillMaxWidth())}}
 }
}
@Composable fun Fields(grade:String,onField:(String)->Unit){
 Column(Modifier.fillMaxSize().background(Bg).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("رشته $grade",style=MaterialTheme.typography.headlineSmall);listOf("ریاضی","تجربی","انسانی").forEach{Button({onField(it)},Modifier.fillMaxWidth()){Text(it)}}}
}
@Composable fun Archive(grade:String,field:String,open:(Long)->Unit){
 var q by remember{mutableStateOf("")}; var year by remember{mutableStateOf<Int?>(null)};var period by remember{mutableStateOf<String?>(null)};var month by remember{mutableStateOf<String?>(null)};var showFilter by remember{mutableStateOf(false)}
 val data=remember(grade,field,q,year,period,month){(1..18).map{n->Exam(n.toLong(),"آزمون شماره $n",grade,field,n,"۱۴۰۴/۰۸/${(25-n).coerceAtLeast(1)}",1404,"شروع از مهر","آبان","")}.filter{q.isBlank()||it.title.contains(q)||it.examDate.contains(q)}.filter{year==null||it.year==year}}
 Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){Text("آزمون‌های $grade $field",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.weight(1f));IconButton({showFilter=!showFilter}){Text("☷")}}
  OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),placeholder={Text("مثلاً: آزمون ۲۳ آبان ۱۴۰۴",color=Color.Gray)})
  if(showFilter) FilterPanel(year,{year=it},period,{period=it},month,{month=it})
  Spacer(Modifier.height(10.dp))
  LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(data){e->Card(Modifier.fillMaxWidth().clickable{open(e.id)},colors=CardDefaults.cardColors(containerColor=Card)){Column(Modifier.padding(16.dp)){Text(e.title);Text(e.examDate,color=Color.Gray);Text("مشاهده آزمون ›",color=Indigo)}}}}
 }
}
@Composable fun FilterPanel(year:Int?,setYear:(Int?)->Unit,period:String?,setPeriod:(String?)->Unit,month:String?,setMonth:(String?)->Unit){
 Column(Modifier.fillMaxWidth().padding(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
  Text("Filter",style=MaterialTheme.typography.titleMedium);Text("Year")
  Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf(1404,1403,1402).forEach{FilterChip(year==it,{setYear(if(year==it)null else it)},{Text(it.toString())})}}
  Text("Period");Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("تابستانه","شروع از مهر").forEach{FilterChip(period==it,{setPeriod(if(period==it)null else it)},{Text(it)})}}
  Text("Month");val months=if(period=="تابستانه")listOf("تیر","مرداد","شهریور") else listOf("مهر","آبان","آذر","دی","بهمن","اسفند","فروردین","اردیبهشت","خرداد")
  Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)){months.forEach{FilterChip(month==it,{setMonth(if(month==it)null else it)},{Text(it)})}}
 }
}
@Composable fun ExamDetail(id:Long,open:(String)->Unit){
 Column(Modifier.fillMaxSize().background(Bg).padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){Text("آزمون شماره $id",style=MaterialTheme.typography.headlineSmall);Text("آزمون + پاسخنامه",color=Color.Gray);Button({open("${AppConfig.BASE_URL}exams/$id/pdf")},Modifier.fillMaxWidth()){Text("مشاهده فایل")}}
}

@Composable fun PdfScreen(url:String,onBack:()->Unit){
 var file by remember{mutableStateOf<java.io.File?>(null)}
 var tool by remember{mutableStateOf(PenTool.PEN)};var width by remember{mutableFloatStateOf(5f)};var color by remember{mutableStateOf(Color.Red)};var tools by remember{mutableStateOf(false)}
 var strokes by remember{mutableStateOf(listOf<Stroke>())};var redo by remember{mutableStateOf(listOf<Stroke>())}
 LaunchedEffect(url){file=runCatching{val f=java.io.File.createTempFile("maz-",".pdf");java.net.URL(url).openStream().use{a->f.outputStream().use{b->a.copyTo(b)}};f}.getOrNull()}
 Column(Modifier.fillMaxSize().background(Color.Black)){
  Row(Modifier.fillMaxWidth().height(48.dp).background(Color(0xFF101014)),verticalAlignment=Alignment.CenterVertically){
   TextButton({onBack()}){Text("←")};TextButton({tools=!tools}){Text("✏️")}
   TextButton({val x=strokes.last();strokes=strokes.dropLast(1);redo=redo+x},enabled=strokes.isNotEmpty()){Text("↶")}
   TextButton({val x=redo.last();redo=redo.dropLast(1);strokes=strokes+x},enabled=redo.isNotEmpty()){Text("↷")}
  }
  if(tools)Surface(color=Color(0xFF17171D)){Column(Modifier.padding(10.dp)){
   Row{listOf(PenTool.PEN to "قلم",PenTool.HIGHLIGHTER to "هایلایتر",PenTool.ERASER to "پاک‌کن").forEach{(t,l)->FilterChip(tool==t,{tool=t;tools=false},{Text(l)})}}
   Row{listOf(3f to "نازک",6f to "متوسط",12f to "ضخیم").forEach{(w,l)->FilterChip(width==w,{width=w},{Text(l)})}}
   Row{listOf(Color.Black to "مشکی",Color.Red to "قرمز",Color.Blue to "آبی",Color.Green to "سبز").forEach{(c,l)->FilterChip(color==c,{color=c},{Text(l)})}}
  }}
  file?.let{PdfCanvas(it,strokes,{strokes=strokes+it;redo=emptyList()},tool,width,color)}?:Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){CircularProgressIndicator()}
 }
}
@Composable fun PdfCanvas(file:java.io.File,strokes:List<Stroke>,add:(Stroke)->Unit,tool:PenTool,width:Float,color:Color){
 var scale by remember{mutableFloatStateOf(1f)};var offset by remember{mutableStateOf(androidx.compose.ui.geometry.Offset.Zero)}
 val renderer=remember(file){PdfRenderer(ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY))}
 DisposableEffect(renderer){onDispose{renderer.close()}}
 val pages=renderer.pageCount
 val bitmaps=remember(file){(0 until pages).map{renderer.openPage(it).let{p->Bitmap.createBitmap(p.width,p.height,Bitmap.Config.ARGB_8888).also{p.render(it,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);p.close()}}}}
 Box(Modifier.fillMaxSize().pointerInput(Unit){detectTransformGestures{_,pan,zoom,_->{scale=(scale*zoom).coerceIn(1f,4f);offset+=pan}}}){
  Column(Modifier.verticalScroll(rememberScrollState()).graphicsLayer(scaleX=scale,scaleY=scale,translationX=offset.x,translationY=offset.y)){
   bitmaps.forEachIndexed{page,bmp->Box(Modifier.fillMaxWidth().padding(8.dp)){
    Image(bmp.asImageBitmap(),null,Modifier.fillMaxWidth())
    Canvas(Modifier.matchParentSize().pointerInput(tool,width,color,page){var pts=mutableListOf<androidx.compose.ui.geometry.Offset>();awaitPointerEventScope{while(true){val e=awaitPointerEvent();if(e.changes.size==1&&e.changes[0].pressed){val c=e.changes[0];pts+=androidx.compose.ui.geometry.Offset((c.position.x/size.width).coerceIn(0f,1f),(c.position.y/size.height).coerceIn(0f,1f));c.consume()}else if(pts.isNotEmpty()){add(Stroke(page=page,points=pts.toList(),color=if(tool==PenTool.ERASER)Color.Transparent else color,width=width,alpha=if(tool==PenTool.HIGHLIGHTER).35f else 1f,tool=tool));pts=mutableListOf()}}}}}){strokes.filter{it.page==page&&it.points.size>1}.forEach{s->val path=Path();path.moveTo(s.points[0].x*size.width,s.points[0].y*size.height);s.points.drop(1).forEach{path.lineTo(it.x*size.width,it.y*size.height)};drawPath(path,s.color.copy(alpha=s.alpha),style=androidx.compose.ui.graphics.drawscope.Stroke(width=s.width))}}
   }}
  };Text("1 / $pages",Modifier.align(Alignment.CenterEnd).padding(6.dp),color=Color.White)
 }
}
