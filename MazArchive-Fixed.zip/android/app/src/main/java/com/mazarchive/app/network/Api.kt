package com.mazarchive.app.network

import com.mazarchive.app.Exam
import com.mazarchive.app.AnnotationPayload
import retrofit2.http.*
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import okhttp3.MediaType.Companion.toMediaType
import kotlinx.serialization.json.Json

interface MazApi {
    @GET("exams") suspend fun exams(
        @Query("grade") grade:String?=null, @Query("field") field:String?=null,
        @Query("year") year:Int?=null, @Query("period") period:String?=null,
        @Query("month") month:String?=null, @Query("q") q:String?=null
    ):List<Exam>
    @GET("exams/{id}") suspend fun exam(@Path("id") id:Long):Exam
    @GET("exams/{id}/annotations") suspend fun annotations(@Path("id") id:Long):List<AnnotationPayload>
    @POST("exams/{id}/annotations") suspend fun createAnnotation(@Path("id") id:Long,@Body a:AnnotationPayload):AnnotationPayload
    @PUT("annotations/{id}") suspend fun updateAnnotation(@Path("id") id:String,@Body a:AnnotationPayload):AnnotationPayload
    @DELETE("annotations/{id}") suspend fun deleteAnnotation(@Path("id") id:String)
}
object ApiFactory {
    fun create(baseUrl:String, tokenProvider:()->String? = { null }):MazApi {
        val client=OkHttpClient.Builder().addInterceptor(AuthInterceptor(tokenProvider)).build()
        return Retrofit.Builder().baseUrl(baseUrl)
            .client(client).addConverterFactory(Json{ignoreUnknownKeys=true}.asConverterFactory("application/json".toMediaType())).build()
            .create(MazApi::class.java)
    }
}
