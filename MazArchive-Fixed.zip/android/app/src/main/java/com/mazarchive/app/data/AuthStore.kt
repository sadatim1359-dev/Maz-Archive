package com.mazarchive.app.data

import android.content.Context
import androidx.core.content.edit

class AuthStore(context: Context) {
    private val prefs=context.getSharedPreferences("maz_auth",Context.MODE_PRIVATE)
    fun token():String?=prefs.getString("access_token",null)
    fun role():String?=prefs.getString("role",null)
    fun refreshToken():String?=prefs.getString("refresh_token",null)
    fun save(token:String,role:String,refreshToken:String?=null){prefs.edit{putString("access_token",token).putString("role",role).apply{if(refreshToken!=null)putString("refresh_token",refreshToken)}}}
    fun clear(){prefs.edit{clear()}}
    fun isLoggedIn()=!token().isNullOrBlank()
}
