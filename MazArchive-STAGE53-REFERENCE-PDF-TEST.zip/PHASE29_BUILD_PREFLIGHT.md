=== Phase 29 preflight ===
- Android Gradle wrapper: missing
- System Gradle: unavailable in current environment
- Duplicate admin.html copies detected; compared byte hashes:
563548fc0cdcebdd35c072a9e0847b901c6a4c95889736f7269581deccde2a56  backend/src/main/resources/web/admin.html
563548fc0cdcebdd35c072a9e0847b901c6a4c95889736f7269581deccde2a56  backend/admin.html
- API endpoint references found:
55:    @GET("admin/exams/{id}/pdf/extracted-questions") suspend fun extractedQuestions(@Path("id") id:Long):List<ExtractedQuestionDto>
56:    @GET("admin/exams") suspend fun adminExams():List<AdminExamPayload>
57:    @POST("admin/exams") suspend fun createAdminExam(@Body exam:AdminExamPayload):AdminExamPayload
58:    @PUT("admin/exams/{id}") suspend fun updateAdminExam(@Path("id") id:Long,@Body exam:AdminExamPayload):AdminExamPayload
61:    @DELETE("admin/exams/{id}") suspend fun deleteAdminExam(@Path("id") id:Long)
62:    @GET("admin/exams/{id}/questions") suspend fun adminQuestions(@Path("id") id:Long):List<QuestionDto>
63:    @POST("admin/exams/{id}/questions") suspend fun createAdminQuestion(@Path("id") id:Long,@Body question:QuestionDto):QuestionDto
64:    @PUT("admin/exams/{examId}/questions/{id}") suspend fun updateAdminQuestion(@Path("examId") examId:Long,@Path("id") id:Long,@Body question:QuestionDto):QuestionDto
65:    @DELETE("admin/exams/{examId}/questions/{id}") suspend fun deleteAdminQuestion(@Path("examId") examId:Long,@Path("id") id:Long)
- This is a static preflight only; no Gradle compilation or APK build was claimed.
