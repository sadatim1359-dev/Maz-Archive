# Phase 38 — Question-Only Extraction

- Added `tools/extract_questions_only.py`.
- Finds the first answer-booklet marker and scans only preceding pages.
- For the supplied PDF, marker page: 33; question range: pages 1–32.
- Test output: 115 candidates, 6 requiring review based on option-marker count.
- Correct answers are not extracted; `correct_index` remains `-1`.
- This is a parser test, not a verified production-quality extraction of every question.
