# Diagnostic Error Messages Fix

This version improves the extracted-question flow:

- Backend returns structured JSON errors with `code`, `stage`, `message`, `details`, and `examId`.
- Android displays the structured reason instead of only a generic failure message.
- Network errors distinguish DNS/host resolution and timeout failures.
- Empty extraction results show page count and extraction warnings, including whether usable text was found, answer-sheet detection, and parser counts.
- Backend logs the complete PDF extraction exception for Render diagnostics.

The APK must be rebuilt after replacing the project files. The backend must also be redeployed so the Android app receives the structured errors.
