# Phase 37 — Booklet-aware question extraction

Implemented a conservative page classifier using subject labels visible in the PDF (`ریاضی/حسابان/هندسه`, `فیزیک`, `شیمی`, `پیش‌خوانی`) plus question-like markers. Pages without a subject-labelled question header are not scanned as question pages.

The extractor keeps page and subject context, splits question candidates within each page, and never infers the correct answer (`correct_index = -1`).

This is a candidate extractor, not proof that every question is perfectly reconstructed. OCR/layout and formula fragments still require human review.
