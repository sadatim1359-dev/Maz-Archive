# Phase 36 — Marker-range question extraction

## Implemented

- The question extractor scans PDF pages individually.
- It finds the first page containing `دفترچه پاسخ` or `پاسخنامه` after normalization.
- Only pages before that marker are considered for question extraction.
- The page boundary is retained in the standalone validation tool.
- Correct answers remain `-1`; no answer key is inferred.

## Validation with the supplied PDF

- Total pages: **118**
- First answer-booklet marker: **page 33**
- Question scan end page: **32**
- Candidate question starts: **80**
- Candidate pages: **23**

The candidate count is not a claim that 80 complete questions were correctly extracted. Repeated numbering across subjects, layout fragments, and option parsing still require review.

## Verification status

- Python extraction tool executed against the supplied PDF.
- Kotlin source was updated by static inspection.
- Gradle compilation and live Ktor execution remain unverified because a Gradle executable/wrapper is not available in this environment.
