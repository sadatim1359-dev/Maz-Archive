# PDF Extraction - Stage 20

This stage adds a safe first extraction pass to the backend.

## Behavior

- The original uploaded PDF is kept as-is on the server.
- The upload endpoint validates the PDF signature before accepting it.
- After upload, Apache PDFBox extracts text page by page.
- The backend returns an extraction summary containing page count, extracted character count, and detected question numbers.
- Extraction is marked as requiring admin review; questions are not automatically published into the question table yet.
- Admins can request the summary through:
  - `GET /admin/exams/{id}/pdf/extraction-summary`

## Important

This is intentionally a non-destructive first step. Because Persian RTL layout, formulas, answer choices, and diagrams can be reordered by PDF text extraction, the next stage should add a reviewable question-draft table and a UI for correcting candidates before publication.
