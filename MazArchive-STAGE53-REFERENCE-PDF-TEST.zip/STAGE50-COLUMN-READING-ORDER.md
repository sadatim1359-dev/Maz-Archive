# Maz-Archive Stage 50 — Column Reading Order

- Added a deterministic horizontal tie-breaker for layout lines sharing the same vertical position.
- Preserved RTL column ordering and top-to-bottom ordering within each column.
- This is a layout-order safeguard, not proof of successful question extraction.
- Real Kotlin/Gradle compilation and extraction against the reference PDF must be verified in Render/GitHub Actions.
