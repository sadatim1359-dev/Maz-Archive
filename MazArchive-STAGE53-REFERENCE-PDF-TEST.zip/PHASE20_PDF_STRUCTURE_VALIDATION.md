# Phase 20 — PDF Structure Validation

This phase adds a repeatable external validation script for the supplied PDF.

## What was checked

- PDF signature (`%PDF-`)
- Text extraction with `pdftotext -layout`
- Presence of conventional question and option markers
- Basic extracted text volume

## Result

The PDF is readable and produces substantial extracted text, but the conventional line-based patterns for question and option markers produced no matches in the layout text. This indicates that the current Kotlin parser cannot be considered validated against this PDF using only those marker assumptions.

This is a diagnostic result, not a claim that the PDF is corrupt. The next implementation should inspect glyph positions/blocks or use a page-aware review workflow rather than automatically publishing extracted questions.
