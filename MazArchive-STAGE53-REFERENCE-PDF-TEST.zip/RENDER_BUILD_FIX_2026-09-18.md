# Render Build Fix — 2026-09-18

## Root cause
Gradle compilation failed in `backend/src/main/kotlin/com/mazarchive/Application.kt` because `CreateExamDto` has no `pdfUrl` property while the admin exam creation route referenced `exam.pdfUrl`.

## Fixes included
- The admin exam creation route now initializes the database `pdfUrl` column with an empty string. The PDF is attached later by `POST /admin/exams/{id}/pdf`.
- PDF extraction routes use normal `try/catch` instead of `runCatching/getOrElse` around suspend `call.respond` operations.
- The stable `PdfUploadResponse` / `PdfExtractionSummary` API contract is preserved.
- Android `CreateExamPayload` and `PdfUploadResponse` models remain aligned with the Backend.
- Root Dockerfile builds `backend/` directly; it does not search for or unzip a ZIP file.
- `backend/Dockerfile` is also configured for a direct Gradle build when Render's Root Directory is set to `backend`.
