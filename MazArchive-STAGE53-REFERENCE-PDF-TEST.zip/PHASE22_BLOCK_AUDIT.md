# Phase 22 — Question Block Audit

Added `tools/audit_question_blocks.py`.

- Audits extracted blocks for non-four option marker counts.
- Flags duplicate question numbers and very short previews.
- Produces `question-block-audit.json`.
- Explicitly prevents auto-publish and never infers correct answers.

The audit is offline and structural. Kotlin/PDFBox runtime and Gradle compilation remain unverified.
