# Phase 38 Notes

The repair tool preserves unresolved records and does not silently discard questions. It uses only contiguous option marker sequences and never derives an answer key.
