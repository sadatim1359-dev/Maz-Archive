# Phase 19 — Parser Hardening

Implemented a focused parser hardening pass:

- Normalizes Persian and Arabic-Indic digits before matching.
- Replaces common bidirectional/zero-width control characters with spaces.
- Collapses repeated whitespace before question/option matching.
- Keeps the existing safety rule that correct answers are never guessed.

Validation status:
- Source-level change completed.
- Full Gradle/Kotlin/PDFBox execution is still pending because this environment does not provide the project's Gradle wrapper or Gradle CLI.
- This phase must not be described as proof that all PDF questions are extracted correctly.
