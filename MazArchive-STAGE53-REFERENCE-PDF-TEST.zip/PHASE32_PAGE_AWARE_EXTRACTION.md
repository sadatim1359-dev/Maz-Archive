# Phase 32 — Page-aware PDF extraction prototype

## Implemented
- Added `tools/extract_questions_page_aware.py`.
- Preserves PDF page boundaries and splits question markers occurring on the same extracted line.
- Accepts only question-like numeric markers followed by a dash, reducing false positives from answer choices.
- Keeps `correct_index = -1`; no answer is inferred.
- Writes `page-aware-questions-v2.json` for review.

## Test with the supplied PDF
- question_count: 276
- pages_with_questions: 97
- needs_review: 55
- four_marker_questions: 221

## Limitation
The result is a prototype and not proof that all 276 records are semantically correct. Some PDF pages include answer/solution material and mixed layouts, so the next validation must classify page sections and compare extracted records against visual page images before publication.
