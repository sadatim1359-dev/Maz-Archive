# Phase 25 — Admin Extraction Review UI

Implemented:
- Android API method for `GET /admin/exams/{id}/pdf/extracted-questions`.
- Admin questions screen button to request extracted questions.
- Review cards showing question text, options, warnings, and safe answer state.
- The UI explicitly displays unassigned answers as requiring manual review.

Not verified:
- Gradle compilation and Android runtime execution were not available in this environment.
- No extracted question is automatically published or assigned a correct answer.
