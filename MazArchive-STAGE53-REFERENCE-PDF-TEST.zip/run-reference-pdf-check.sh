#!/usr/bin/env bash
set -euo pipefail
PDF="${1:?مسیر PDF را وارد کنید}"
command -v pdfinfo >/dev/null || { echo 'pdfinfo is required'; exit 2; }
command -v pdftotext >/dev/null || { echo 'pdftotext is required'; exit 2; }
pages=$(pdfinfo "$PDF" | awk '/^Pages:/ {print $2}')
text_file=$(mktemp)
trap 'rm -f "$text_file"' EXIT
pdftotext -layout "$PDF" "$text_file"
printf 'pages=%s\n' "$pages"
printf 'text_lines=%s\n' "$(wc -l < "$text_file")"
printf '%s\n' 'This is a preflight check only; it does not certify extraction correctness.'
