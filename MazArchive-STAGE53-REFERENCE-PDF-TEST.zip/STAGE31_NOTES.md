# Stage 31 — Persian/Arabic Digit Recognition

- Question-number detection now accepts ASCII, Persian, and Arabic-Indic digits.
- Option detection now accepts ASCII, Persian, and Arabic-Indic digits.
- Common Persian punctuation and both «سؤال» / «سوال» labels are supported.
- No candidate is silently discarded; existing quarantine and review rules remain active.

Validation status: source-level change completed. Gradle/Render integration test is still required.
