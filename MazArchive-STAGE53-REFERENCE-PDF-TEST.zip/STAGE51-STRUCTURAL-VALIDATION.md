# Stage 51 — Structural Question Validation

- Added post-reconstruction structural validation.
- Duplicate question numbers are marked `QUARANTINED`.
- Duplicate candidates remain visible for audit and are not silently deleted.
- Validation rules now explicitly require a unique number, non-empty question text, and exactly four non-empty options.
- Kotlin compilation and real PDF extraction still require verification in Render/GitHub Actions.
