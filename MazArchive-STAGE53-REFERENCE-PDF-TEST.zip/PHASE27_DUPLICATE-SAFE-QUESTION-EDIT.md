# Phase 27 – Duplicate-Safe Question Editing

Implemented:
- Backend rejects creating a question when the same exam already has that question number (HTTP 409).
- Backend rejects updating a question to a number already used by another question in the same exam (HTTP 409).
- Backend returns 404 when an update target does not exist.
- Android admin form tracks an optional question ID and calls POST for new questions or PUT for edits.
- The form resets edit mode after a successful save.

Verification:
- Static source inspection completed.
- Full Gradle compilation/runtime integration remains unverified because the archive does not include a Gradle wrapper and the current environment has no Gradle executable available.
