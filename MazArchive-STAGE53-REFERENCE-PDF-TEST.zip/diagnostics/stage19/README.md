# Stage 19 — Real PDF Layout Trace Inspection

This folder contains a diagnostic sample generated from the 13-page test PDF.

- `source-bbox.html`: raw bounding-box extraction.
- `layout-trace-sample.json`: page/line coordinates and heuristic column hints.

The `columnHint` field is only a diagnostic heuristic. It is not used to approve or extract questions.
