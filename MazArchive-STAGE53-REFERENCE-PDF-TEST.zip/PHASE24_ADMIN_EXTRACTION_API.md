# Phase 24 — Admin Extraction API Wiring

## Implemented
- Added Android Retrofit DTOs for the backend PDF extraction summary.
- Added Android Retrofit DTOs for extracted questions, including `needsReview` and warnings.
- Added authenticated API methods:
  - `GET admin/exams/{id}/pdf/extraction-summary`
  - `GET admin/exams/{id}/pdf/extracted-questions`

## Safety
- The client does not assume that an extracted answer is correct.
- `correctIndex` defaults to `-1` and `needsReview` defaults to `true`.
- This phase wires the API contract only; the full Compose review editor and Gradle compilation still require separate verification.
