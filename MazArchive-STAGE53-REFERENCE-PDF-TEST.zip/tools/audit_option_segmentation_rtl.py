#!/usr/bin/env python3
"""Stage 37: audit option markers with Persian/Arabic digit normalization."""
import json,re,sys
from pathlib import Path
DIGITS=str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789')
MARKER=re.compile(r'(?<!\d)([1-4])\s*[\)\.：:،؛]\s*')
def split_options(text):
    text=text.translate(DIGITS)
    ms=list(MARKER.finditer(text)); out=[]
    for i,m in enumerate(ms):
        end=ms[i+1].start() if i+1<len(ms) else len(text)
        out.append({'index':int(m.group(1)),'text':text[m.end():end].strip(' -–—:؛،')})
    return out
def main(inp,out):
    data=json.loads(Path(inp).read_text(encoding='utf-8')); audited=[]
    counts={'total':0,'four_complete':0,'missing_or_duplicate':0,'empty_option':0}
    for q in data.get('questions',[]):
        opts=split_options(q.get('text','')); indices=[x['index'] for x in opts]
        empty=sum(not x['text'] for x in opts); good=indices==[1,2,3,4] and empty==0
        counts['total']+=1; counts['four_complete']+=int(good); counts['missing_or_duplicate']+=int(not good); counts['empty_option']+=empty
        audited.append({**q,'parsed_options':opts,'option_audit_status':'ok' if good else 'review','needs_review':not good})
    result={'stage':'37','counts':counts,'questions':audited,'policy':'Digits normalized; option markers audited only; no answer key inferred.'}
    Path(out).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(counts,ensure_ascii=False))
if __name__=='__main__': main(sys.argv[1],sys.argv[2])
