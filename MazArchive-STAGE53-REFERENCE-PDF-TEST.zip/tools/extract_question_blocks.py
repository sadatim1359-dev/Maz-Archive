#!/usr/bin/env python3
"""Conservative layout-based question block detector.
It never assigns answers and marks uncertain blocks for review.
"""
from pathlib import Path
import json, re, sys

DIGITS = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')
BIDI = re.compile(r'[\u202a-\u202e\u2066-\u2069\u200b\u200c\u200d\ufeff]')
Q = re.compile(r'(?<!\d)[-−]?\s*([0-9]{1,3})\s*(?:[.)]|$)')
OPT = re.compile(r'(?<!\d)([1-4])\s*[.)]')

def clean(s):
    s = BIDI.sub('', s).translate(DIGITS)
    return re.sub(r'\s+', ' ', s).strip()

def detect(lines):
    starts=[]
    for i, raw in enumerate(lines):
        line=clean(raw)
        # Question markers in this source commonly appear at the right edge,
        # so accept a marker anywhere but require a non-empty question-like tail.
        matches=list(Q.finditer(line))
        for m in matches:
            tail=line[m.end():].strip(' :-')
            if tail and len(tail) >= 3:
                n=int(m.group(1))
                if 1 <= n <= 200:
                    starts.append((i,n))
                    break
    blocks=[]
    for idx,(start,n) in enumerate(starts):
        end=starts[idx+1][0] if idx+1<len(starts) else len(lines)
        content=[clean(x) for x in lines[start:end] if clean(x)]
        text=' '.join(content)
        options=sorted(set(int(x) for x in OPT.findall(text)))
        blocks.append({'number':n,'start_line':start+1,'end_line':end,
                       'option_markers':options,'option_marker_count':len(options),
                       'needs_review':len(options)!=4,'preview':text[:500]})
    return blocks

def main():
    src=Path(sys.argv[1]) if len(sys.argv)>1 else Path('pdf-layout.txt')
    out=Path(sys.argv[2]) if len(sys.argv)>2 else Path('question-blocks.json')
    lines=src.read_text(errors='replace').splitlines()
    blocks=detect(lines)
    out.write_text(json.dumps({'source':str(src),'block_count':len(blocks),'blocks':blocks},ensure_ascii=False,indent=2))
    print(f'source_lines={len(lines)}')
    print(f'detected_blocks={len(blocks)}')
    print(f'blocks_needing_review={sum(b["needs_review"] for b in blocks)}')
    print(f'output={out}')

if __name__=='__main__': main()
