#!/usr/bin/env python3
"""Phase 38: question-only extraction. Stops at the first answer-booklet marker."""
from __future__ import annotations
import fitz, json, re, sys, unicodedata
from pathlib import Path
DIGITS=str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789')
BIDI=re.compile(r'[\u202a-\u202e\u2066-\u2069\u200b\u200c\u200d\ufeff]')
ANSWER=re.compile(r'(دفترچه\s*ی?\s*پاسخ|دفترچه\s*پاسخ|پاسخنامه|کلید\s*پاسخ)', re.I)
QUESTION=re.compile(r'(?<!\d)(\d{1,3})\s*[-−–—]\s*')
OPTION=re.compile(r'(?<!\d)([1-4])\s*[\)\.：:،]')

def clean(s):
    s=unicodedata.normalize('NFKC',s).translate(DIGITS)
    s=BIDI.sub(' ',s)
    return re.sub(r'\s+',' ',s).strip()

def first_answer_page(doc):
    for n,p in enumerate(doc,1):
        t=clean(p.get_text('text') or '')
        if ANSWER.search(t): return n
    return None

def main():
    if len(sys.argv)<3: raise SystemExit('usage: script PDF OUT_JSON')
    pdf,out=Path(sys.argv[1]),Path(sys.argv[2]); doc=fitz.open(pdf)
    answer_page=first_answer_page(doc)
    end=(answer_page-1) if answer_page else len(doc)
    rows=[]
    for n in range(1,end+1):
        t=clean(doc[n-1].get_text('text') or '')
        matches=[m for m in QUESTION.finditer(t) if 1<=int(m.group(1))<=100]
        for i,m in enumerate(matches):
            nxt=matches[i+1].start() if i+1<len(matches) else len(t)
            body=t[m.end():nxt].strip(' -−–—')
            opts=sorted({int(x.group(1)) for x in OPTION.finditer(body)})
            rows.append({'page':n,'number':int(m.group(1)),'text_preview':body[:500], 'option_markers':opts,'option_marker_count':len(opts),'correct_index':-1,'needs_review':len(opts)!=4})
    result={'source':str(pdf),'pages':len(doc),'answer_marker_page':answer_page,'question_page_range':[1,end], 'question_count':len(rows),'questions':rows,'policy':'Only pages before the first answer-booklet marker are scanned; answer key is not extracted and correct_index remains -1.'}
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'pages':len(doc),'answer_marker_page':answer_page,'question_page_range':[1,end],'question_count':len(rows),'review_count':sum(r['needs_review'] for r in rows)},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
