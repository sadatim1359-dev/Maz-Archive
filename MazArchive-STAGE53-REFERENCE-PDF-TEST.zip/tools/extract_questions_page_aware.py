#!/usr/bin/env python3
"""Page-aware conservative extractor for the Maz PDF.
Keeps page boundaries, detects question starts at line boundaries, and never guesses answers.
"""
from pathlib import Path
import fitz, json, re, sys

DIGITS = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')
BIDI = re.compile(r'[\u202a-\u202e\u2066-\u2069\u200b\u200c\u200d\ufeff]')
QSTART = re.compile(r'(?<!\d)([0-9]{1,3})\s*[-−–—]\s+')
OPT = re.compile(r'(?<!\d)([1-4])\s*[.)：:]')


def clean(s):
    return re.sub(r'\s+', ' ', BIDI.sub('', s).translate(DIGITS)).strip()


def extract(pdf_path):
    doc = fitz.open(pdf_path)
    questions = []
    for page_no, page in enumerate(doc, 1):
        text = page.get_text('text')
        page_text = clean(text)
        matches = list(QSTART.finditer(page_text))
        starts = []
        for m in matches:
            number = int(m.group(1))
            tail = page_text[m.end():m.end()+80]
            if 1 <= number <= 200 and re.search(r"[آ-ی]", tail):
                starts.append((m.start(), m.end(), number))
        for j, (start, marker_end, number) in enumerate(starts):
            end = starts[j+1][0] if j + 1 < len(starts) else len(page_text)
            joined = page_text[marker_end:end].strip()
            markers = sorted(set(int(x) for x in OPT.findall(joined)))
            questions.append({
                'page': page_no,
                'number': number,
                'text': joined,
                'option_markers': markers,
                'needs_review': len(markers) != 4,
                'correct_index': -1,
            })
    return questions


def main():
    if len(sys.argv) < 2:
        raise SystemExit('usage: extract_questions_page_aware.py PDF [OUT]')
    pdf = Path(sys.argv[1])
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path('page-aware-questions.json')
    qs = extract(pdf)
    out.write_text(json.dumps({'source': str(pdf), 'question_count': len(qs), 'questions': qs}, ensure_ascii=False, indent=2))
    print(f'question_count={len(qs)}')
    print(f'pages_with_questions={len(set(q["page"] for q in qs))}')
    print(f'needs_review={sum(q["needs_review"] for q in qs)}')
    print(f'four_marker_questions={sum(not q["needs_review"] for q in qs)}')
    print(f'output={out}')

if __name__ == '__main__':
    main()
