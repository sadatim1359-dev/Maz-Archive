#!/usr/bin/env python3
"""Phase 39: audit question option boundaries without reading answer keys."""
from __future__ import annotations
import json, re, sys
from pathlib import Path

MARKER = re.compile(r'(?<!\d)([1-4])\s*[\)\.：:،]\s*')

def split_options(text: str):
    ms=list(MARKER.finditer(text))
    out=[]
    for i,m in enumerate(ms):
        end=ms[i+1].start() if i+1<len(ms) else len(text)
        value=text[m.end():end].strip(' -–—:؛،')
        out.append({'index':int(m.group(1)), 'text':value})
    return out

def main():
    if len(sys.argv)!=3: raise SystemExit('usage: audit_option_segmentation.py IN_JSON OUT_JSON')
    inp,out=map(Path,sys.argv[1:]); data=json.loads(inp.read_text(encoding='utf-8'))
    audited=[]; counts={'total':0,'four_complete':0,'missing_or_duplicate':0,'empty_option':0}
    for q in data.get('questions',[]):
        opts=split_options(q.get('text',''))
        indices=[o['index'] for o in opts]
        empty=sum(not o['text'] for o in opts)
        good=indices==[1,2,3,4] and empty==0
        counts['total']+=1
        counts['four_complete']+=int(good)
        counts['missing_or_duplicate']+=int(not good)
        counts['empty_option']+=empty
        audited.append({**q,'parsed_options':opts,'option_audit_status':'ok' if good else 'review','needs_review':not good})
    result={'source':data.get('source'),'question_count':len(audited),'counts':counts,'questions':audited,'policy':'Option boundaries are audited only; no answer key is extracted and correct_index remains -1.'}
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(counts,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
