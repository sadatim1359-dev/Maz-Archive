#!/usr/bin/env python3
from pathlib import Path
import re, subprocess, sys
pdf = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('maze11R-2qA-16mor04.pdf')
out = Path('/tmp/mazarchive_pdf_layout.txt')
subprocess.run(['pdftotext','-layout',str(pdf),str(out)], check=True)
text = out.read_text(errors='replace')
lines = text.splitlines()
checks = {
    'pdf_exists': pdf.exists(),
    'has_pdf_header': pdf.read_bytes()[:5] == b'%PDF-',
    'page_count_detected': bool(re.search(r'Pages:\s*\d+', subprocess.check_output(['pdfinfo',str(pdf)], text=True))),
    'standard_question_markers_found': bool(re.search(r'(?m)^\s*[0-9۰-۹]{1,3}\s*[)\\.\-:]', text)),
    'standard_option_markers_found': bool(re.search(r'(?m)^\s*[1-4۱-۴]\s*[)\\.\-:]', text)),
}
print(f'PDF: {pdf}')
print(f'Characters after pdftotext -layout: {len(text)}')
print(f'Non-empty lines: {sum(bool(x.strip()) for x in lines)}')
for k,v in checks.items(): print(f'{k}: {v}')
if not checks['standard_question_markers_found']:
    print('finding: standard question-marker regex found no matches in layout text')
if not checks['standard_option_markers_found']:
    print('finding: standard option-marker regex found no matches in layout text')
