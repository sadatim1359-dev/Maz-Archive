#!/usr/bin/env python3
"""Phase 36: extract question candidates only before the first answer-booklet marker.
Keeps page/section context, preserves repeated question numbers across booklets,
and never infers correct answers.
"""
from __future__ import annotations
import json, re, sys, unicodedata
from pathlib import Path
import fitz

DIGITS = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')
BIDI = re.compile(r'[\u202a-\u202e\u2066-\u2069\u200b\u200c\u200d\ufeff]')
ANSWER_MARKER = re.compile(r'دفتر\s*چه\s*پاسخ|پاسخ\s*نامه|دفتر\s*چه\s*ی?\s*پاسخ')
QUESTION_LINE = re.compile(r'^\s*(\d{1,3})\s*[-−–—]\s*(.*)$')
QUESTION_SPLIT = re.compile(r'^\s*(\d{1,3})\s*$')
OPTION_MARKER = re.compile(r'(?<!\d)([1-4])\s*\)')

def clean(value: str) -> str:
    value = unicodedata.normalize('NFKC', value).translate(DIGITS)
    value = BIDI.sub(' ', value)
    return re.sub(r'\s+', ' ', value).strip()

def first_answer_page(doc: fitz.Document) -> int | None:
    for page_no, page in enumerate(doc, 1):
        if ANSWER_MARKER.search(clean(page.get_text('text') or '')):
            return page_no
    return None

def page_markers(lines: list[str]):
    found = []
    i = 0
    while i < len(lines):
        line = lines[i]
        split = QUESTION_SPLIT.fullmatch(line)
        if split and i + 1 < len(lines) and lines[i + 1] in {'-', '−', '–', '—'}:
            number = int(line)
            if 1 <= number <= 200:
                found.append((i, number, i + 2))
                i += 2
                continue
        match = QUESTION_LINE.match(line)
        if match:
            number = int(match.group(1))
            if 1 <= number <= 200:
                found.append((i, number, i + 1))
        i += 1
    return found

def extract(pdf_path: Path):
    doc = fitz.open(pdf_path)
    answer_page = first_answer_page(doc)
    end_page = (answer_page - 1) if answer_page else len(doc)
    questions = []
    for page_no in range(1, end_page + 1):
        lines = [clean(line) for line in (doc[page_no - 1].get_text('text') or '').splitlines()]
        lines = [line for line in lines if line]
        markers = page_markers(lines)
        for index, (start, number, content_start) in enumerate(markers):
            end = markers[index + 1][0] if index + 1 < len(markers) else len(lines)
            content = lines[content_start:end]
            joined = ' '.join(content).strip()
            option_markers = sorted({int(match.group(1)) for match in OPTION_MARKER.finditer(joined)})
            questions.append({
                'page': page_no,
                'number': number,
                'text_preview': joined[:500],
                'option_markers': option_markers,
                'option_marker_count': len(option_markers),
                'correct_index': -1,
                'needs_review': len(option_markers) != 4,
            })
    return {
        'source': str(pdf_path),
        'pages': len(doc),
        'first_answer_marker_page': answer_page,
        'question_scan_end_page': end_page,
        'question_count': len(questions),
        'pages_with_questions': sorted({item['page'] for item in questions}),
        'duplicate_number_count': len(questions) - len({(item['page'], item['number']) for item in questions}),
        'questions': questions,
        'policy': 'Question candidates are restricted to pages before the first answer marker; correct answers remain -1.'
    }

def main():
    if len(sys.argv) < 2:
        raise SystemExit('usage: extract_questions_marker_range.py PDF [OUT]')
    pdf = Path(sys.argv[1])
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path('phase36-marker-range-questions.json')
    result = extract(pdf)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('pages', 'first_answer_marker_page', 'question_scan_end_page', 'question_count', 'pages_with_questions')}, ensure_ascii=False, indent=2))
    print(f'output={out}')

if __name__ == '__main__':
    main()
