#!/usr/bin/env python3
"""Phase 37: classify booklet question pages and extract page-local candidates.
Conservative: only pages with a subject header and question-like markers are scanned.
No answer key is inferred.
"""
from __future__ import annotations
import fitz, json, re, sys, unicodedata
from pathlib import Path
DIGITS=str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789')
BIDI=re.compile(r'[\u202a-\u202e\u2066-\u2069\u200b\u200c\u200d\ufeff]')
SUBJECTS=[('math','ریاضی|حسابان|هندسه'),('physics','فیزیک'),('chemistry','شیمی'),('preview','پیش\s*خوانی')]
QUESTION=re.compile(r'(?<!\d)(\d{1,3})\s*[-−–—]\s*')
OPTION=re.compile(r'(?<!\d)([1-4])\s*\)')

def clean(s):
 s=unicodedata.normalize('NFKC',s).translate(DIGITS); s=BIDI.sub(' ',s)
 return re.sub(r'\s+',' ',s).strip()

def subject(text):
 for name,pat in SUBJECTS:
  if re.search(pat,text,re.I): return name
 return None

def marker_pages(doc):
 out=[]
 for n,p in enumerate(doc,1):
  t=clean(p.get_text('text') or '')
  subj=subject(t)
  # A question page has the standard page header and at least one question-like marker.
  qs=[int(m.group(1)) for m in QUESTION.finditer(t) if 1 <= int(m.group(1)) <= 100]
  is_question=bool(subj and 'صفحه' in t and qs)
  out.append({'page':n,'subject':subj,'question_like_numbers':qs,'is_question_page':is_question,
              'text_preview':t[:220]})
 return out

def extract(doc,pages):
 rows=[]
 for info in pages:
  if not info['is_question_page']: continue
  p=doc[info['page']-1]; t=clean(p.get_text('text') or '')
  matches=[m for m in QUESTION.finditer(t) if 1 <= int(m.group(1)) <= 100]
  for i,m in enumerate(matches):
   num=int(m.group(1)); end=matches[i+1].start() if i+1<len(matches) else len(t)
   body=t[m.end():end].strip(' -−–—')
   opts=sorted({int(x.group(1)) for x in OPTION.finditer(body)})
   rows.append({'page':info['page'],'subject':info['subject'],'number':num,
    'text_preview':body[:500],'option_markers':opts,'option_marker_count':len(opts),
    'correct_index':-1,'needs_review':len(opts)!=4})
 return rows

def main():
 if len(sys.argv)<3: raise SystemExit('usage: script PDF OUT_JSON')
 pdf,out=Path(sys.argv[1]),Path(sys.argv[2]); doc=fitz.open(pdf)
 pages=marker_pages(doc); rows=extract(doc,pages)
 result={'source':str(pdf),'pages':len(doc),'question_pages':[x for x in pages if x['is_question_page']],
  'question_count':len(rows),'subjects':sorted({r['subject'] for r in rows}),
  'counts_by_subject':{s:sum(r['subject']==s for r in rows) for s in sorted({r['subject'] for r in rows})},
  'duplicate_number_by_subject':{s:len([r for r in rows if r['subject']==s])-len({r['number'] for r in rows if r['subject']==s}) for s in sorted({r['subject'] for r in rows})},
  'questions':rows,'policy':'Only subject-labelled question pages are scanned; correct answers remain -1.'}
 out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'pages':len(doc),'question_pages':[x['page'] for x in pages if x['is_question_page']], 'question_count':len(rows),'counts_by_subject':result['counts_by_subject'],'duplicates':result['duplicate_number_by_subject']},ensure_ascii=False,indent=2))
 print('output='+str(out))
if __name__=='__main__': main()
