#!/usr/bin/env python3
"""Stage 38: conservative repair of option segmentation.
Keeps only a contiguous final 1,2,3,4 marker sequence when extra markers
occur in the stem; otherwise sends the question to manual review.
"""
import json,re,sys
from pathlib import Path

def repair(opts):
    seq=[o.get('index') for o in opts]
    candidates=[]
    for i in range(len(seq)-3):
        if seq[i:i+4]==[1,2,3,4]: candidates.append(i)
    if not candidates: return opts, 'review_no_contiguous_sequence'
    start=candidates[-1]
    chosen=opts[start:start+4]
    if any(o.get('text','').strip()=='' for o in chosen): return chosen,'review_empty_option'
    return chosen, 'repaired' if start>0 or len(opts)>4 else 'ok'

def main(inp,out):
    d=json.loads(Path(inp).read_text(encoding='utf-8')); qs=[]
    counts={'total':0,'ok':0,'repaired':0,'review':0}
    for q in d.get('questions',[]):
        opts=q.get('parsed_options',[])
        fixed,status=repair(opts)
        counts['total']+=1
        if status=='ok': counts['ok']+=1
        elif status=='repaired': counts['repaired']+=1
        else: counts['review']+=1
        qs.append({**q,'repaired_options':fixed,'stage38_status':status,'needs_review':status.startswith('review')})
    result={'stage':'38','counts':counts,'questions':qs,'policy':'Only contiguous 1-2-3-4 sequences are accepted; no answer key is inferred; unresolved items remain for review.'}
    Path(out).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(counts,ensure_ascii=False))
if __name__=='__main__': main(sys.argv[1],sys.argv[2])
