#!/usr/bin/env python3
"""Stage 34: deterministic PDF layout probe for RTL column extraction."""
import json, re, sys
from pathlib import Path
import fitz

FA_DIGITS = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')
QUESTION = re.compile(r'(?m)(?:^|\s)(\d{1,3})\s*[.)،:]')

def norm(s):
    return s.translate(FA_DIGITS)

def main(pdf_path, out_path):
    doc = fitz.open(pdf_path)
    pages=[]
    total_markers=0
    for pno, page in enumerate(doc, 1):
        blocks=[]
        for b in page.get_text('blocks'):
            x0,y0,x1,y1,text,*_ = b
            text=text.strip()
            if not text: continue
            blocks.append({'x0':round(x0,2),'y0':round(y0,2),'x1':round(x1,2),'y1':round(y1,2),'text':text})
        # RTL: group by rough x position and read right group first, top-down.
        ordered=sorted(blocks,key=lambda b:(round(b['x0']/25), b['y0']))
        markers=[]
        for b in ordered:
            for m in QUESTION.finditer(norm(b['text'])):
                markers.append(int(m.group(1)))
        total_markers += len(markers)
        pages.append({'page':pno,'block_count':len(blocks),'characters':sum(len(b['text']) for b in blocks),'candidate_question_numbers':markers,'ordered_blocks_preview':ordered[:8]})
    result={'stage':'34','source':Path(pdf_path).name,'pages':len(doc),'total_candidate_question_markers':total_markers,'pages':pages,'warnings':['این گزارش تشخیصی است و به‌تنهایی استخراج نهایی سؤال‌ها را تأیید نمی‌کند.']}
    Path(out_path).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'pages':len(doc),'candidate_markers':total_markers,'output':out_path},ensure_ascii=False))
if __name__=='__main__': main(sys.argv[1],sys.argv[2])
