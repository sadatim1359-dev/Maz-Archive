#!/usr/bin/env python3
"""Build a deterministic human-review queue from the structural audit."""
from pathlib import Path
import json, sys

src = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('question-block-audit.json')
out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path('question-review-queue.json')
audit = json.loads(src.read_text(encoding='utf-8'))
issues = audit.get('issues', [])
queue = []
for index, issue in enumerate(issues, 1):
    queue.append({
        'review_id': f'REVIEW-{index:04d}',
        'question_number': issue.get('number'),
        'start_line': issue.get('start_line'),
        'reasons': sorted(set(issue.get('reasons', []))),
        'status': 'pending',
        'reviewer_decision': None,
        'correct_option_index': None,
        'notes': ''
    })
report = {
    'source': str(src),
    'queue_count': len(queue),
    'status_counts': {'pending': len(queue), 'approved': 0, 'rejected': 0},
    'answer_policy': 'correct_option_index remains null until a human reviewer explicitly enters it.',
    'items': queue
}
out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'queue_count={report["queue_count"]}')
print('pending_count=' + str(report['status_counts']['pending']))
print('answers_inferred=0')
print(f'output={out}')
