#!/usr/bin/env python3
"""Audit extracted question blocks for structural risks; never infers answers."""
from pathlib import Path
import json, sys
from collections import Counter

src = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('question-blocks.json')
out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path('question-block-audit.json')
data = json.loads(src.read_text(encoding='utf-8'))
blocks = data.get('blocks', [])
nums = [b.get('number') for b in blocks]
counts = Counter(nums)
issues = []
for b in blocks:
    reasons = []
    if b.get('option_marker_count') != 4:
        reasons.append('option_marker_count_not_4')
    if counts[b.get('number')] > 1:
        reasons.append('duplicate_question_number')
    preview = b.get('preview', '')
    if len(preview) < 20:
        reasons.append('very_short_preview')
    if reasons:
        issues.append({'number': b.get('number'), 'start_line': b.get('start_line'), 'reasons': reasons})
report = {
    'source': str(src),
    'block_count': len(blocks),
    'unique_question_numbers': len(set(nums)),
    'duplicate_numbers': sorted(n for n, c in counts.items() if c > 1),
    'review_issue_count': len(issues),
    'issues': issues,
    'safe_for_auto_publish': False,
    'reason': 'Structural audit only; human review is required and answers are never inferred.'
}
out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'blocks={report["block_count"]}')
print(f'unique_numbers={report["unique_question_numbers"]}')
print(f'duplicate_numbers={len(report["duplicate_numbers"])}')
print(f'issues={report["review_issue_count"]}')
print(f'safe_for_auto_publish={report["safe_for_auto_publish"]}')
print(f'output={out}')
