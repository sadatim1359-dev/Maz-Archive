# Phase 17 — Layout-aware PDF extraction implementation

## Implemented
- Added a real `PDFTextStripper` subclass using `TextPosition`.
- Rebuilds each emitted text chunk using glyph X coordinates.
- Uses descending X order for predominantly RTL chunks and ascending X order otherwise.
- Wired the stripper into both PDF summary and question extraction paths.

## Validation status
- Source-level implementation completed.
- Runtime Kotlin/PDFBox compilation and extraction are still pending because this environment does not have a usable Gradle wrapper/Gradle installation.
- This phase does not claim that every question and option has been correctly extracted.
