-- Maz-Archive Phase 40: questions/options-only compatibility
-- Run against an existing PostgreSQL database before importing extraction output.
ALTER TABLE questions
    ALTER COLUMN correct_index DROP NOT NULL;

-- Existing answer values are preserved. New extraction records must use NULL
-- when no answer key is supplied; do not store -1 in the database column.
