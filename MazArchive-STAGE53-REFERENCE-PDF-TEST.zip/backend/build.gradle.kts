plugins { kotlin("jvm") version "2.0.21"; kotlin("plugin.serialization") version "2.0.21"; application }
dependencies {
 implementation("io.ktor:ktor-server-core-jvm:3.0.3"); implementation("io.ktor:ktor-server-netty-jvm:3.0.3")
 implementation("io.ktor:ktor-server-content-negotiation-jvm:3.0.3"); implementation("io.ktor:ktor-serialization-kotlinx-json-jvm:3.0.3")
 implementation("io.ktor:ktor-server-auth-jvm:3.0.3"); implementation("io.ktor:ktor-server-auth-jwt-jvm:3.0.3"); implementation("io.ktor:ktor-server-cors-jvm:3.0.3")
 implementation("org.jetbrains.exposed:exposed-core:0.57.0"); implementation("org.jetbrains.exposed:exposed-jdbc:0.57.0"); implementation("org.jetbrains.exposed:exposed-java-time:0.57.0")
 implementation("org.postgresql:postgresql:42.7.4"); implementation("at.favre.lib:bcrypt:0.10.2"); implementation("org.apache.pdfbox:pdfbox:3.0.3")
 implementation("ch.qos.logback:logback-classic:1.5.15")
 testImplementation(kotlin("test"))
}
application { mainClass.set("com.mazarchive.ApplicationKt") }
