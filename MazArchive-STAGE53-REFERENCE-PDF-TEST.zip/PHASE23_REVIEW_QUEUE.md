# Phase 23 — Human Review Queue

Added `tools/build_review_queue.py` to convert structural audit issues into a deterministic human-review queue.

Each item contains:
- stable review ID
- question number and source line
- structural reasons
- pending status
- empty reviewer decision
- empty correct option index
- notes field

The tool never infers or assigns a correct answer. `correct_option_index` remains `null` until a human reviewer explicitly enters it.

Validation performed:
- structural audit rerun
- review queue generated
- output JSON parsed successfully
- automatic answer inference count: 0

Compilation and full backend runtime execution remain unverified because a Gradle executable/wrapper is not available in this environment.
