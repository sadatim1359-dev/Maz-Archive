# Phase 21 — Conservative Layout Block Extraction

Added `tools/extract_question_blocks.py`.

- Cleans bidirectional/zero-width controls and Persian/Arabic-Indic digits.
- Detects candidate question starts conservatively from layout text.
- Groups lines into question blocks and counts option markers.
- Writes a JSON preview with source line ranges.
- Marks blocks whose four option markers are not detected as `needs_review`.
- Does not infer or assign correct answers.

Validation performed locally against the included `pdf-layout.txt` using Python.
This is an offline structural detector, not proof of Kotlin/PDFBox runtime behavior.
