# Stage 33 — RTL column ordering

## Change

The question-candidate builder now visits columns in descending column index
for each page. This is intended for Persian right-to-left exam layouts where
the right-hand column should be processed before the left-hand column.

## Safety

- The change does not claim that all PDFs use RTL ordering.
- Candidate validation and review-queue behavior remain enabled.
- A real 40-question extraction test and Gradle compilation are still required.
