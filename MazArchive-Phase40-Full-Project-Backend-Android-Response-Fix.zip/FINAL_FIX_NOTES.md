# MazArchive – Full Project Response Fix

This archive contains the complete project (backend + Android + tools + documentation).

Fix included:
- Backend PDF upload endpoint returns a structured `PdfUploadResponse` object.
- Android `Api.kt` models `extraction` as `ExtractionSummaryDto`, matching the backend JSON object.
- Retrofit JSON converter keeps `ignoreUnknownKeys=true` for compatibility.

Deployment:
1. Back up the existing GitHub repository.
2. Replace the repository project files with the contents of this archive, preserving `.github/workflows/build-apk.yml` if it is not included in the archive.
3. Commit and push.
4. Run GitHub Actions to build the APK.
5. Deploy the backend on Render.
