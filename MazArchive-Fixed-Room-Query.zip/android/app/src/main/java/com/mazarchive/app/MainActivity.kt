package com.mazarchive.app

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.consume
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.serialization.Serializable
import androidx.compose.ui.text.input.PasswordVisualTransformation
import java.net.URLDecoder
import java.net.URLEncoder

@Serializable
data class Exam(
    val id: Long,
    val title: String,
    val grade: String,
    val field: String,
    val examNumber: Int? = null,
    val examDate: String,
    val year: Int,
    val period: String,
    val month: String,
    val pdfUrl: String
)

enum class PenTool { PEN, HIGHLIGHTER, ERASER }

data class Stroke(
    val id: String = java.util.UUID.randomUUID().toString(),
    val page: Int,
    val points: List<androidx.compose.ui.geometry.Offset>,
    val color: Color,
    val width: Float,
    val alpha: Float,
    val tool: PenTool
)

private val Indigo = Color(0xFF7167E8)
private val Bg = Color(0xFF0B0B0F)
private val Card = Color(0xFF15151C)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { MazTheme { App() } }
    }
}

@Composable
fun MazTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Indigo,
            background = Bg,
            surface = Card
        ),
        content = content
    )
}

@Composable
fun App() {
    val nav = rememberNavController()
    var loggedIn by rememberSaveable { mutableStateOf(false) }

    if (!loggedIn) {
        LoginScreen { loggedIn = true }
        return
    }

    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            Home { grade -> nav.navigate("fields/${URLEncoder.encode(grade, "UTF-8")}") }
        }
        composable("fields/{g}") { backStackEntry ->
            val grade = URLDecoder.decode(
                backStackEntry.arguments?.getString("g")!!,
                "UTF-8"
            )
            Fields(grade) { field ->
                nav.navigate(
                    "archive/${URLEncoder.encode(grade, "UTF-8")}/${URLEncoder.encode(field, "UTF-8")}"
                )
            }
        }
        composable("archive/{g}/{f}") { backStackEntry ->
            Archive(
                URLDecoder.decode(backStackEntry.arguments?.getString("g")!!, "UTF-8"),
                URLDecoder.decode(backStackEntry.arguments?.getString("f")!!, "UTF-8")
            ) { id -> nav.navigate("exam/$id") }
        }
        composable("exam/{id}") { backStackEntry ->
            ExamDetail(backStackEntry.arguments?.getString("id")!!.toLong()) { url ->
                nav.navigate("pdf/${URLEncoder.encode(url, "UTF-8")}")
            }
        }
        composable("pdf/{url}") { backStackEntry ->
            PdfScreen(URLDecoder.decode(backStackEntry.arguments?.getString("url")!!, "UTF-8")) {
                nav.popBackStack()
            }
        }
    }
}

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().background(Bg).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(50.dp))
        Text("MazArchive", style = MaterialTheme.typography.headlineLarge)
        Text("ورود به آرشیو", color = Color.Gray)
        OutlinedTextField(
            value = user,
            onValueChange = { user = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("نام کاربری") }
        )
        OutlinedTextField(
            value = pass,
            onValueChange = { pass = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("رمز عبور") },
            visualTransformation = PasswordVisualTransformation()
        )
        Button(
            onClick = onLogin,
            modifier = Modifier.fillMaxWidth(),
            enabled = user.isNotBlank() && pass.isNotBlank()
        ) {
            Text("ورود")
        }
    }
}

@Composable
fun Home(onGrade: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Bg).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text("MazArchive", style = MaterialTheme.typography.headlineMedium)
        Text("آرشیو ماز", color = Color.LightGray)
        Text("جدیدترین آزمون‌های ماز", style = MaterialTheme.typography.titleLarge)
        Card(
            Modifier.fillMaxWidth().height(175.dp),
            colors = CardDefaults.cardColors(containerColor = Card)
        ) {
            Column(
                Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Text("آزمون مرحله دوم")
                Text("یازدهم ریاضی")
                Text("شیمی")
                Text("۱۵ آبان ۱۴۰۴", color = Indigo)
                Text("مشاهده آزمون ›", color = Indigo)
            }
        }
        Text("انتخاب پایه", style = MaterialTheme.typography.titleMedium)
        listOf("دهم", "یازدهم", "دوازدهم").forEach { grade ->
            TextButton(onClick = { onGrade(grade) }, modifier = Modifier.fillMaxWidth()) {
                Text(grade, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
fun Fields(grade: String, onField: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Bg).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("رشته $grade", style = MaterialTheme.typography.headlineSmall)
        listOf("ریاضی", "تجربی", "انسانی").forEach { field ->
            Button(onClick = { onField(field) }, modifier = Modifier.fillMaxWidth()) {
                Text(field)
            }
        }
    }
}

@Composable
fun Archive(grade: String, field: String, open: (Long) -> Unit) {
    var q by remember { mutableStateOf("") }
    var year by remember { mutableStateOf<Int?>(null) }
    var period by remember { mutableStateOf<String?>(null) }
    var month by remember { mutableStateOf<String?>(null) }
    var showFilter by remember { mutableStateOf(false) }

    val data = remember(grade, field, q, year, period, month) {
        (1..18)
            .map { n ->
                Exam(
                    n.toLong(), "آزمون شماره $n", grade, field, n,
                    "۱۴۰۴/۰۸/${(25 - n).coerceAtLeast(1)}", 1404,
                    "شروع از مهر", "آبان", ""
                )
            }
            .filter { q.isBlank() || it.title.contains(q) || it.examDate.contains(q) }
            .filter { year == null || it.year == year }
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("آزمون‌های $grade $field", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { showFilter = !showFilter }) { Text("☷") }
        }
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("مثلاً: آزمون ۲۳ آبان ۱۴۰۴", color = Color.Gray) }
        )
        if (showFilter) {
            FilterPanel(year, { year = it }, period, { period = it }, month, { month = it })
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(data) { exam ->
                Card(
                    Modifier.fillMaxWidth().clickable { open(exam.id) },
                    colors = CardDefaults.cardColors(containerColor = Card)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(exam.title)
                        Text(exam.examDate, color = Color.Gray)
                        Text("مشاهده آزمون ›", color = Indigo)
                    }
                }
            }
        }
    }
}

@Composable
fun FilterPanel(
    year: Int?, setYear: (Int?) -> Unit,
    period: String?, setPeriod: (String?) -> Unit,
    month: String?, setMonth: (String?) -> Unit
) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Filter", style = MaterialTheme.typography.titleMedium)
        Text("Year")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(1404, 1403, 1402).forEach { value ->
                FilterChip(
                    selected = year == value,
                    onClick = { setYear(if (year == value) null else value) },
                    label = { Text(value.toString()) }
                )
            }
        }
        Text("Period")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("تابستانه", "شروع از مهر").forEach { value ->
                FilterChip(
                    selected = period == value,
                    onClick = { setPeriod(if (period == value) null else value) },
                    label = { Text(value) }
                )
            }
        }
        Text("Month")
        val months = if (period == "تابستانه") {
            listOf("تیر", "مرداد", "شهریور")
        } else {
            listOf("مهر", "آبان", "آذر", "دی", "بهمن", "اسفند", "فروردین", "اردیبهشت", "خرداد")
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            months.forEach { value ->
                FilterChip(
                    selected = month == value,
                    onClick = { setMonth(if (month == value) null else value) },
                    label = { Text(value) }
                )
            }
        }
    }
}

@Composable
fun ExamDetail(id: Long, open: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Bg).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("آزمون شماره $id", style = MaterialTheme.typography.headlineSmall)
        Text("آزمون + پاسخنامه", color = Color.Gray)
        Button(
            onClick = { open("${AppConfig.BASE_URL}exams/$id/pdf") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("مشاهده فایل")
        }
    }
}

@Composable
fun PdfScreen(url: String, onBack: () -> Unit) {
    var file by remember { mutableStateOf<java.io.File?>(null) }
    var tool by remember { mutableStateOf(PenTool.PEN) }
    var width by remember { mutableFloatStateOf(5f) }
    var color by remember { mutableStateOf(Color.Red) }
    var tools by remember { mutableStateOf(false) }
    var strokes by remember { mutableStateOf(listOf<Stroke>()) }
    var redo by remember { mutableStateOf(listOf<Stroke>()) }

    LaunchedEffect(url) {
        file = runCatching {
            val f = java.io.File.createTempFile("maz-", ".pdf")
            java.net.URL(url).openStream().use { input ->
                f.outputStream().use { output -> input.copyTo(output) }
            }
            f
        }.getOrNull()
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(
            Modifier.fillMaxWidth().height(48.dp).background(Color(0xFF101014)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("←") }
            TextButton(onClick = { tools = !tools }) { Text("✏️") }
            TextButton(
                onClick = {
                    val last = strokes.last()
                    strokes = strokes.dropLast(1)
                    redo = redo + last
                },
                enabled = strokes.isNotEmpty()
            ) { Text("↶") }
            TextButton(
                onClick = {
                    val last = redo.last()
                    redo = redo.dropLast(1)
                    strokes = strokes + last
                },
                enabled = redo.isNotEmpty()
            ) { Text("↷") }
        }
        if (tools) {
            Surface(color = Color(0xFF17171D)) {
                Column(Modifier.padding(10.dp)) {
                    Row {
                        listOf(
                            PenTool.PEN to "قلم",
                            PenTool.HIGHLIGHTER to "هایلایتر",
                            PenTool.ERASER to "پاک‌کن"
                        ).forEach { (t, label) ->
                            FilterChip(
                                selected = tool == t,
                                onClick = { tool = t; tools = false },
                                label = { Text(label) }
                            )
                        }
                    }
                    Row {
                        listOf(3f to "نازک", 6f to "متوسط", 12f to "ضخیم").forEach { (w, label) ->
                            FilterChip(
                                selected = width == w,
                                onClick = { width = w },
                                label = { Text(label) }
                            )
                        }
                    }
                    Row {
                        listOf(
                            Color.Black to "مشکی",
                            Color.Red to "قرمز",
                            Color.Blue to "آبی",
                            Color.Green to "سبز"
                        ).forEach { (c, label) ->
                            FilterChip(
                                selected = color == c,
                                onClick = { color = c },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }
        }
        file?.let { pdfFile ->
            PdfCanvas(pdfFile, strokes, { stroke ->
                strokes = strokes + stroke
                redo = emptyList()
            }, tool, width, color)
        } ?: Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) { CircularProgressIndicator() }
    }
}

@Composable
fun PdfCanvas(
    file: java.io.File,
    strokes: List<Stroke>,
    add: (Stroke) -> Unit,
    tool: PenTool,
    width: Float,
    color: Color
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    val renderer = remember(file) {
        PdfRenderer(ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY))
    }
    DisposableEffect(renderer) {
        onDispose { renderer.close() }
    }
    val pages = renderer.pageCount
    val bitmaps = remember(file) {
        (0 until pages).map { pageIndex ->
            renderer.openPage(pageIndex).let { page ->
                Bitmap.createBitmap(page.width, page.height, Bitmap.Config.ARGB_8888).also { bitmap ->
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()
                }
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 4f)
                    offset += pan
                }
            }
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
        ) {
            bitmaps.forEachIndexed { pageIndex, bitmap ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Canvas(
                        Modifier
                            .matchParentSize()
                            .pointerInput(tool, width, color, pageIndex) {
                                val points = mutableListOf<androidx.compose.ui.geometry.Offset>()
                                awaitPointerEventScope {
                                    while (true) {
                                        val event = awaitPointerEvent()
                                        if (event.changes.size == 1 && event.changes[0].pressed) {
                                            val change = event.changes[0]
                                            points += androidx.compose.ui.geometry.Offset(
                                                (change.position.x / size.width).coerceIn(0f, 1f),
                                                (change.position.y / size.height).coerceIn(0f, 1f)
                                            )
                                            change.consume()
                                        } else if (points.isNotEmpty()) {
                                            add(
                                                Stroke(
                                                    page = pageIndex,
                                                    points = points.toList(),
                                                    color = if (tool == PenTool.ERASER) Color.Transparent else color,
                                                    width = width,
                                                    alpha = if (tool == PenTool.HIGHLIGHTER) 0.35f else 1f,
                                                    tool = tool
                                                )
                                            )
                                            points.clear()
                                        }
                                    }
                                }
                            }
                    ) {
                        strokes
                            .filter { it.page == pageIndex && it.points.size > 1 }
                            .forEach { stroke ->
                                val path = Path()
                                path.moveTo(
                                    stroke.points[0].x * size.width,
                                    stroke.points[0].y * size.height
                                )
                                stroke.points.drop(1).forEach { point ->
                                    path.lineTo(point.x * size.width, point.y * size.height)
                                }
                                drawPath(
                                    path = path,
                                    color = stroke.color.copy(alpha = stroke.alpha),
                                    style = DrawStroke(width = stroke.width)
                                )
                            }
                    }
                }
            }
        }
        Text(
            "1 / $pages",
            Modifier.align(Alignment.CenterEnd).padding(6.dp),
            color = Color.White
        )
    }
}
