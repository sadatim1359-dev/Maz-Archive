package com.mazarchive.app

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.runtime.*
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.serialization.Serializable
import androidx.compose.ui.text.input.PasswordVisualTransformation
import java.net.URLDecoder
import java.net.URLEncoder
import com.mazarchive.app.data.ExamRepository
import com.mazarchive.app.network.ApiFactory
import com.mazarchive.app.network.AuthApiFactory
import com.mazarchive.app.network.LoginRequest
import kotlinx.coroutines.launch

@Serializable
data class Exam(
    val id: Long,
    val title: String,
    val grade: String,
    val field: String,
    val examNumber: Int? = null,
    val examDate: String,
    val year: Int,
    val period: String,
    val month: String,
    val pdfUrl: String
)

enum class PenTool { PEN, HIGHLIGHTER, ERASER }

data class Stroke(
    val id: String = java.util.UUID.randomUUID().toString(),
    val page: Int,
    val points: List<androidx.compose.ui.geometry.Offset>,
    val color: Color,
    val width: Float,
    val alpha: Float,
    val tool: PenTool
)

data class ExamQuestion(
    val id: Int,
    val text: String,
    val options: List<String>,
    val correct: Int
)

data class ExamResult(
    val answers: Map<Int, Int>,
    val usedSeconds: Int,
    val submittedByTime: Boolean
)

private fun sampleQuestions(count: Int = 20): List<ExamQuestion> =
    (1..count).map { n ->
        ExamQuestion(
            id = n,
            text = "سؤال $n: کدام گزینه پاسخ صحیح این سؤال نمونه است؟",
            options = listOf("گزینه اول", "گزینه دوم", "گزینه سوم", "گزینه چهارم"),
            correct = (n + 1) % 4
        )
    }

private fun persianNumber(value: Int): String =
    value.toString().map { ch -> "۰۱۲۳۴۵۶۷۸۹"[ch - '0'] }.joinToString("")

private fun formatTime(totalSeconds: Int): String {
    val m = (totalSeconds / 60).coerceAtLeast(0)
    val sec = (totalSeconds % 60).coerceAtLeast(0)
    return "${persianNumber(m)}:${sec.toString().padStart(2, '0').map { "۰۱۲۳۴۵۶۷۸۹"[it - '0'] }.joinToString("")}"
}

private object LatestExamResultHolder {
    var result: ExamResult? = null
}

private object ExamHistoryStore {
    fun save(context: android.content.Context, examId: Long, result: ExamResult, correct: Int, total: Int) {
        val prefs = context.getSharedPreferences("maz_exam_history", android.content.Context.MODE_PRIVATE)
        val old = prefs.getInt("count", 0)
        prefs.edit()
            .putInt("count", old + 1)
            .putInt("last_percent", correct * 100 / total)
            .putInt("last_correct", correct)
            .putInt("last_wrong", total - correct - (total - result.answers.size))
            .putInt("last_unanswered", total - result.answers.size)
            .putInt("last_used", result.usedSeconds)
            .putLong("last_exam_id", examId)
            .apply()
    }
    fun count(context: android.content.Context) =
        context.getSharedPreferences("maz_exam_history", android.content.Context.MODE_PRIVATE).getInt("count", 0)
}


private val Indigo = Color(0xFF7167E8)
private val Bg = Color(0xFF0B0B0F)
private val Card = Color(0xFF15151C)
private val LightBg = Color(0xFFF6F7FC)
private val LightCard = Color(0xFFFFFFFF)
private val LocalMazDark = compositionLocalOf { true }

@Composable
private fun mazBg() = if (LocalMazDark.current) Bg else LightBg

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { App() }
    }
}

@Composable
fun MazTheme(isDark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (isDark) darkColorScheme(
        primary = Indigo, background = Bg, surface = Card
    ) else lightColorScheme(
        primary = Indigo, background = LightBg, surface = LightCard,
        onBackground = Color(0xFF202236), onSurface = Color(0xFF202236)
    )
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(
            LocalLayoutDirection provides LayoutDirection.Rtl,
            LocalMazDark provides isDark
        ) { content() }
    }
}

@Composable
fun App() {
    var isDark by rememberSaveable { mutableStateOf(true) }
    MazTheme(isDark) { AppContent(isDark = isDark, onToggleTheme = { isDark = !isDark }) }
}

@Composable
private fun AppContent(isDark: Boolean, onToggleTheme: () -> Unit) {
    val nav = rememberNavController()
    val context = LocalContext.current
    val authStore = remember { com.mazarchive.app.data.AuthStore(context) }
    var showSplash by rememberSaveable { mutableStateOf(true) }
    var loggedIn by rememberSaveable { mutableStateOf(authStore.isLoggedIn()) }
    var registered by rememberSaveable { mutableStateOf(authStore.isRegistered()) }
    var showAdminLogin by rememberSaveable { mutableStateOf(false) }
    var role by rememberSaveable { mutableStateOf(authStore.role() ?: "USER") }
    var loginError by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(2600)
        showSplash = false
    }

    if (showSplash) {
        SplashScreen()
        return
    }

    if (!registered && !loggedIn && showAdminLogin) {
        LoginScreen(
            onLogin = { username, password ->
                scope.launch {
                    loginError = ""
                    if (username.trim() == "admin") {
                        runCatching {
                            AuthApiFactory.create(BuildConfig.API_BASE_URL)
                                .login(LoginRequest(username.trim(), password))
                        }.onSuccess { response ->
                            authStore.save(response.token, response.role, response.refreshToken)
                            role = response.role
                            loggedIn = true
                            showAdminLogin = false
                        }.onFailure {
                            loginError = "ورود مدیر ناموفق بود؛ آدرس سرور و رمز مدیر را بررسی کنید."
                        }
                    } else {
                        loginError = "برای ورود مدیر، نام کاربری admin را وارد کنید."
                    }
                }
            }
        )
        if (loginError.isNotBlank()) Text(loginError, color = Color(0xFFFF6B6B))
        return
    }

    if (!registered && !loggedIn) {
        RegisterScreen(
            onRegister = { username, password ->
                authStore.registerLocal(username, password)
                registered = true
                loggedIn = true
                role = "USER"
            },
            onAdminLogin = { showAdminLogin = true }
        )
        return
    }

    if (!loggedIn) {
        LoginScreen { username, password ->
            scope.launch {
                loginError = ""
                if (username.trim() == "admin") {
                    runCatching { AuthApiFactory.create(BuildConfig.API_BASE_URL).login(LoginRequest(username.trim(), password)) }
                        .onSuccess { response ->
                            authStore.save(response.token, response.role, response.refreshToken)
                            role = response.role
                            loggedIn = true
                        }.onFailure { loginError = "ورود ناموفق بود؛ آدرس سرور و رمز مدیر را بررسی کنید." }
                } else if (authStore.checkLocalCredentials(username.trim(), password)) {
                    authStore.save("local-session", "USER")
                    role = "USER"
                    loggedIn = true
                } else {
                    loginError = "نام کاربری یا رمز عبور نادرست است."
                }
            }
        }
        if (loginError.isNotBlank()) Text(loginError, color = Color(0xFFFF6B6B))
        return
    }

    if (role == "ADMIN") {
        AdminHome(onLogout = { authStore.clear(); loggedIn = false; role = "USER" })
        return
    }

    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            AppScaffold(nav, "home") {
                Home { grade -> nav.navigate("fields/${URLEncoder.encode(grade, "UTF-8")}") }
            }
        }
        composable("fields/{g}") { entry ->
            val grade = URLDecoder.decode(entry.arguments?.getString("g")!!, "UTF-8")
            AppScaffold(nav, "archive") {
                Fields(grade) { field ->
                    nav.navigate("archive/${URLEncoder.encode(grade, "UTF-8")}/${URLEncoder.encode(field, "UTF-8")}")
                }
            }
        }
        composable("archive/{g}/{f}") { entry ->
            val grade = URLDecoder.decode(entry.arguments?.getString("g")!!, "UTF-8")
            val field = URLDecoder.decode(entry.arguments?.getString("f")!!, "UTF-8")
            AppScaffold(nav, "archive") {
                Archive(grade, field) { id -> nav.navigate("exam/$id") }
            }
        }
        composable("exam/{id}") { entry ->
            ExamDetail(entry.arguments?.getString("id")!!.toLong()) { id ->
                nav.navigate("player/$id")
            }
        }
        composable("player/{id}") { entry ->
            val examId = entry.arguments?.getString("id")!!.toLong()
            ExamPlayer(examId) { result ->
                LatestExamResultHolder.result = result
                nav.navigate("result/$examId/0")
            }
        }
        composable("result/{id}/{unused}") { entry ->
            ExamResultScreen(
                examId = entry.arguments?.getString("id")!!.toLong(),
                onHome = { nav.navigate("home") { popUpTo("home") { inclusive = true } } }
            )
        }
        composable("search") {
            AppScaffold(nav, "search") { SearchScreen { grade, field ->
                nav.navigate("archive/${URLEncoder.encode(grade, "UTF-8")}/${URLEncoder.encode(field, "UTF-8")}")
            } }
        }
        composable("profile") { AppScaffold(nav, "profile") { ProfileScreen(isDark = isDark, onToggleTheme = onToggleTheme) } }
        composable("pdf/{url}") { entry ->
            PdfScreen(URLDecoder.decode(entry.arguments?.getString("url")!!, "UTF-8")) { nav.popBackStack() }
        }
    }
}

@Composable
fun AppScaffold(nav: androidx.navigation.NavHostController, selected: String, content: @Composable () -> Unit) {
    val dark = LocalMazDark.current
    val navBg = if (dark) Color(0xFF0D0F18) else Color.White
    val navText = if (dark) Color(0xFF8E91A3) else Color(0xFF4B5068)
    Scaffold(
        containerColor = mazBg(),
        bottomBar = {
            NavigationBar(containerColor = navBg, tonalElevation = 0.dp) {
                NavItem("⌂", "خانه", selected == "home", navText) { nav.navigate("home") { launchSingleTop = true; popUpTo("home") { saveState = true } } }
                NavItem("▣", "آرشیو", selected == "archive", navText) {
                    nav.navigate("fields/${URLEncoder.encode("دهم", "UTF-8")}") { launchSingleTop = true }
                }
                NavItem("⌕", "جستجو", selected == "search", navText) { nav.navigate("search") { launchSingleTop = true } }
                NavItem("♙", "پروفایل", selected == "profile", navText) { nav.navigate("profile") { launchSingleTop = true } }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) { content() }
    }
}

@Composable
fun RowScope.NavItem(icon: String, label: String, selected: Boolean, navText: Color, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { Text(icon, style = MaterialTheme.typography.titleLarge) },
        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = if (LocalMazDark.current) Color.White else Indigo,
            selectedTextColor = if (LocalMazDark.current) Color.White else Indigo,
            indicatorColor = Indigo.copy(alpha = if (LocalMazDark.current) 0.28f else 0.12f),
            unselectedIconColor = navText,
            unselectedTextColor = navText
        )
    )
}

@Composable
fun SplashScreen() {
    Box(
        Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.mipmap.ic_launcher),
            contentDescription = "Maz-Archive",
            modifier = Modifier
                .size(150.dp)
                .clip(RoundedCornerShape(38.dp))
        )
    }
}

@Composable
fun AdminHome(onLogout: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val api = remember { ApiFactory.create(BuildConfig.API_BASE_URL) { com.mazarchive.app.data.AuthStore(context).token() } }
    var section by rememberSaveable { mutableStateOf("exams") }
    var examTitle by rememberSaveable { mutableStateOf("") }
    var examYear by rememberSaveable { mutableStateOf("") }
    var examField by rememberSaveable { mutableStateOf("") }
    var examGrade by rememberSaveable { mutableStateOf("") }
    var examDate by rememberSaveable { mutableStateOf("2026-01-01") }
    var examMinutes by rememberSaveable { mutableStateOf("30") }
    var selectedExamId by rememberSaveable { mutableStateOf<Long?>(null) }
    var editingExamId by rememberSaveable { mutableStateOf<Long?>(null) }
    var questionText by rememberSaveable { mutableStateOf("") }
    var option1 by rememberSaveable { mutableStateOf("") }
    var option2 by rememberSaveable { mutableStateOf("") }
    var option3 by rememberSaveable { mutableStateOf("") }
    var option4 by rememberSaveable { mutableStateOf("") }
    var correct by rememberSaveable { mutableIntStateOf(0) }
    var adminExams by remember { mutableStateOf(listOf<com.mazarchive.app.network.AdminExamPayload>()) }
    var status by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    fun loadExams() = scope.launch {
        loading = true
        runCatching { api.adminExams() }
            .onSuccess { adminExams = it; status = "آزمون‌ها از سرور دریافت شدند." }
            .onFailure { status = "دریافت آزمون‌ها ناموفق بود." }
        loading = false
    }
    LaunchedEffect(Unit) { loadExams() }

    Column(Modifier.fillMaxSize().background(mazBg()).padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("داشبورد مدیریت", style = MaterialTheme.typography.headlineSmall, color = Indigo); Text("مدیریت محتوای Maz-Archive", color = Color(0xFFAAAEC0)) }
            TextButton(onClick = onLogout) { Text("خروج") }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = section == "exams", onClick = { section = "exams" }, label = { Text("آزمون‌ها") })
            FilterChip(selected = section == "questions", onClick = { section = "questions" }, label = { Text("سؤال‌ها") })
        }
        if (status.isNotBlank()) Text(status, color = Color(0xFFAAAEC0), modifier = Modifier.padding(vertical = 8.dp))
        if (section == "exams") {
            Text(if (editingExamId == null) "افزودن آزمون" else "ویرایش آزمون", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(examTitle, { examTitle = it }, Modifier.fillMaxWidth(), label = { Text("عنوان آزمون") }, singleLine = true)
            OutlinedTextField(examYear, { examYear = it }, Modifier.fillMaxWidth(), label = { Text("سال") }, singleLine = true)
            OutlinedTextField(examDate, { examDate = it }, Modifier.fillMaxWidth(), label = { Text("تاریخ میلادی (YYYY-MM-DD)") }, singleLine = true)
            OutlinedTextField(examGrade, { examGrade = it }, Modifier.fillMaxWidth(), label = { Text("پایه") }, singleLine = true)
            OutlinedTextField(examField, { examField = it }, Modifier.fillMaxWidth(), label = { Text("رشته") }, singleLine = true)
            OutlinedTextField(examMinutes, { examMinutes = it }, Modifier.fillMaxWidth(), label = { Text("مدت آزمون (دقیقه)") }, singleLine = true)
            Button(enabled = !loading, onClick = {
                val year = examYear.toIntOrNull(); val minutes = examMinutes.toIntOrNull()
                if (examTitle.isBlank() || year == null || minutes == null) { status = "عنوان، سال و مدت را درست وارد کنید." }
                else scope.launch {
                    loading = true
                    runCatching {
                        val payload = com.mazarchive.app.network.AdminExamPayload(id=editingExamId ?: 0, title=examTitle.trim(), grade=examGrade.trim(), field=examField.trim(), examDate=examDate, year=year, period="", month="", durationSeconds=minutes*60)
                        if (editingExamId == null) api.createAdminExam(payload) else api.updateAdminExam(editingExamId!!, payload)
                    }
                        .onSuccess { status = if (editingExamId == null) "آزمون در سرور ذخیره شد." else "آزمون ویرایش شد."; examTitle = ""; editingExamId = null; loadExams() }
                        .onFailure { status = "ذخیره آزمون ناموفق بود." }
                    loading = false
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("ذخیره آزمون در سرور") }
            Spacer(Modifier.height(12.dp))
            Text("آزمون‌های موجود در سرور", style = MaterialTheme.typography.titleMedium)
            if (adminExams.isEmpty()) Text("آزمونی یافت نشد.", color = Color(0xFFAAAEC0))
            else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(adminExams) { item -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Text(item.title); Text("شناسه: ${item.id} | سال: ${item.year}", color = Color(0xFFAAAEC0)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { editingExamId = item.id; examTitle = item.title; examYear = item.year.toString(); examGrade = item.grade; examField = item.field; examDate = item.examDate; examMinutes = (item.durationSeconds / 60).toString() }) { Text("ویرایش") }
                            TextButton(onClick = { scope.launch { loading = true; runCatching { api.deleteAdminExam(item.id) }.onSuccess { status = "آزمون حذف شد."; loadExams() }.onFailure { status = "حذف آزمون ناموفق بود." }; loading = false } }) { Text("حذف") }
                            TextButton(onClick = { selectedExamId = item.id; section = "questions" }) { Text("افزودن سؤال") }
                        } } } } }
        } else {
            Text("افزودن سؤال", style = MaterialTheme.typography.titleLarge)
            Text("آزمون انتخاب‌شده: ${selectedExamId ?: "ابتدا از بخش آزمون‌ها انتخاب کنید"}", color = Color(0xFFAAAEC0))
            OutlinedTextField(questionText, { questionText = it }, Modifier.fillMaxWidth(), label = { Text("متن سؤال") })
            OutlinedTextField(option1, { option1 = it }, Modifier.fillMaxWidth(), label = { Text("گزینه ۱") }, singleLine = true)
            OutlinedTextField(option2, { option2 = it }, Modifier.fillMaxWidth(), label = { Text("گزینه ۲") }, singleLine = true)
            OutlinedTextField(option3, { option3 = it }, Modifier.fillMaxWidth(), label = { Text("گزینه ۳") }, singleLine = true)
            OutlinedTextField(option4, { option4 = it }, Modifier.fillMaxWidth(), label = { Text("گزینه ۴") }, singleLine = true)
            Text("گزینه صحیح")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { (0..3).forEach { i -> FilterChip(selected = correct == i, onClick = { correct = i }, label = { Text("${i + 1}") }) } }
            Button(enabled = selectedExamId != null && questionText.isNotBlank(), onClick = {
                val id = selectedExamId ?: return@Button
                scope.launch {
                    loading = true
                    val options = listOf(option1, option2, option3, option4).filter { it.isNotBlank() }
                    runCatching { api.createAdminQuestion(id, QuestionDto(examId=id, number=1, text=questionText, options=options, correctIndex=correct.coerceAtMost(options.lastIndex))) }
                        .onSuccess { status = "سؤال در سرور ذخیره شد."; questionText = "" }
                        .onFailure { status = "ذخیره سؤال ناموفق بود." }
                    loading = false
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("ذخیره سؤال در سرور") }
        }
    }
}

@Composable
fun RegisterScreen(onRegister: (String, String) -> Unit, onAdminLogin: () -> Unit = {}) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize().background(mazBg())) {
        Column(
            Modifier.fillMaxWidth().align(Alignment.Center).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(id = R.mipmap.ic_launcher),
                contentDescription = "Maz-Archive",
                modifier = Modifier.size(104.dp).clip(RoundedCornerShape(28.dp))
            )
            Text("Maz-Archive", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Indigo)
            Text("ثبت‌نام در آرشیو", style = MaterialTheme.typography.titleLarge)
            Text("برای اولین ورود، حساب خودت را بساز", color = Color(0xFFAAAEC0))

            OutlinedTextField(
                value = user,
                onValueChange = { user = it; error = "" },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("نام کاربری") },
                singleLine = true,
                shape = RoundedCornerShape(18.dp)
            )
            OutlinedTextField(
                value = pass,
                onValueChange = { pass = it; error = "" },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("رمز عبور") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(18.dp)
            )
            OutlinedTextField(
                value = confirm,
                onValueChange = { confirm = it; error = "" },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("تکرار رمز عبور") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(18.dp)
            )
            if (error.isNotBlank()) Text(error, color = Color(0xFFFF6B6B))
            Button(
                onClick = {
                    when {
                        user.trim().length < 3 -> error = "نام کاربری حداقل ۳ حرف باشد"
                        pass.length < 4 -> error = "رمز عبور حداقل ۴ کاراکتر باشد"
                        pass != confirm -> error = "رمزهای عبور یکسان نیستند"
                        else -> onRegister(user.trim(), pass)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = user.isNotBlank() && pass.isNotBlank() && confirm.isNotBlank(),
                shape = RoundedCornerShape(16.dp)
            ) { Text("ساخت حساب و ورود") }

            OutlinedButton(
                onClick = onAdminLogin,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("ورود مدیر")
            }
        }
    }
}

@Composable
fun LoginScreen(onLogin: (String, String) -> Unit) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(mazBg())) {
        Column(
            Modifier.fillMaxWidth().align(Alignment.Center).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(id = R.mipmap.ic_launcher),
                contentDescription = "Maz-Archive",
                modifier = Modifier
                    .size(104.dp)
                    .clip(RoundedCornerShape(28.dp))
            )
            Text(
                "Maz-Archive",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = Indigo
            )
            Text("آرشیو آزمون‌ها و منابع آموزشی", color = Color(0xFFAAAEC0))
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = user,
                onValueChange = { user = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("نام کاربری") },
                shape = RoundedCornerShape(18.dp)
            )
            OutlinedTextField(
                value = pass,
                onValueChange = { pass = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("رمز عبور") },
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(18.dp)
            )
            Button(
                onClick = {
                    val u = user.trim()
                    if (u.isNotBlank() && pass.isNotBlank()) {
                        error = false
                        onLogin(u, pass)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = user.isNotBlank() && pass.isNotBlank(),
                shape = RoundedCornerShape(16.dp)
            ) { Text("ورود به آرشیو") }
            if (error) Text("نام کاربری یا رمز عبور نادرست است", color = Color(0xFFFF6B6B))
        }
    }
}

@Composable
fun Home(onGrade: (String) -> Unit) {
    val dark = LocalMazDark.current
    val primaryText = if (dark) Color(0xFFF4F2FF) else Color(0xFF151827)
    val secondaryText = if (dark) Color(0xFF9EA2B4) else Color(0xFF68708A)
    val examCard = if (dark) Color(0xFF171B3A) else Color(0xFFF1F0FF)
    val gradeCard = if (dark) Color(0xFF131827) else Color.White
    val grades = listOf(
        Triple("دهم", "۲۴ آزمون", Color(0xFF10C99A)),
        Triple("یازدهم", "۱۸ آزمون", Color(0xFF2686FF)),
        Triple("دوازدهم", "۳۲ آزمون", Color(0xFF8247FF))
    )
    Column(Modifier.fillMaxSize().background(mazBg()).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(id = R.mipmap.ic_launcher), "Maz-Archive", Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)))
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("Maz-Archive", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = primaryText)
                Text("آرشیو هوشمند آزمون‌ها", color = secondaryText, style = MaterialTheme.typography.bodySmall)
            }
            Surface(shape = CircleShape, color = if (dark) Color(0xFF171C31) else Color(0xFFEDEBFF)) { Text("M", Modifier.padding(horizontal = 13.dp, vertical = 9.dp), color = Indigo, fontWeight = FontWeight.Bold) }
        }
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("سلام، کاربر عزیز 👋", color = secondaryText)
            Text("آماده‌ای برای آزمون بعدی؟", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = primaryText)
        }
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = examCard), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(Modifier.size(52.dp), RoundedCornerShape(16.dp), color = Indigo.copy(alpha = .22f)) { Box(contentAlignment = Alignment.Center) { Text("✦", color = Indigo, style = MaterialTheme.typography.headlineSmall) } }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("جدیدترین آزمون", color = if (dark) Color(0xFFC3BEFF) else Indigo, style = MaterialTheme.typography.labelLarge)
                        Text("آزمون مرحله دوم", fontWeight = FontWeight.Bold, color = primaryText)
                        Text("یازدهم • ریاضی • شیمی", color = secondaryText, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("۳۰ سوال", color = secondaryText, style = MaterialTheme.typography.labelSmall)
                    Text("۱۵ آبان ۱۴۰۴", color = Indigo, style = MaterialTheme.typography.labelSmall)
                }
                Button(onClick = { onGrade("یازدهم") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("مشاهده آزمون  →") }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text("پایه‌های تحصیلی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = primaryText)
                Text("پایه موردنظر را انتخاب کن", color = secondaryText, style = MaterialTheme.typography.bodySmall)
            }
            Text("۳ پایه", color = secondaryText, style = MaterialTheme.typography.labelSmall)
        }
        grades.forEach { (grade, count, accent) ->
            Card(Modifier.fillMaxWidth().clickable { onGrade(grade) }, RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = gradeCard)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(Modifier.size(58.dp), RoundedCornerShape(18.dp), color = accent.copy(alpha = if (dark) .15f else .12f)) { Box(contentAlignment = Alignment.Center) { Text("🎓", style = MaterialTheme.typography.titleLarge) } }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("پایه $grade", fontWeight = FontWeight.Bold, color = primaryText)
                        Text(count, color = accent, style = MaterialTheme.typography.labelLarge)
                        Text("آزمون‌های این پایه", color = secondaryText, style = MaterialTheme.typography.bodySmall)
                    }
                    Text("›", color = accent, style = MaterialTheme.typography.headlineMedium)
                }
            }
        }
        Text("Maz-Archive  •  نسخه 1.0.0", Modifier.fillMaxWidth(), color = secondaryText, textAlign = androidx.compose.ui.text.style.TextAlign.Center, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun Fields(grade: String, onField: (String) -> Unit) {
    Column(Modifier.fillMaxSize().background(mazBg()).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("انتخاب رشته", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("پایه $grade", color = Color(0xFF9EA2B4))
        Spacer(Modifier.height(4.dp))
        listOf("ریاضی" to Color(0xFF2686FF), "تجربی" to Color(0xFF10C99A), "انسانی" to Color(0xFF8247FF)).forEach { (field, accent) ->
            Card(Modifier.fillMaxWidth().clickable { onField(field) }, RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A))) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(Modifier.size(52.dp), RoundedCornerShape(16.dp), color = accent.copy(alpha = .16f)) { Box(contentAlignment = Alignment.Center) { Text("◆", color = accent) } }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) { Text("رشته $field", fontWeight = FontWeight.Bold); Text("مشاهده آزمون‌های $grade", color = Color(0xFF8F94A8), style = MaterialTheme.typography.bodySmall) }
                    Text("›", color = accent, style = MaterialTheme.typography.headlineMedium)
                }
            }
        }
    }
}

@Composable
fun Archive(grade: String, field: String, open: (Long) -> Unit) {
    var q by remember { mutableStateOf("") }
    var year by remember { mutableStateOf<Int?>(null) }
    var period by remember { mutableStateOf<String?>(null) }
    var month by remember { mutableStateOf<String?>(null) }
    var showFilter by remember { mutableStateOf(false) }
    val data = remember(grade, field, q, year, period, month) {
        (1..18).map { n -> Exam(n.toLong(), "آزمون $n", grade, field, n, "۱۴۰۴/۰۸/${(25 - n).coerceAtLeast(1)}", 1404, "شروع از مهر", "آبان", "") }
            .filter { q.isBlank() || it.title.contains(q) || it.examDate.contains(q) }
            .filter { year == null || it.year == year }
    }
    Column(Modifier.fillMaxSize().background(mazBg()).padding(horizontal = 16.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("آزمون‌های $grade", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("$field", color = Indigo) }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("نام آزمون، درس یا تاریخ...") }, leadingIcon = { Text("⌕") }, shape = RoundedCornerShape(16.dp))
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("همه", "تخصصی", "عمومی").forEachIndexed { i, label -> FilterChip(selected = (i == 0 && !showFilter) || (i == 1 && showFilter), onClick = { showFilter = i == 1 }, label = { Text(label) }) }
            Spacer(Modifier.weight(1f)); TextButton(onClick = { showFilter = !showFilter }) { Text("فیلتر ☷") }
        }
        if (showFilter) FilterPanel(year, { year = it }, period, { period = it }, month, { month = it })
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(data) { exam ->
                Card(Modifier.fillMaxWidth().clickable { open(exam.id) }, RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A))) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(Modifier.size(48.dp), RoundedCornerShape(14.dp), color = Indigo.copy(alpha = .15f)) { Box(contentAlignment = Alignment.Center) { Text("▤", color = Indigo) } }
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) { Text("${exam.title} • $field", fontWeight = FontWeight.SemiBold); Text("${exam.examDate}  •  ۳۰ سوال", color = Color(0xFF858B9F), style = MaterialTheme.typography.bodySmall) }
                        Text("›", color = Indigo, style = MaterialTheme.typography.headlineSmall)
                    }
                }
            }
        }
    }
}

@Composable
fun SearchScreen(open: (String, String) -> Unit) {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(mazBg()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("جستجو", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("آزمون موردنظرت را سریع پیدا کن", color = Color(0xFF969BAD))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("نام آزمون، درس یا پایه...") }, leadingIcon = { Text("⌕") }, shape = RoundedCornerShape(17.dp))
        Text("فیلترهای سریع", fontWeight = FontWeight.Bold)
        listOf("دهم • ریاضی", "یازدهم • فیزیک", "دوازدهم • شیمی").forEach { label ->
            val parts = label.split(" • ")
            Card(Modifier.fillMaxWidth().clickable { open(parts[0], parts[1]) }, RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A))) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text("⌕", color = Indigo); Spacer(Modifier.width(12.dp)); Text(label, Modifier.weight(1f)); Text("›", color = Indigo) }
            }
        }
    }
}

@Composable
fun ProfileScreen(isDark: Boolean, onToggleTheme: () -> Unit) {
    val dark = LocalMazDark.current
    val panel = if (dark) Color(0xFF141A2A) else Color.White
    val softPanel = if (dark) Color(0xFF111622) else Color(0xFFEDEFFC)
    val primaryText = if (dark) Color(0xFFF4F2FF) else Color(0xFF202236)
    val secondaryText = if (dark) Color(0xFF8E94A8) else Color(0xFF68708A)
    Column(Modifier.fillMaxSize().background(mazBg()).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("پروفایل", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = primaryText)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onToggleTheme) {
                Text(if (isDark) "☀" else "☾", color = if (isDark) Color(0xFFFFD76A) else Indigo, style = MaterialTheme.typography.headlineSmall)
            }
        }
        Card(Modifier.fillMaxWidth(), RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = panel)) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(Modifier.size(70.dp), CircleShape, color = Color(0xFF1D5FEA)) { Box(contentAlignment = Alignment.Center) { Text("م", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("کاربر Maz-Archive", fontWeight = FontWeight.Bold, color = primaryText, style = MaterialTheme.typography.titleMedium)
                    Text("حساب کاربری شما", color = secondaryText, style = MaterialTheme.typography.bodySmall)
                }
                Text("›", color = Indigo, style = MaterialTheme.typography.headlineMedium)
            }
        }
        Card(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = if (dark) Color(0xFF171B3A) else Color(0xFFE8E7FF))) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("تاریخچه آزمون", fontWeight = FontWeight.Bold, color = primaryText, style = MaterialTheme.typography.titleMedium)
                Text("${persianNumber(ExamHistoryStore.count(LocalContext.current))} آزمون ثبت‌شده", color = Indigo, style = MaterialTheme.typography.bodyMedium)
                Text("مرور آزمون‌های قبلی شما", color = secondaryText, style = MaterialTheme.typography.bodySmall)
            }
        }
        listOf("حالت نمایش" to (if (isDark) "تاریک" else "روشن"), "اطلاعات برنامه" to "نسخه ۱.۰.۰", "درباره ما" to "آشنایی با Maz-Archive", "تماس با ما" to "پشتیبانی و ارتباط").forEach { (title, subtitle) ->
            Card(Modifier.fillMaxWidth().clickable { if (title == "حالت نمایش") onToggleTheme() }, RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = softPanel)) {
                Row(Modifier.padding(horizontal = 17.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(title, color = primaryText, fontWeight = FontWeight.SemiBold)
                        Text(subtitle, color = secondaryText, style = MaterialTheme.typography.bodySmall)
                    }
                    Text("›", color = Indigo, style = MaterialTheme.typography.headlineSmall)
                }
            }
        }
        OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(17.dp)) { Text("خروج از حساب", color = Color(0xFFFF6B7A), fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun FilterPanel(
    year: Int?, setYear: (Int?) -> Unit,
    period: String?, setPeriod: (String?) -> Unit,
    month: String?, setMonth: (String?) -> Unit
) {
    Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), color = Color(0xFF111522)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("فیلتر آزمون‌ها", fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(1404, 1403, 1402).forEach { value -> FilterChip(year == value, { setYear(if (year == value) null else value) }, label = { Text(value.toString()) }) } }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("تابستانه", "شروع از مهر").forEach { value -> FilterChip(period == value, { setPeriod(if (period == value) null else value) }, label = { Text(value) }) } }
            val months = if (period == "تابستانه") listOf("تیر", "مرداد", "شهریور") else listOf("مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) { months.forEach { value -> FilterChip(month == value, { setMonth(if (month == value) null else value) }, label = { Text(value) }) } }
        }
    }
}

@Composable
fun ExamDetail(id: Long, startExam: (Long) -> Unit) {
    Column(
        Modifier.fillMaxSize().background(mazBg()).verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("جزئیات آزمون", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(
            Modifier.fillMaxWidth(),
            RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171B3A))
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("آزمون شماره $id", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("یازدهم • ریاضی", color = Color(0xFFB7BBCE))
                Text("۲۰ سؤال • مدت ۳۰ دقیقه", color = Color(0xFF8D93A8), style = MaterialTheme.typography.bodySmall)
                LinearProgressIndicator(
                    progress = { .25f },
                    modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(10.dp)),
                    color = Indigo,
                    trackColor = Color(0xFF2A2D3B)
                )
                Text("آزمون تعاملی داخل برنامه", color = Color(0xFFBDB4FF), style = MaterialTheme.typography.labelSmall)
            }
        }
        Button(
            onClick = { startExam(id) },
            Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("شروع آزمون  ▶", style = MaterialTheme.typography.titleMedium) }
        OutlinedButton(
            onClick = { startExam(id) },
            Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("شروع دوباره آزمون") }
        Text("نحوه برگزاری", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(
            "سؤال‌ها داخل برنامه نمایش داده می‌شوند. زمان آزمون واقعی است، می‌توانی سؤال‌ها را علامت‌گذاری کنی و بین همه سؤال‌ها جابه‌جا شوی. با پایان زمان، آزمون به‌صورت خودکار ثبت می‌شود.",
            color = Color(0xFF989DAF)
        )
    }
}

@Composable
fun ExamPlayer(examId: Long, onFinished: (ExamResult) -> Unit) {
    val context = LocalContext.current
    val authStore = remember { com.mazarchive.app.data.AuthStore(context) }
    val repository = remember {
        ExamRepository(
            ApiFactory.create(BuildConfig.API_BASE_URL) { authStore.token() },
            MazDb.get(context)
        )
    }
    var questions by remember(examId) { mutableStateOf<List<ExamQuestion>>(emptyList()) }
    var loading by remember(examId) { mutableStateOf(true) }
    var loadError by remember(examId) { mutableStateOf<String?>(null) }
    LaunchedEffect(examId) {
        loading = true
        loadError = null
        runCatching { repository.questions(examId) }
            .onSuccess { remote ->
                questions = remote.sortedBy { it.number }.map { dto ->
                    ExamQuestion(dto.id.toInt(), dto.text, dto.options, dto.correctIndex)
                }
                if (questions.isEmpty()) loadError = "برای این آزمون هنوز سؤالی ثبت نشده است."
            }
            .onFailure { loadError = it.message ?: "دریافت سؤال‌ها ناموفق بود." }
        loading = false
    }
    if (loading) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }
    if (loadError != null || questions.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(loadError ?: "سؤالی برای نمایش وجود ندارد.", textAlign = TextAlign.Center)
        }
        return
    }
    var current by rememberSaveable { mutableIntStateOf(0) }
    var remaining by rememberSaveable { mutableIntStateOf(30 * 60) }
    var submitted by rememberSaveable { mutableStateOf(false) }
    var warningShown by rememberSaveable { mutableStateOf(false) }
    var showGrid by remember { mutableStateOf(false) }
    var showEndDialog by remember { mutableStateOf(false) }
    var startedSeconds by rememberSaveable { mutableIntStateOf(30 * 60) }
    val startedAtMillis = rememberSaveable { android.os.SystemClock.elapsedRealtime() }
    val answers = remember { mutableStateMapOf<Int, Int>() }
    var flagged by remember { mutableStateOf(setOf<Int>()) }
    fun finish(byTime: Boolean) {
        if (submitted) return
        submitted = true
        val finalResult = ExamResult(
            answers = answers.toMap(),
            usedSeconds = (startedSeconds - remaining).coerceIn(0, startedSeconds),
            submittedByTime = byTime
        )
        val correct = questions.count { finalResult.answers[it.id] == it.correct }
        ExamHistoryStore.save(context, examId, finalResult, correct, questions.size)
        onFinished(finalResult)
    }

    LaunchedEffect(Unit) {
        while (!submitted && remaining > 0) {
            kotlinx.coroutines.delay(250)
            if (!submitted) {
                val elapsed = ((android.os.SystemClock.elapsedRealtime() - startedAtMillis) / 1000L).toInt()
                remaining = (startedSeconds - elapsed).coerceAtLeast(0)
            }
        }
        if (!submitted && remaining <= 0) finish(true)
    }

    LaunchedEffect(remaining) {
        if (remaining == 300 && !warningShown && !submitted) warningShown = true
    }

    val q = questions[current]
    val selected = answers[q.id]

    Column(Modifier.fillMaxSize().background(mazBg())) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("ریاضی دهم", fontWeight = FontWeight.Bold)
                Text("سؤال ${persianNumber(current + 1)} از ${persianNumber(questions.size)}", color = Color(0xFF8E94A8), style = MaterialTheme.typography.labelSmall)
            }
            Surface(
                shape = RoundedCornerShape(13.dp),
                color = if (remaining <= 300) Color(0xFF4A1D2A) else Color(0xFF191633)
            ) {
                Text(
                    "⏱ ${formatTime(remaining)}",
                    Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    color = if (remaining <= 300) Color(0xFFFF7183) else Color(0xFFC1B9FF),
                    fontWeight = FontWeight.Bold
                )
            }
        }

        LinearProgressIndicator(
            progress = { (current + 1).toFloat() / questions.size },
            Modifier.fillMaxWidth().padding(horizontal = 14.dp).height(7.dp).clip(RoundedCornerShape(10.dp)),
            color = Indigo,
            trackColor = Color(0xFF26283A)
        )

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("${persianNumber((current + 1) * 100 / questions.size)}٪", color = Color(0xFFBDB4FF), style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { flagged = flagged + q.id; showGrid = true }) {
                Text(if (flagged.contains(q.id)) "★ علامت‌گذاری شد" else "☆ علامت‌گذاری")
            }
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                Modifier.fillMaxWidth(),
                RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF151A31))
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("سؤال ${persianNumber(q.id)}", color = Color(0xFFBDB4FF), style = MaterialTheme.typography.labelLarge)
                    Text(q.text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
            }
            q.options.forEachIndexed { index, option ->
                val isSelected = selected == index
                Card(
                    Modifier.fillMaxWidth().clickable { answers[q.id] = index },
                    RoundedCornerShape(17.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFF30265D) else Color(0xFF121722)
                    )
                ) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            Modifier.size(38.dp),
                            CircleShape,
                            color = if (isSelected) Indigo else Color(0xFF252A39)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    "${persianNumber(index + 1)}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(option, Modifier.weight(1f))
                        if (isSelected) Text("✓", color = Color(0xFFBEB5FF), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = { if (current > 0) current-- },
                enabled = current > 0,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp)
            ) { Text("قبلی") }
            OutlinedButton(
                onClick = { showGrid = true },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp)
            ) { Text("سؤال‌ها") }
            Button(
                onClick = { if (current < questions.lastIndex) current++ else showEndDialog = true },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp)
            ) { Text(if (current == questions.lastIndex) "پایان" else "بعدی") }
        }
    }

    if (warningShown) {
        AlertDialog(
            onDismissRequest = { warningShown = false },
            title = { Text("⏰ زمان رو به پایان است") },
            text = { Text("فقط ۵ دقیقه از زمان آزمون باقی مانده است.") },
            confirmButton = {
                Button(onClick = { warningShown = false }) { Text("متوجه شدم") }
            }
        )
    }

    if (showGrid) {
        AlertDialog(
            onDismissRequest = { showGrid = false },
            title = { Text("جابجایی بین سؤال‌ها") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("● پاسخ داده شده   ○ بی‌پاسخ   ★ علامت‌گذاری شده", color = Color(0xFF969BAD), style = MaterialTheme.typography.bodySmall)
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(5),
                        modifier = Modifier.fillMaxWidth().height(270.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(questions) { index, item ->
                            val answered = answers.containsKey(item.id)
                            val marked = flagged.contains(item.id)
                            OutlinedButton(
                                onClick = { current = index; showGrid = false },
                                shape = RoundedCornerShape(11.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(
                                    if (marked) "★${persianNumber(index + 1)}" else persianNumber(index + 1),
                                    color = if (answered) Color(0xFFBDB4FF) else Color.White
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showGrid = false }) { Text("بستن") } }
        )
    }

    if (showEndDialog) {
        val unanswered = questions.count { !answers.containsKey(it.id) }
        AlertDialog(
            onDismissRequest = { showEndDialog = false },
            title = { Text("پایان آزمون؟") },
            text = {
                Text(
                    if (unanswered == 0)
                        "همه سؤال‌ها پاسخ داده شده‌اند. آزمون ثبت شود؟"
                    else
                        "${persianNumber(unanswered)} سؤال بی‌پاسخ مانده است. می‌خواهی آزمون را ثبت کنی؟"
                )
            },
            dismissButton = { TextButton(onClick = { showEndDialog = false }) { Text("ادامه آزمون") } },
            confirmButton = { Button(onClick = { showEndDialog = false; finish(false) }) { Text("ثبت آزمون") } }
        )
    }
}

@Composable
fun ExamResultScreen(examId: Long, onHome: () -> Unit) {
    var showReview by rememberSaveable { mutableStateOf(false) }
    val questions = remember(examId) { sampleQuestions(20) }
    val result = LatestExamResultHolder.result
    val correct = remember(result) {
        if (result == null) 0 else questions.count { result.answers[it.id] == it.correct }
    }
    val unanswered = remember(result) {
        if (result == null) questions.size else questions.count { !result.answers.containsKey(it.id) }
    }
    val wrong = questions.size - correct - unanswered
    val percent = correct * 100 / questions.size

    if (showReview) {
        Column(
            Modifier.fillMaxSize().background(mazBg()).verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("مرور پاسخ‌ها", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("آزمون شماره $examId", color = Color(0xFF979CAF))
            questions.forEach { q ->
                Card(
                    Modifier.fillMaxWidth(),
                    RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A))
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("سؤال ${persianNumber(q.id)}", color = Color(0xFFBDB4FF), fontWeight = FontWeight.Bold)
                        Text(q.text)
                        val chosen = result?.answers?.get(q.id)
                        Text(
                            "پاسخ شما: ${if (chosen == null) "بی‌پاسخ" else q.options[chosen]}",
                            color = if (chosen == q.correct) Color(0xFF8FE3C0) else Color(0xFFFF9AA7),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text("پاسخ صحیح: ${q.options[q.correct]}", color = Color(0xFF8FE3C0), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Button(onClick = onHome, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) { Text("بازگشت به خانه") }
        }
        return
    }

    Column(
        Modifier.fillMaxSize().background(mazBg()).verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("آزمون به پایان رسید", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(
            Modifier.fillMaxWidth(),
            RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171B3A))
        ) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ریاضی دهم", color = Color(0xFFB8B0FF))
                Text("$percent٪", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, color = Color(0xFFD1CAFF))
                Text("امتیاز آزمون", color = Color(0xFF8F94A8))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ResultStat("صحیح", correct.toString(), Color(0xFF76E1B4), Modifier.weight(1f))
            ResultStat("غلط", wrong.toString(), Color(0xFFFF7585), Modifier.weight(1f))
            ResultStat("بی‌پاسخ", unanswered.toString(), Color(0xFFFFC86B), Modifier.weight(1f))
        }
        ResultStat(
            "زمان استفاده‌شده",
            formatTime(result?.usedSeconds ?: 0),
            Color(0xFFBDB4FF),
            Modifier.fillMaxWidth()
        )
        Button(onClick = { showReview = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
            Text("مشاهده پاسخ‌ها")
        }
        OutlinedButton(onClick = onHome, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
            Text("بازگشت به خانه")
        }
    }
}

@Composable
fun ResultStat(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF141A2A))) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = color, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(label, color = Color(0xFF8E94A8), style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun PdfScreen(url: String, onBack: () -> Unit) {
    var file by remember { mutableStateOf<java.io.File?>(null) }
    var tool by remember { mutableStateOf(PenTool.PEN) }
    var width by remember { mutableFloatStateOf(5f) }
    var color by remember { mutableStateOf(Color.Red) }
    var tools by remember { mutableStateOf(false) }
    var strokes by remember { mutableStateOf(listOf<Stroke>()) }
    var redo by remember { mutableStateOf(listOf<Stroke>()) }

    LaunchedEffect(url) {
        file = runCatching {
            val f = java.io.File.createTempFile("maz-", ".pdf")
            java.net.URL(url).openStream().use { input ->
                f.outputStream().use { output -> input.copyTo(output) }
            }
            f
        }.getOrNull()
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(
            Modifier.fillMaxWidth().height(48.dp).background(Color(0xFF101014)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("←") }
            TextButton(onClick = { tools = !tools }) { Text("✏️") }
            TextButton(
                onClick = {
                    val last = strokes.last()
                    strokes = strokes.dropLast(1)
                    redo = redo + last
                },
                enabled = strokes.isNotEmpty()
            ) { Text("↶") }
            TextButton(
                onClick = {
                    val last = redo.last()
                    redo = redo.dropLast(1)
                    strokes = strokes + last
                },
                enabled = redo.isNotEmpty()
            ) { Text("↷") }
        }
        if (tools) {
            Surface(color = Color(0xFF17171D)) {
                Column(Modifier.padding(10.dp)) {
                    Row {
                        listOf(
                            PenTool.PEN to "قلم",
                            PenTool.HIGHLIGHTER to "هایلایتر",
                            PenTool.ERASER to "پاک‌کن"
                        ).forEach { (t, label) ->
                            FilterChip(
                                selected = tool == t,
                                onClick = { tool = t; tools = false },
                                label = { Text(label) }
                            )
                        }
                    }
                    Row {
                        listOf(3f to "نازک", 6f to "متوسط", 12f to "ضخیم").forEach { (w, label) ->
                            FilterChip(
                                selected = width == w,
                                onClick = { width = w },
                                label = { Text(label) }
                            )
                        }
                    }
                    Row {
                        listOf(
                            Color.Black to "مشکی",
                            Color.Red to "قرمز",
                            Color.Blue to "آبی",
                            Color.Green to "سبز"
                        ).forEach { (c, label) ->
                            FilterChip(
                                selected = color == c,
                                onClick = { color = c },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }
        }
        file?.let { pdfFile ->
            PdfCanvas(pdfFile, strokes, { stroke ->
                strokes = strokes + stroke
                redo = emptyList()
            }, tool, width, color)
        } ?: Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) { CircularProgressIndicator() }
    }
}

@Composable
fun PdfCanvas(
    file: java.io.File,
    strokes: List<Stroke>,
    add: (Stroke) -> Unit,
    tool: PenTool,
    width: Float,
    color: Color
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    val renderer = remember(file) {
        PdfRenderer(ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY))
    }
    DisposableEffect(renderer) {
        onDispose { renderer.close() }
    }
    val pages = renderer.pageCount
    val bitmaps = remember(file) {
        (0 until pages).map { pageIndex ->
            renderer.openPage(pageIndex).let { page ->
                Bitmap.createBitmap(page.width, page.height, Bitmap.Config.ARGB_8888).also { bitmap ->
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()
                }
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 4f)
                    offset += pan
                }
            }
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
        ) {
            bitmaps.forEachIndexed { pageIndex, bitmap ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Canvas(
                        Modifier
                            .matchParentSize()
                            .pointerInput(tool, width, color, pageIndex) {
                                val points = mutableListOf<androidx.compose.ui.geometry.Offset>()
                                awaitPointerEventScope {
                                    while (true) {
                                        val event = awaitPointerEvent()
                                        if (event.changes.size == 1 && event.changes[0].pressed) {
                                            val change = event.changes[0]
                                            points += androidx.compose.ui.geometry.Offset(
                                                (change.position.x / size.width).coerceIn(0f, 1f),
                                                (change.position.y / size.height).coerceIn(0f, 1f)
                                            )
                                        } else if (points.isNotEmpty()) {
                                            add(
                                                Stroke(
                                                    page = pageIndex,
                                                    points = points.toList(),
                                                    color = if (tool == PenTool.ERASER) Color.Transparent else color,
                                                    width = width,
                                                    alpha = if (tool == PenTool.HIGHLIGHTER) 0.35f else 1f,
                                                    tool = tool
                                                )
                                            )
                                            points.clear()
                                        }
                                    }
                                }
                            }
                    ) {
                        strokes
                            .filter { it.page == pageIndex && it.points.size > 1 }
                            .forEach { stroke ->
                                val path = Path()
                                path.moveTo(
                                    stroke.points[0].x * size.width,
                                    stroke.points[0].y * size.height
                                )
                                stroke.points.drop(1).forEach { point ->
                                    path.lineTo(point.x * size.width, point.y * size.height)
                                }
                                drawPath(
                                    path = path,
                                    color = stroke.color.copy(alpha = stroke.alpha),
                                    style = DrawStroke(width = stroke.width)
                                )
                            }
                    }
                }
            }
        }
        Text(
            "1 / $pages",
            Modifier.align(Alignment.CenterEnd).padding(6.dp),
            color = Color.White
        )
    }
}
