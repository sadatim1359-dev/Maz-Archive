package com.mazarchive

import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.response.*
import io.ktor.server.request.*
import io.ktor.server.routing.*
import io.ktor.server.http.content.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.auth.*
import io.ktor.server.auth.jwt.*
import io.ktor.http.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.javatime.*
import java.io.File
import java.time.Instant
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import java.util.Base64

object Exams:Table("exams"){
 val id=long("id").autoIncrement();val title=text("title");val grade=text("grade");val field=text("field");val examNumber=integer("exam_number").nullable()
 val examDate=date("exam_date");val year=integer("year");val period=text("period");val month=text("month");val description=text("description").default("");val pdfUrl=text("pdf_url")
 val durationSeconds=integer("duration_seconds").default(1800)
 val createdAt=timestamp("created_at");val updatedAt=timestamp("updated_at");override val primaryKey=PrimaryKey(id)
}
object Questions:Table("questions"){
 val id=long("id").autoIncrement()
 val examId=long("exam_id").references(Exams.id, onDelete=ReferenceOption.CASCADE)
 val number=integer("number")
 val text=text("question_text")
 val options=text("options_json")
 val correctIndex=integer("correct_index")
 val createdAt=timestamp("created_at")
 val updatedAt=timestamp("updated_at")
 override val primaryKey=PrimaryKey(id)
}

object Annotations:Table("annotations"){
 val id=uuid("id");val userId=uuid("user_id");val examId=long("exam_id");val pageNumber=integer("page_number");val type=text("type")
 val content=text("content").nullable();val position=text("position");val color=text("color");val thickness=float("thickness")
 val createdAt=timestamp("created_at");val updatedAt=timestamp("updated_at");override val primaryKey=PrimaryKey(id)
}
@Serializable data class ExamDto(val id:Long,val title:String,val grade:String,val field:String,val examNumber:Int?=null,val examDate:String,val year:Int,val period:String,val month:String,val description:String="",val pdfUrl:String,val durationSeconds:Int=1800)
@Serializable data class QuestionDto(
    val id:Long=0,
    val examId:Long,
    val number:Int,
    val text:String,
    val options:List<String>,
    val correctIndex:Int,
    val imageUrl:String?=null,
    val createdAt:String="",
    val updatedAt:String=""
)
@Serializable data class AnnotationDto(val id:String,val user_id:String,val exam_id:Long,val page_number:Int,val type:String,val content:String?=null,val position:String,val color:String,val thickness:Float,val created_at:String="",val updated_at:String="")
@Serializable data class Login(val username:String,val password:String)
@Serializable data class Token(val token:String,val role:String)

private val jsonCodec = Json { ignoreUnknownKeys = true }

fun questionDto(r:ResultRow)=QuestionDto(
    id=r[Questions.id],
    examId=r[Questions.examId],
    number=r[Questions.number],
    text=r[Questions.text],
    options=jsonCodec.decodeFromString(r[Questions.options]),
    correctIndex=r[Questions.correctIndex],
    createdAt=r[Questions.createdAt].toString(),
    updatedAt=r[Questions.updatedAt].toString()
)

fun main(){embeddedServer(Netty,port=System.getenv("PORT")?.toInt()?:8080,host="0.0.0.0"){module()}.start(wait=true)}

fun Application.module(){
 Database.connect(System.getenv("DATABASE_URL")?:"jdbc:postgresql://localhost:5432/mazarchive",driver="org.postgresql.Driver",
  user=System.getenv("DB_USER")?:"postgres",password=System.getenv("DB_PASSWORD")?:"postgres")
 transaction{SchemaUtils.create(Exams,Questions,Annotations); exec("ALTER TABLE exams ADD COLUMN IF NOT EXISTS description TEXT NOT NULL DEFAULT ''"); exec("ALTER TABLE exams ADD COLUMN IF NOT EXISTS duration_seconds INTEGER NOT NULL DEFAULT 1800") }
 install(ContentNegotiation){json()}
 install(Authentication){jwt("auth"){verifier(JwtAuth.verifier);validate{p->if(p.payload.subject!=null)JWTPrincipal(p.payload)else null}}}
 routing{
  staticResources("/admin", "web") { defaultResource("admin.html") }
  get("/admin/logo"){ call.respondResource("web/logo.png") }
  get("/health"){call.respond(mapOf("status" to "ok"))}
  post("/auth/login"){ 
   val body=call.receive<Login>(); val admin=body.username=="admin" && body.password==(System.getenv("ADMIN_PASSWORD")?:"change-me")
   val role=if(admin)"ADMIN" else "USER"; if (!admin) return@post call.respond(HttpStatusCode.Unauthorized, "نام کاربری یا رمز عبور نامعتبر است")
   val access=JwtAuth.token(body.username,role); val refresh=UUID.randomUUID().toString(); DevRefreshTokens[refresh]=body.username to role; call.respond(mapOf("token" to access,"role" to role,"refreshToken" to refresh))
  }

  post("/auth/refresh"){
   val body=call.receive<Map<String,String>>()
   val rt=body["refreshToken"] ?: return@post call.respond(HttpStatusCode.BadRequest)
   val entry=DevRefreshTokens[rt] ?: return@post call.respond(HttpStatusCode.Unauthorized)
   call.respond(Token(JwtAuth.token(entry.first,entry.second),entry.second))
  }

  authenticate("auth"){
   get("/exams"){
    val g=call.request.queryParameters["grade"];val f=call.request.queryParameters["field"];val y=call.request.queryParameters["year"]?.toIntOrNull()
    val p=call.request.queryParameters["period"];val m=call.request.queryParameters["month"];val q=call.request.queryParameters["q"]
    val rows=transaction{Exams.selectAll().where{Op.build{listOfNotNull(
      g?.let{Exams.grade eq it},f?.let{Exams.field eq it},y?.let{Exams.year eq it},p?.let{Exams.period eq it},m?.let{Exams.month eq it},
      q?.takeIf{it.isNotBlank()}?.let{Exams.title.lowerCase() like "%${it.lowercase()}%"}
    ).fold<Op<Boolean>?>(null){a,b->if(a==null)b else a and b}?:Op.TRUE}}.orderBy(Exams.examDate,SortOrder.DESC).map(::examDto)}
    call.respond(rows)
   }
   get("/exams/{id}"){val id=call.parameters["id"]!!.toLong();transaction{Exams.select{Exams.id eq id}.singleOrNull()?.let{call.respond(examDto(it))}?:call.respond(HttpStatusCode.NotFound)}}
   get("/exams/{id}/questions"){
    val id=call.parameters["id"]!!.toLong()
    call.respond(transaction{Questions.select{Questions.examId eq id}.orderBy(Questions.number).map(::questionDto)})
   }
   get("/exams/{id}/pdf"){val id=call.parameters["id"]!!.toLong();val path=transaction{Exams.select{Exams.id eq id}.singleOrNull()?.get(Exams.pdfUrl)}?:return@get call.respond(HttpStatusCode.NotFound);val f=File(path);if(!f.canonicalPath.startsWith(File(System.getenv("STORAGE_DIR")?:"./storage").canonicalPath))return@get call.respond(HttpStatusCode.Forbidden);if(!f.exists())return@get call.respond(HttpStatusCode.NotFound);call.respondFile(f)}
   get("/exams/{id}/annotations"){val id=call.parameters["id"]!!.toLong();val uid=UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject);call.respond(transaction{Annotations.select{(Annotations.examId eq id) and (Annotations.userId eq uid)}.map(::annotationDto)})}
   post("/exams/{id}/annotations"){val id=call.parameters["id"]!!.toLong();val uid=UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject);val a=call.receive<AnnotationDto>();val aid=UUID.fromString(a.id);transaction{Annotations.insert{it[Annotations.id]=aid;it[userId]=uid;it[examId]=id;it[pageNumber]=a.page_number;it[type]=a.type;it[content]=a.content;it[position]=a.position;it[color]=a.color;it[thickness]=a.thickness;it[createdAt]=Instant.now();it[updatedAt]=Instant.now()}};call.respond(a.copy(user_id=uid.toString()),HttpStatusCode.Created)}
   put("/annotations/{id}"){val aid=UUID.fromString(call.parameters["id"]!!);val uid=UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject);val a=call.receive<AnnotationDto>();transaction{Annotations.update({(Annotations.id eq aid) and (Annotations.userId eq uid)}){it[position]=a.position;it[color]=a.color;it[thickness]=a.thickness;it[content]=a.content;it[updatedAt]=Instant.now()}};call.respond(a)}
   delete("/annotations/{id}"){val aid=UUID.fromString(call.parameters["id"]!!);val uid=UUID.fromString(call.principal<JWTPrincipal>()!!.payload.subject);transaction{Annotations.deleteWhere{(Annotations.id eq aid) and (Annotations.userId eq uid)}};call.respond(HttpStatusCode.NoContent)}
   route("/admin"){
    fun ApplicationCall.isAdmin():Boolean = principal<JWTPrincipal>()?.payload?.getClaim("role")?.asString()=="ADMIN"
    suspend fun ApplicationCall.requireAdmin():Boolean { if(!isAdmin()){ respond(HttpStatusCode.Forbidden, "دسترسی مدیر لازم است"); return false }; return true }
    get("/exams"){ if(!call.requireAdmin()) return@get; val rows=transaction{Exams.selectAll().orderBy(Exams.examDate,SortOrder.DESC).map(::examDto)}; call.respond(rows) }
    get("/stats"){ if(!call.requireAdmin()) return@get; val rows=transaction{Exams.selectAll().toList()}; call.respond(mapOf("total" to rows.size,"withPdf" to rows.count{it[Exams.pdfUrl].isNotBlank()},"withoutPdf" to rows.count{it[Exams.pdfUrl].isBlank()})) }
    post("/exams"){ if(!call.requireAdmin()) return@post;val e=call.receive<ExamDto>();val newId=transaction{Exams.insert{it[title]=e.title;it[grade]=e.grade;it[field]=e.field;it[examNumber]=e.examNumber;it[examDate]=java.time.LocalDate.parse(e.examDate);it[year]=e.year;it[period]=e.period;it[month]=e.month;it[description]=e.description;it[pdfUrl]=e.pdfUrl;it[durationSeconds]=e.durationSeconds;it[createdAt]=Instant.now();it[updatedAt]=Instant.now()} get Exams.id};call.respond(e.copy(id=newId),HttpStatusCode.Created)}
    put("/exams/{id}"){if(!call.requireAdmin()) return@put;val id=call.parameters["id"]!!.toLong();val e=call.receive<ExamDto>();transaction{Exams.update({Exams.id eq id}){it[title]=e.title;it[grade]=e.grade;it[field]=e.field;it[examNumber]=e.examNumber;it[examDate]=java.time.LocalDate.parse(e.examDate);it[year]=e.year;it[period]=e.period;it[month]=e.month;it[description]=e.description;it[durationSeconds]=e.durationSeconds;it[updatedAt]=Instant.now()}};call.respond(e)}
    delete("/exams/{id}"){if(!call.requireAdmin()) return@delete;transaction{Exams.deleteWhere{Exams.id eq call.parameters["id"]!!.toLong()}};call.respond(HttpStatusCode.NoContent)}
    get("/exams/{id}/questions"){
     if(!call.requireAdmin()) return@get
     val examId=call.parameters["id"]!!.toLong()
     call.respond(transaction{Questions.select{Questions.examId eq examId}.orderBy(Questions.number).map(::questionDto)})
    }
    post("/exams/{id}/questions"){
     if(!call.requireAdmin()) return@post
     val examId=call.parameters["id"]!!.toLong()
     val q=call.receive<QuestionDto>()
     if(q.options.size < 2 || q.correctIndex !in q.options.indices) return@post call.respond(HttpStatusCode.BadRequest,"گزینه‌ها یا پاسخ صحیح نامعتبر است")
     val newId=transaction{
       Questions.insert{
        it[Questions.examId]=examId;it[number]=q.number;it[text]=q.text
        it[options]=jsonCodec.encodeToString(q.options);it[correctIndex]=q.correctIndex
        it[createdAt]=Instant.now();it[updatedAt]=Instant.now()
       } get Questions.id
     }
     call.respond(q.copy(id=newId,examId=examId),HttpStatusCode.Created)
    }
    put("/exams/{examId}/questions/{id}"){
     if(!call.requireAdmin()) return@put
     val examId=call.parameters["examId"]!!.toLong(); val id=call.parameters["id"]!!.toLong()
     val q=call.receive<QuestionDto>()
     if(q.options.size < 2 || q.correctIndex !in q.options.indices) return@put call.respond(HttpStatusCode.BadRequest,"گزینه‌ها یا پاسخ صحیح نامعتبر است")
     transaction{
       Questions.update({(Questions.id eq id) and (Questions.examId eq examId)}){
        it[number]=q.number;it[text]=q.text;it[options]=jsonCodec.encodeToString(q.options)
        it[correctIndex]=q.correctIndex;it[updatedAt]=Instant.now()
       }
     }
     call.respond(q.copy(id=id,examId=examId))
    }
    delete("/exams/{examId}/questions/{id}"){
     if(!call.requireAdmin()) return@delete
     val examId=call.parameters["examId"]!!.toLong(); val id=call.parameters["id"]!!.toLong()
     transaction{Questions.deleteWhere{(Questions.id eq id) and (Questions.examId eq examId)}}
     call.respond(HttpStatusCode.NoContent)
    }
    post("/exams/{id}/pdf"){if(!call.requireAdmin()) return@post;val id=call.parameters["id"]!!.toLong();if(call.request.contentType()!=ContentType.Application.Pdf)return@post call.respond(HttpStatusCode.UnsupportedMediaType);val root=File(System.getenv("STORAGE_DIR")?:"./storage");val target=File(root,"exams/$id.pdf");target.parentFile.mkdirs();call.receiveChannel().toInputStream().use{input->target.outputStream().use{out->input.copyTo(out,50L*1024*1024)}};val magic=target.inputStream().use{it.readNBytes(5)};if(!magic.contentEquals(byteArrayOf(0x25,0x50,0x44,0x46,0x2D))){target.delete();return@post call.respond(HttpStatusCode.BadRequest,"Invalid PDF")};transaction{Exams.update({Exams.id eq id}){it[pdfUrl]=target.absolutePath;it[updatedAt]=Instant.now()}};call.respond(mapOf("ok" to true))}
   }
  }
 }
}
fun examDto(r:ResultRow)=ExamDto(r[Exams.id],r[Exams.title],r[Exams.grade],r[Exams.field],r[Exams.examNumber],r[Exams.examDate].toString(),r[Exams.year],r[Exams.period],r[Exams.month],r[Exams.description],r[Exams.pdfUrl],r[Exams.durationSeconds])
fun annotationDto(r:ResultRow)=AnnotationDto(r[Annotations.id].toString(),r[Annotations.userId].toString(),r[Annotations.examId],r[Annotations.pageNumber],r[Annotations.type],r[Annotations.content],r[Annotations.position],r[Annotations.color],r[Annotations.thickness],r[Annotations.createdAt].toString(),r[Annotations.updatedAt].toString())
object DevRefreshTokens:MutableMap<String,Pair<String,String>> by java.util.concurrent.ConcurrentHashMap<String,Pair<String,String>>()
object JwtAuth{
 private val secret=System.getenv("JWT_SECRET")?:"CHANGE_ME"
 fun token(sub:String,role:String):String{val h=Base64.getUrlEncoder().withoutPadding().encodeToString("""{"alg":"HS256","typ":"JWT"}""".toByteArray());val p=Base64.getUrlEncoder().withoutPadding().encodeToString("""{"sub":"$sub","role":"$role"}""".toByteArray());val data="$h.$p";val mac=Mac.getInstance("HmacSHA256");mac.init(SecretKeySpec(secret.toByteArray(),"HmacSHA256"));val s=Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(data.toByteArray()));return "$data.$s"}
 val verifier=com.auth0.jwt.JWT.require(com.auth0.jwt.algorithms.Algorithm.HMAC256(secret)).build()
}
